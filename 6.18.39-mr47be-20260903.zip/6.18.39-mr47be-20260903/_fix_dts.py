dts = open('/root/flint3-mr47be-20260903/target/linux/qualcommbe/dts/ipq5332-mr47be-v2.dts').read()
dts = dts.replace('reg = <0x0 0x4a900000 0x0 0x02300000>;', 'reg = <0x0 0x4a900000 0x0 0x02b00000>;')
open('/root/flint3-mr47be-20260903/target/linux/qualcommbe/dts/ipq5332-mr47be-v2.dts', 'w').write(dts)
print('DTS fixed: 35MB -> 43MB')
