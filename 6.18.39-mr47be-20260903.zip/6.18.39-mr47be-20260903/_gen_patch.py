import subprocess

# Read the source after 2010c
src_path = '/root/flint3-mr47be-20260903/build_dir/target-aarch64_cortex-a53_musl/linux-qualcommbe_ipq53xx/linux-6.18.39/drivers/remoteproc/qcom_q6v5_wcss_sec.c'
with open(src_path) as f:
    src = f.read()

# 1. Add smem.h include
src = src.replace(
    '#include <linux/soc/qcom/mdt_loader.h>\n',
    '#include <linux/soc/qcom/mdt_loader.h>\n#include <linux/soc/qcom/smem.h>\n'
)

# 2. Add bootargs writer before Q6_WAIT_TIMEOUT
bootargs = '''#define Q6_BOOT_ARGS_SMEM_SIZE 4096
#define REMOTE_PID 1

struct bootargs_smem_info {
	void *smem_base_ptr;
	void *smem_elem_cnt_ptr;
	void *smem_bootargs_ptr;
};

static int wcss_sec_write_bootargs(struct device *dev)
{
	int ret;
	u32 smem_id, rd_val;
	size_t size;
	u16 cnt, tmp, version;
	void *ptr;
	u8 *bootargs_arr;
	struct device_node *np = dev->of_node;
	struct bootargs_smem_info boot_args;

	ret = of_property_read_u32(np, "qcom,bootargs_smem", &smem_id);
	if (ret) {
		dev_err(dev, "failed to get bootargs smem id\\n");
		return ret;
	}

	ret = qcom_smem_alloc(REMOTE_PID, smem_id, Q6_BOOT_ARGS_SMEM_SIZE);
	if (ret && ret != -EEXIST) {
		dev_err(dev, "failed to allocate bootargs smem\\n");
		return ret;
	}

	boot_args.smem_base_ptr = qcom_smem_get(REMOTE_PID, smem_id, &size);
	if (IS_ERR(boot_args.smem_base_ptr)) {
		dev_err(dev, "unable to get bootargs smem %ld\\n",
			PTR_ERR(boot_args.smem_base_ptr));
		return PTR_ERR(boot_args.smem_base_ptr);
	}
	ptr = boot_args.smem_base_ptr;

	version = 2;
	if (!of_property_read_u32(dev->of_node, "qcom,bootargs_version", &rd_val))
		version = (u16)rd_val;
	memcpy_toio(ptr, &version, sizeof(version));
	ptr += sizeof(version);
	boot_args.smem_elem_cnt_ptr = ptr;

	cnt = ret = of_property_count_u32_elems(np, "boot-args");
	if (ret < 0)
		cnt = 0;
	memcpy_toio(ptr, &cnt, sizeof(u16));
	ptr += sizeof(u16);

	if (cnt > 0) {
		bootargs_arr = kzalloc(cnt, GFP_KERNEL);
		if (!bootargs_arr)
			return -ENOMEM;
		for (tmp = 0; tmp < cnt; tmp++) {
			ret = of_property_read_u32_index(np, "boot-args", tmp, &rd_val);
			if (ret) {
				kfree(bootargs_arr);
				return ret;
			}
			bootargs_arr[tmp] = (u8)rd_val;
		}
		memcpy_toio(ptr, bootargs_arr, cnt);
		ptr += cnt;
		kfree(bootargs_arr);
	}
	boot_args.smem_bootargs_ptr = ptr;

	ret = of_property_read_u32(np, "qcom,heartbeat_smem", &smem_id);
	if (!ret) {
		ret = qcom_smem_alloc(REMOTE_PID, smem_id, Q6_BOOT_ARGS_SMEM_SIZE);
		if (ret && ret != -EEXIST) {
			dev_err(dev, "failed to allocate heartbeat smem\\n");
			return ret;
		}
	}

	dev_info(dev, "bootargs written to SMEM (version=%u, cnt=%u)\\n", version, cnt);
	return 0;
}

'''

src = src.replace(
    '#define Q6_WAIT_TIMEOUT\t\t\t(5 * HZ)',
    bootargs + '#define Q6_WAIT_TIMEOUT\t\t\t(5 * HZ)'
)

# 3. Add bootargs call in wcss_sec_start
src = src.replace(
    '\tret = qcom_q6v5_prepare(&wcss->q6);\n\tif (ret)\n\t\treturn ret;',
    '\tret = wcss_sec_write_bootargs(dev);\n\tif (ret)\n\t\tdev_warn(dev, "bootargs write failed %d\\n", ret);\n\n\tret = qcom_q6v5_prepare(&wcss->q6);\n\tif (ret)\n\t\treturn ret;'
)

with open(src_path, 'w') as f:
    f.write(src)

print('Source modified. Now generate diff...')

# Generate diff against the 2010c-applied source
# We need to get the original (2010c applied) source first
# Actually, let's just verify the changes are in place
print('bootargs function added:', 'wcss_sec_write_bootargs' in src)
print('smem.h added:', 'linux/soc/qcom/smem.h' in src)
print('bootargs call added:', 'wcss_sec_write_bootargs(dev)' in src)
