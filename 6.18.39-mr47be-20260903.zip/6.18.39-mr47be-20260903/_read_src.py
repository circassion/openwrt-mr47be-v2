import sys
p = '/root/flint3-mr47be-20260903/build_dir/target-aarch64_cortex-a53_musl/linux-qualcommbe_ipq53xx/linux-6.18.39/drivers/remoteproc/qcom_q6v5_wcss_sec.c'
lines = open(p).readlines()
for i, line in enumerate(lines[44:90], start=45):
    print(f"{i}: {line}", end='')
