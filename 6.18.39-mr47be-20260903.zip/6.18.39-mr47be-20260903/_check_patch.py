lines = open('/root/flint3-mr47be-20260903/target/linux/qualcommbe/patches-6.18/2010d-remoteproc-qcom-wcss-sec-bootargs-writer.patch').readlines()
for i, line in enumerate(lines[90:105], start=91):
    print(f"{i}: {repr(line)}")
