patch_path = '/root/flint3-mr47be-20260903/target/linux/qualcommbe/patches-6.18/2010d-remoteproc-qcom-wcss-sec-bootargs-writer.patch'

with open(patch_path) as f:
    patch = f.read()

# Fix the headers
patch = patch.replace(
    '--- /tmp/qcom_q6v5_wcss_sec_2010c.c\t2026-09-08 09:42:06.581354042 +0300\n',
    '--- a/drivers/remoteproc/qcom_q6v5_wcss_sec.c\n'
)
patch = patch.replace(
    '+++ /root/flint3-mr47be-20260903/build_dir/target-aarch64_cortex-a53_musl/linux-qualcommbe_ipq53xx/linux-6.18.39/drivers/remoteproc/qcom_q6v5_wcss_sec.c\t2026-09-08 09:40:34.309912236 +0300\n',
    '+++ b/drivers/remoteproc/qcom_q6v5_wcss_sec.c\n'
)

with open(patch_path, 'w') as f:
    f.write(patch)

print('Headers fixed')
print('First 5 lines:')
for line in patch.split('\n')[:5]:
    print(line)
