# LIVE SESSION STATE — Flint3 temelli MR47BE portu (v2)
 **TEK KAYNAK.** Her oturumda İLK İŞ bunu oku. Yeni .md ÜRETME — bunu güncelle.
> **Yeni çalışma alanı:** `E:\ROUTER\router\GL-BE9300 (Flint 3)\`  (MR47BE klasörü artık YEDEK/REFERANS)
> **Repo (çalışan referans):** `https://github.com/perceival/openwrt-flint3`  (branch `flint3-be9300`, kernel 6.18)
> **Klonumuz:** `E:\WSL\flint3-mr47be-20260903\`
> **Son güncelleme:** 2026-09-08 (Q6-FW-COMPARE oturumu) — 3 fw karşılaştırması + RAM testi: firmware İÇERİĞİ -12'nin sebebi DEĞİL; vendor DTB memory-map farkı (43→35MB + bootargs_version=2 + heartbeat 508) = yeni prime suspect (§33). Önceki: 2026-09-07 (test41 oturumu) — TEST41 UART+SSH canlı doğrulandı: regdb.bin artık doğru dizinde VAR (/lib/firmware/ath12k/QCN9274/hw2.0/), WAN internet ✓ (ping 8.8.8.8); ama PCI EP [17cb:1109] yine MSI16'da sessiz (MHI power-up yok), Q6 yine TZ -12 (res0=0). Root Port [17cb:1005] her testte ~1.075s ✓ — şüpheli hiç olmadı. debug_mask doğru yolu teyit: /sys/module/ath12k/. SSH'ten reload → cihaz 2. kez çöktü (UART güç çevrimi gerekli). Detay §32

---
> Amaç: `perceival/openwrt-flint3` (flint3-be9300, kernel 6.18) tree'sini MR47BE V2'ye uyarlamak.
> Klon: `E:\WSL\flint3-mr47be-20260903\`
> NOT: MR47BE donanımı Ethernet hariç flint3 ile aynı IPQ5332 ailesi. RTL8372N/RTL8221B ALINMAZ.

## 📌📌 HİÇBİR YERI SİLME — BUILD & İMAJ ADRES REHBERİ (her oturumda İLK BURADAN DEVAM ET) 📌📌
- **Build ağacı (kaynak kod + make):** `/root/flint3-mr47be-20260903`  =  Windows: `\\wsl$\Ubuntu-24.04\root\flint3-mr47be-20260903`
- **İMAJLARIN OLUŞTUĞU yer (make çıktısı):** `/root/flint3-mr47be-20260903/bin/targets/qualcommbe/ipq53xx/`  =  `\\wsl$\Ubuntu-24.04\root\flint3-mr47be-20260903\bin\targets\qualcommbe\ipq53xx\`
- **Build log:** `\\wsl$\Ubuntu-24.04\root\build-testNN.log`
- **İMAJLARIN TRANSFER/ARŞİV yeri (son durdukları yer):** `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\<testNN>\`
- **Build başlatma (PowerShell'den, FOREGROUND client; arka plan setsid ÖLÜR):** `wsl -d Ubuntu-24.04 -- bash -c 'cd /root/flint3-mr47be-20260903 && env FORCE_UNSAFE_CONFIGURE=1 make -j4 > /root/build-testNN.log 2>&1; echo DONE'`
- **Make durdurma:** `pkill -x make` (`pkill -f 'make -j4'` kendini öldürür!)
- her yeni imajda bu satır güncellenecek tarih/imaj durumu**Son durum (07.09, test41):** ⚠️ **HÂLÂ ÇALIŞAN SORUNSUZ İMAJ YOK.** test41 (regdb paketi + qrtr-ns LF fix'li) UART/TFTP boot ✓; SSH ✓, WAN internet ✓ (UART logunda ping 8.8.8.8 0% loss), LAN1 jakı ✓; LAN2/3 ✗ (ess-switch sürücüsü yok); WiFi ✗. QCN9274/hw2.0/regdb.bin cihazda DOĞRU yerde VAR ama dmesg'de hiç qmi/regdb/bdf satırı yok — PCI EP [17cb:1109] probe'u MSI16 sonrası ~30ms'de bitiyor, MHI power-up çağrılmıyor (§31C geçerli). Q6 2.4G yine "MR47BE: mpd cmd=24 ret=-12 res0=0" = TZ'nin KENDİ ENOMEM'i (§27). PCIe teşhisi kesinleşti (§32): [17cb:1005] root port asla sorun değil; -22→-12 daima IPQ5332 iç Q6'dan (ath12k_wifi7_ahb), [17cb:1109]'un belirtisi hatasız sessizlik. debug_mask yolu = /sys/module/ath12k/parameters/debug_mask (çekirdek modülü adı "ath12k"). UYARI: rmmod/modprobe reload SSH'ten yapılınca cihaz çöküyor (2x kanıt) → SADECE UART'tan; reload sonrası mask 0'a döner (kalıcı: /etc/modules.d satırı). Detay §32
Windows PowerShell
Copyright (C) Microsoft Corporation. All rights reserved.

PS C:\WINDOWS\system32> wsl -l -v
  NAME              STATE           VERSION
* docker-desktop    Running         2
  Ubuntu-24.04      Stopped         2
PS C:\WINDOWS\system32> wsl -d Ubuntu-24.04
root@TuRUSmay:/mnt/c/WINDOWS/system32# hostname
pwd
ls -la /root/flint3-mr47be-20260903
cat /etc/os-release
TuRUSmay
/mnt/c/WINDOWS/system32
total 500
drwxrwxrwx 21 root root   4096 Sep  5 03:05 .
drwx------ 15 root root  12288 Sep  6 16:38 ..
-rw-r--r--  1 root root 163135 Sep  5 03:05 .config
-rw-r--r--  1 root root 154293 Sep  5 03:05 .config.old
drwxrwxrwx  3 root root   4096 Sep  3 16:31 .devcontainer
drwxrwxrwx  7 root root   4096 Sep  4 03:32 .git
-rwxrwxrwx  1 root root    137 Sep  3 16:31 .gitattributes
drwxrwxrwx  4 root root   4096 Sep  3 16:31 .github
-rwxrwxrwx  1 root root    362 Sep  3 16:31 .gitignore
drwxrwxrwx  2 root root   4096 Sep  3 16:31 .vscode
-rwxrwxrwx  1 root root   2909 Sep  3 16:31 2.4GHZ-Q6-PAS-FINDINGS.md
-rwxrwxrwx  1 root root    106 Sep  3 16:31 BSDmakefile
-rwxrwxrwx  1 root root    284 Sep  3 16:31 COPYING
-rwxrwxrwx  1 root root    668 Sep  3 16:31 Config.in
drwxrwxrwx  2 root root   4096 Sep  3 16:31 LICENSES
-rwxrwxrwx  1 root root   4233 Sep  3 16:31 Makefile
-rwxrwxrwx  1 root root   4362 Sep  3 16:31 README.md
drwxr-xr-x  4 root root   4096 Sep  3 22:56 bin
drwxr-xr-x  6 root root   4096 Sep  3 22:56 build_dir
drwxrwxrwx  2 root root   4096 Sep  3 16:31 config
drwxrwxrwx  2 root root   4096 Sep  3 16:31 configs
drwxrwxrwx  2 root root  12288 Sep  5 03:07 dl
drwxrwxrwx 12 root root   4096 Sep  3 20:54 feeds
-rwxrwxrwx  1 root root    441 Sep  3 16:31 feeds.conf.default
drwxrwxrwx  3 root root   4096 Sep  3 16:31 include
drwxrwxrwx 12 root root   4096 Sep  5 03:05 package
-rw-r--r--  1 root root    227 Sep  3 22:56 private-key.pem
-rw-r--r--  1 root root    178 Sep  3 22:56 public-key.pem
-rwxrwxrwx  1 root root  17647 Sep  3 16:31 rules.mk
drwxrwxrwx  4 root root   4096 Sep  3 16:31 scripts
drwxrwxrwx  7 root root   4096 Sep  3 23:25 staging_dir
drwxrwxrwx  7 root root   4096 Sep  3 16:32 target
drwxrwxrwx  4 root root  20480 Sep  6 16:43 tmp
drwxrwxrwx 12 root root   4096 Sep  3 16:32 toolchain
drwxrwxrwx 76 root root   4096 Sep  3 16:32 tools
PRETTY_NAME="Ubuntu 24.04.4 LTS"
NAME="Ubuntu"
VERSION_ID="24.04"
VERSION="24.04.4 LTS (Noble Numbat)"
VERSION_CODENAME=noble
ID=ubuntu
ID_LIKE=debian
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
UBUNTU_CODENAME=noble
LOGO=ubuntu-logo
root@TuRUSmay:/mnt/c/WINDOWS/system32#
>
## 0. ÖN KOŞULLAR
- WSL: `Ubuntu-24.04` (çalışıyor). E: NTFS mount: `/mnt/e`.
- Boş disk: ~878 GB. RAM: 7 GB → `make -j4` kullan.
- Hedef klasör (kullanıcının çalışma alanı): `E:\ROUTER\router\GL-BE9300 (Flint 3)\`
- Klon daha önce `git clone -b flint3-be9300 --depth 1 https://github.com/perceival/openwrt-flint3.git E:\WSL\flint3-mr47be-20260903` ile alındı.

## 1. BUILD (flint3 asıl)
```bash
wsl -d Ubuntu-24.04
cd /mnt/e/WSL/flint3-mr47be-20260903
./scripts/feeds update -a
./scripts/feeds install -a
make defconfig
# Target System: Qualcomm Atheros 802.11be ; Subtarget: ipq53xx ; Profile: GL-BE9300
make menuconfig        # (isteğe bağlı)
setsid nohup make -j4 V=s > /mnt/e/ROUTER/router/GL-BE9300\ \(Flint\ 3\)/_loglar/build1.log 2>&1 < /dev/null &
```
- İmaj: `bin/targets/qualcommbe/ipq53xx/openwrt-qualcommbe-ipq53xx-glinet_gl-be9300-*.itb`
- RAM boot (be9300): `tftpboot 0x46000000 <itb>; bootm 0x46000000` (FLint3 eMMC'den boot edilir ama RAM boot çalışır).

 YEDEK
- Çalışan her imaj/build → `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\<tarih>_<test>\`
- DTS/patch değişikliği öncesi `cp file file.bak_<tarih>`.


## 3. MR47BE KRİTİK DTS KARARLARI (ilk test denemesi)
```dts
reserved-memory {
    q6_region: wcss@4a900000 { reg = <0x0 0x4a900000 0x0 0x02b00000>; };  /* 43MB DENENECEK */
    m3_dump:  m3-dump@4d400000  { reg = <0x0 0x4d400000 0x0 0x100000>; };
    q6_caldb: q6-caldb@4d500000 { reg = <0x0 0x4d500000 0x0 0x500000>; };
    mlo_mem:  mlo-global-mem@4db00000 { reg = <0x0 0x4db00000 0x0 0x01200000>; }; /* 18MB */
    qcn9224_host_ddr: qcn9224-host-ddr@4ed00000 { reg = <0x0 0x4ed00000 0x0 0x03200000>; }; /* 50MB */
};
&wifi0 { qcom,board-id = <18>; ... };   /* 22 YERİNE 18 */
&q6v5_wcss { firmware-name = "ath12k/IPQ5332/hw1.0/q6_fw0.mdt"; };
```
> Not: MR47BE vendor GPL'de 35MB (0x2300000) **da** gördük. İlk test 43MB + board-id 18. Eğer TZ yine -22 verirse 3-arg auth (0606) ekle.

## 4. BİLİNEN HATALAR / DERSLER
**WSL BUILD/ÇÖKME DERSLERİ (05.09, test30):** ① `wsl bash -c 'setsid nohup make &'` ile başlatma — wsl.exe client çıkınca distro ~8 sn'de kapanır, make ölür (belirti: log 0 byte). ② `pkill -f 'make -j4'` KENDİ bash'ini öldürür (self-match) → `pkill -x make` veya `[m]ake`. ③ DOĞRU YÖNTEM: **foreground wsl.exe client** içinde make (`wsl -d ... -- bash -c 'cd /root/... && make -j4 > /root/build-test30.log 2>&1; echo DONE'`) — client canlı kaldıkça distro kapanmaz. ④ Log boşluksuz yola (`/root/build-test30.log`), Windows'tan `\\wsl$\Ubuntu-24.04\root\` ile takip; bitince E:'ye cp. ⑤ /mnt/e'de ağır find/grep segfault — Windows'tan oku (SBE1V1K LIVE §4).
- DTS'te `#` yorum DEĞİL; `/* */` kullan.
- rsync `--exclude=bin` (anchorsız) TÜM bin/ siler → `--exclude=/bin` kullan.
- `setsid nohup make &` şart; nohup tek başına ölür.
- İmaj kopyalama her zaman python/script ile (WSL watcher ölüyor).
- DEVICE_DTS `mercusys_mr47be-v2` → build `ipq5332-mr47be-v2.dts` arar; dosya adını doğru koy.
- 6.18.39 devam; .44/.48'e çıkma yok (patch set kırılır).


---
## ⚠️⚠️ BUILD ADRESİ — EN ÜSTTE, ASLA SİLME (05.09) ⚠️⚠️
- **Build ağacının TEK GERÇEK YERİ (WSL ext4 içi): `/root/flint3-mr47be-20260903`**
- **Windows'tan açmak için Dosya Gezgini adres çubuğuna KOPYALA:**
  `\\wsl$\Ubuntu-24.04\root\flint3-mr47be-20260903`
- **İmajlar burda çıkar:** `\\wsl$\Ubuntu-24.04\root\flint3-mr47be-20260903\bin\targets\qualcommbe\ipq53xx\`
- **Build log:** `\\wsl$\Ubuntu-24.04\root\build-testNN.log` (boşluklu E: yoluna log yazma — redirect bozulur!)
- **`E:\WSL\flint3-mr47be-20260903` İLE BUILD OLMAZ** (NTFS case-sensitive-fs hatası; ölü kopya, sadece referans).
- **Build başlatma (PowerShell'den, FOREGROUND client — arka plan setsid ÖLÜR):**
  ```
  wsl -d Ubuntu-24.04 -- bash -c 'cd /root/flint3-mr47be-20260903 && env FORCE_UNSAFE_CONFIGURE=1 make -j4 > /root/build-testNN.log 2>&1; echo DONE'
  ```
- **Kill gerekirse:** `pkill -x make` KULLAN — `pkill -f 'make -j4'` KENDİ komutunu öldürür!
- **Build bitince imaj kopyalama (PowerShell):**
  ```
  Copy-Item '\\wsl$\Ubuntu-24.04\root\flint3-mr47be-20260903\bin\targets\qualcommbe\ipq53xx\*' 'E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\testNN\' -Force
  ```
- **DTS:** `/root/flint3-mr47be-20260903/target/linux/qualcommbe/dts/ipq5332-mr47be-v2.dts` — değiştirmeden ÖNCE `.bak_<test>_<tarih>` yedek al.
---

## ⭐⭐⭐ DURUM: TEST30 = ÇALIŞAN İMAJ — SİLME / DEĞİŞTİRME (05.09) ⭐⭐⭐
İlk İNTERNETE açılan build: **WAN ✅ DHCP ✅ ping 8.8.8.8 ✅ LuCI ✅ LAN1 ✅** · LAN2/3 + WiFi = sıradaki faz.
- **ALINACAK İMAJ:** `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\test30\openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb` (sha `6EE316F1…`)
- **WAN'ı çözen DTS (değişmemeli):** WAN port@1 = `phy-mode="2500base-x"` + `managed="in-band-status"` (LAN1 sgmii+phy-handle kalsın).
- **Rapor:** `imajlar\test30\test30_uart_openwrt_sonuçları.md` (UART dökümü + SSH komutları + altın kanıt satırları).
- **LED:** WAN/LAN1 jak LED'leri yanmıyor (ess-switch sürücüsüyle gelecek; vendor eşleme wan=31 lan1=24 lan2=39 lan3=32).
- **Sonraki (test31):** ① Q6 2.4G -22 → 0606 3-arg PAS patch ② QCN6274 MHI/fw/QMI + SBE1V1K gold-mine `d5ed1d2f5d` (per-radio MAC) & `72dce28ee0` (multi-PCI-path) ③ LAN2/3 + LED → ess-switch-qca8386 (Compex/Wallys GPL).

### 21.7 TEST31 (05.09 — QCN6274 MHI fw'ya sokma: Q6 clock kilidini kır)
- **Teşhis (test30 cihazında):** `/lib/firmware/ath12k/QCN9274/hw2.0/` = firmware-2.bin+board-2.bin+regdb.bin (cal-pci YOK — ath12k caldata'yı hiç istemedi, çünkü MHI/fw aşamasına ulaşmadı). `dmesg`'te **`gcc ... sync_state() pending due to c000000.wifi`** = Q6/ath12k_ahb -22 probe fail'i tüm clock sistemini bekletiyor → ath12k_pci fw/MHI yükleyemiyor. (caldata script'i MR47BE case'li HAZIR: `0:art 0x58800 0x27800` — tetiklenmiyormuş.)
- **test31 değişikliği (DTS 2 satır):** `&wifi0` (638) ve `&q6v5_wcss` (664) → `status="disabled"` → Q6 -22 ortadan kalksın, gcc sync_state release olsun, QCN6274(WIFI1) fw/MHI önü açılsın. 2.4G bu build'de bilerek kapalı; test32'de 0606 patchi ile geri gelecek. Yedek: `.bak_test30_20260905`.
- **SBE1V1K caldata referansı:** 3 radyo = 3 ayrı cal `0:58800/0x8a800/0xbc800` (her biri 0x2d000). MR47BE tek pcie→tek cal 0x58800 0x2d000 adayı (0x27800'den büyük; num-radios=2).
- **Build:** `/root` `make -j4` → `log build-test31.log` → imaj `imajlar\test31\`.
- **Test kriteri:** `dmesg | grep -iE 'ath12k_pci|mhi|qmi|bdf|sync_state'` → MHI/fw satırları + `iw dev`'te wlan; `sync_state()` kilidi release oldu mu.
- **✅ test31 HAZIR (05.09):** initramfs sha `8986866A…` → `imajlar\test31\`
- **TFTP:** `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\test31\openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb`
  `setenv serverip 192.168.1.100; setenv ipaddr 192.168.1.1; tftpboot 0x46000000 openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb; bootm 0x46000000`
- Boot sonrası bak: `dmesg | grep -iE 'ath12k_pci|mhi|qmi|bdf|sync_state'` → wlan/radyolar + MHI/fw satırları + `iw dev`. WAN/LAN/LuCI değişmemeli.

## 0. NEDEN BU ALAN?

- MR47BE ağacımız (`E:\ROUTER\MERCUSYS MR47BE_OPENWRT\`) 25+ test yaptı, Q6/PAS hâlâ **-22/−12**.
- perceival/openwrt-flint3 **aynı IPQ5332 SoC'de Wi-Fi 7 üç bandı çalıştırıyor** (README: "Wi-Fi 7, all three bands working; MLO working").
- Amacımız: **çalışan flint3 build'ini MR47BE donanımına uyarlamak** (ismi flint3 olsun umurumuzda değil).
- MR47BE klasörüne DOKUNMA — yeni oyun alanı burası. Değişiklikleri buradan (klon + bu klasör) takip et.

---


---

## 1. DONANIM (MR47BE V2 — kesin, foto + UART)

| Bileşen | Değer |
|---|---|
| SoC | **IPQ5322** (`IPQ5332LA` = bootloader string'i, donanım DEĞİL) |
| RAM | 1 GiB DDR4 (Samsung K4A8G165WC-BCTD) |
| NAND | Winbond W25N01GW 128 MiB SPI-NAND (SPI-NOR YOK) |
| WiFi 2.4G | on-SoC IPQ5332 Q6/WCSS (AHB), ath12k, board-id **0x12=18** (vendor GPL) |
| WiFi 5/6G | QCN6274/QCN9274 via PCIe1, pci17cb:1109, **board-id 0x1019**, num-radios 2 |
| Ethernet | QCA8084 entegre switch-PHY (AYRI çip YOK; GPL `ipq_qca8084.c`) — 4× 2.5G |
| UART | GPIO18/19, 115200 8N1 |
| Secure Boot | **Off** (U-Boot `Secure Boot: Off`) → imzasız boot mümkün |
| QFPROM | `full fuse OTP[1/1]`; mtd11 secure-binary BOŞ (BI# blob 48B @0x7ffd0) |

## 2. FLINT3 REPO GERÇEKLERİ (bu oturumda OKUNDU)

### 2.1 README (özet)
- `flint3-be9300` = **tam, build edilebilir OpenWrt tree'si** (target `qualcommbe/ipq53xx`, kernel **6.18**).
- Durum: boot/procd/SSH ✅ · LAN (RTL8372N DSA + EDMA/PPE) ✅ · WAN (RTL8221B USXGMII 2.5G) ✅ · VLAN ✅ · **Wi-Fi 7 all three bands ✅ · MLO ✅ · DFS ✅** · 802.11k/v ✅ · throughput ~1.8–1.9 Gbit/s.
- Known issues: ath12k firmware hang under sustained load; PPE WAN RX FIFO overrun.
- Build: `clone -b flint3-be9300` → `./scripts/feeds update -a; install -a` → `make menuconfig` (Target=qualcommbe, Subtarget=ipq53xx, Profile=GL-BE9300) → `make -j$(nproc)`.

### 2.2 `2.4GHZ-Q6-PAS-FINDINGS.md` (Q6 sorunu — BİLİMSEL BULGU)
- **-22 kök nedeni:** retail IPQ5332 TZ'si `PAS_AUTH_AND_RESET`'i **3 argümanla** bekliyor `(peripheral, debug, reset_cmd_id)`; mainline **1 argüman** gönderiyor → `-EINVAL`.
- **Fix = `0606-remoteproc-qcom-q6-mpd-3arg-pas-auth.patch`** → `qcom_scm_pas_auth_and_reset_mpd(peripheral, debug, reset_cmd_id)`, reset_cmd_id **0x18** (IPQ5332 root PD; IPQ5018=0x14).
- Donanımda doğrulandı: 0606 ile **-22 → -12** (TZ isteği kabul ediyor, sonra ENOMEM).
- **-12 denenen/elenen:** SMEM 507 bootargs segmenti; reset_cmd_id 0x14 vs 0x18; Q6 mem/bus clock'ları (yanlış teori); low reserved-memory (uboot/sbl/tz/smem 0x4a100000-0x4a900000). Hepsi hâlâ -12.
- Kalan hipotez: upstream mem kombinasyonu `q6_fw0.mbn` + 43MB q6_region — **`.mbn` yayınlanmamış** (upstream-wifi-fw/linux-firmware'de yok) → perceival bu noktada takılmış.

### 2.3 ⚠️ KRİTİK: flint3-be9300 branch'inde 0606 patch'i YOK
- `target/linux/qualcommbe/patches-6.18/` listesinde sadece: `2010` (wcss_sec sürücü), `2010a` (crash-reason SMEM host), `2008` (SCM metadata size).
- **0606** yalnız README + findings'ta atıf; branch tree'sinde dosya değil. → "three bands working" büyük olasılıkla **Q6-2.4GHz HÂLÂ -12 iken** PCIe radyolarıyla ölçülmüş.
- **Kendi 0606/3-arg patch'imizi eklememiz gerekebilir.**

### 2.4 Patch seti (flint3-be9300, 6.18)
- **0301-0312:** QCA8084 PHY sürücüsü (probe/config_init/package/SerDes) — MR47BE Ethernet için BİREBİR gerekli.
- **0313-0324:** IPQ9574/5332 PCS + USXGMII/2500BASEX/1000BASEX/10G_QXGMII + UNIPHY.
- **0325-0342:** PPE/EDMA/netdev driver (RX/TX/ethtool/sysctl/label).
- **0343-0355:** IPQ9574 PPE/EDMA/MDIO/port DTS + NSSNOC/interconnect.
- **0356-0374:** ipq5332 pwm/mdio/pcie2/USB + PPE fix'leri.
- **2007:** tmel-qmp mailbox · **2008:** SCM metadata size · **2010/2010a:** WCSS secure PIL + crash-reason.
- **2011/2012/2013:** ipq5018/ipq5332/ipq9574 Q6 DTS (smp2p + remoteproc@d100000 + q6_region **43MB**).
- **2014-2018:** CMN-PLL (IPQ5332 ref div, 50/200MHz çıkışlar) + xo_board.
- **2028-2034:** QPIC SPI-NAND + eMMC-off (ipq5332 rdp442).
- **2050:** ipq5332 wifi node (RDP441) — q6_region 43MB, m3_dump@4d400000, caldb@4d500000, mlo@4db00000 18MB.
---

## 3. GL-BE9300 DTS Q6/zinciri (`dts/ipq5332-gl-be9300.dts`)
- reserved-memory: `tzapp@49b00000`(6MB) · `m3_dump@4d400000`(1MB) · `q6_caldb@4d500000`(5MB) · `ramoops@4da00000`(1MB) · `mlo@4db00000`(**18MB**) · `qcn9274_host_ddr@4ed00000`(**50MB**).
- `&wifi0` (2.4G): `firmware-name = "ath12k/IPQ5332/hw1.0/q6_fw1.mdt", "…/iu_fw.mdt"`; `memory-region = <&q6_region>, <&m3_dump>, <&q6_caldb>, <&mlo_mem>`; `qcom,bdf-address-offset = <0x0c00000>`; `qcom,board-id = <18>`; `qcom,legacy-userpd-bootinfo`; `qcom,rproc = <&q6v5_wcss>`; `qcom,wsi-controller`; status okay.
- `&q6v5_wcss`: `firmware-name = "ath12k/IPQ5332/hw1.0/q6_fw0.mdt"`; status okay.
- `&pcie1` wifi1: `pci17cb,1109`; `memory-region = <&qcn9274_host_ddr>, <&mlo_mem>`; `qcom,ath12k-fw-memory-mode=<1>`; `qcom,board-id=<0x1019>`; `qcom,num-radios=<2>`; perst gpio47, wake gpio48.
- `&mdio` = qcom,ipq4019-mdio; `status="disabled"`, mdio1+mdio0 pins.

## 4. ipq53xx.mk (image) + config + base-files
- `glinet_gl-be9300`: FitImage+EmmcImage; `DEVICE_DTS_CONFIG := config-1` (stok U-Boot `config-1` arar); factory = `gl-be9300-factory` (mkits-qsdk bootscript); DEVICE_PACKAGES: `kmod-ath12k ath12k-firmware-ipq5332 ath12k-firmware-qcn9274 ipq-wifi-glinet_gl-be9300 kmod-hwmon-pwmfan kmod-qrtr-smd kmod-rtl837x-dsa kmod-phy-realtek ethtool e2fsprogs f2fsck mkf2fs dumpimage usb/block pkg`.
- config-6.18 kernel: `QCOM_Q6V5_WCSS_SEC=y`, `QCOM_MDT_LOADER=y`, `QCOM_PIL_INFO=y`, `QCOM_SCM=y`, `QCOM_SMEM=y`, `QCOM_SMEM_STATE=y`, `REMOTEPROC=y`, `REMOTEPROC_CDEV=y`, `RPMSG_QCOM_GLINK(+RPM/SMEM)=y`.
- `hotplug.d/firmware/12-ath12k-caldata`:
  - `ath12k/IPQ5332/hw1.0/cal-ahb-c000000.wifi.bin` → `caldata_extract "0:art" 0x1000 0x20000`
  - `ath12k/QCN9274/hw2.0/cal-pci-0001:01:00.0.bin` → `caldata_extract_mmc "0:ART" 0x58800 0x27800` (be9300; be6500 nand 0x18800)
- `uci-defaults/99-gl-be9300-wifi-macs`: ART offset **0x4**; be9300'e özel. `02_network`: be9300 → `lan1..4` + `wan`.

## 5. Firmware & board (flint3)
- `package/firmware/ath12k-firmware/src/IPQ5332/hw1.0/`: `q6_fw0.mdt`(11812B)+b00..b11, `q6_fw1.mdt`(4256B)+b00..02, `iu_fw.*`, `Data.msc`, `qdss_trace_config.bin`.
- `src/QCN9274/hw2.0/`: `regdb.bin`.
- `ipq-wifi/src/`: **yalnız `board-glinet_gl-be9300.ipq5332`(89292B) + `.qcn9274`(187596B)**; be6500 de var. **MR47BE board'u YOK → ekleyeceğiz.**

## 6. MR47BE ↔ FLINT3 FARK TABLOSU (kritik)

| Öğe | MR47BE (bizim) | Flint3 BE9300 | Yorum |
|---|---|---|---|
| q6_region | **0x2300000 = 35MB** | ipq5332.dtsi **0x2b00000 = 43MB** | **MUHTEMEL -12 KAYNAĞI (35 yanlış olabilir)** |
| m3_dump | 0x4cc00000 (1MB) | 0x4d400000 (1MB) | farklı adres |
| q6_caldb | 0x4cd00000 (5MB) | 0x4d500000 (5MB) | farklı adres |
| mlo | 0x4d200000 (**17MB**) | 0x4db00000 (**18MB**) | farklı |
| qcn9224 host-ddr | 0x4e300000 (**37MB**) | qcn9274 0x4ed00000 (**50MB**) | farklı |
| wifi0 board-id | **22** | **18** | GPL: 18 doğru (0x12) → **22 ŞÜPHELİ** |
| q6_fw0 | OpenWrt 11812 (test24) | flint3 11812 | aynı OpenWrt fw |
| q6_fw1/iu_fw | var | var | aynı yapı |
| wifi1 board-id | 0x1019 | 0x1019 | aynı |
| ath12k fw mem mode | 1 | 1 | aynı |
| Ethernet | QCA8084 entegre | RTL8372N DSA + RTL8221B | **ALAMAYIZ (farklı donanım) — MR47BE node korunacak** |
| LED/button GPIO | 31/24/15/32/33/34; reset 30/17 | 32/33; reset 17 | map farklı |
---

## 7. YAPILACAKLAR (sıralı, flint3-bazlı NEW BUILD)

1. **E:\WSL\flint3-mr47be-20260903** klonu hazır (flint3-be9300, tam). Bağımlılıkları `./scripts/feeds update -a; install -a` ile kur.
2. **MR47BE DTS'ini flint3 DTS'inden türet:** `dts/ipq5332-mr47be-v2.dts`:
   - `q6_region` → **0x2b00000 (43MB) dene**; m3_dump/caldb/mlo/qcn9224 adreslerini flint3 düzenine yaklaştır (0x4d400000 / 0x4d500000 / 0x4db00000 / 0x4ed00000).
   - `wifi0 board-id` → **18** (0x12) — dene; `bdf-address-offset = <0x0c00000>` koru.
   - Ethernet'i **MR47BE QCA8084 node'undan** koru (flint3 RTL'ini KOPYALAMA); ppe/port yapısı zaten çalışıyordu.
   - `02_network` → `mercusys,mr47be-v2` case ekle: lan/wan ayrımı.
3. **ipq-wifi:** `board-mercusys_mr47be-v2.ipq5332` + `.qcn9274` ekle (ART'tan: `E:\ROUTER\MERCUSYS MR47BE_OPENWRT\imajlar\test9\art_full.bin`). ALLWIFIBOARDS + generate + DEVICE_PACKAGES'a `ipq-wifi-mercusys_mr47be-v2`.
4. **caldata:** `12-ath12k-caldata`'ya `mercusys,mr47be-v2` case ekle (IPQ5332: mtd "0:art" 0x1000 0x20000; QCN9274: 0x58800 0x27800).
5. **Build:** menuconfig → Target qualcommbe/ipq53xx, Profile = MR47BE (yeni), DEVICE_DTS_CONFIG = **`config@mi01.6`** (MR47BE U-Boot bu adı ister), sonra `make -j4`.
6. **RAM boot:** `tftpboot 0x46000000 <itb>; bootm 0x46000000`.
7. Kriter: `dmesg`'te Q6 **auth_and_reset OK → remoteproc running → wlan0+wlan1+wlan2**; WAN DHCP internet.

## 8. AÇIK SORULAR / RİSKLER
- MR47BE GPL Q6 düzeni gerçekten **35MB** mu, yoksa **43MB** mu? (flint3/upstream 43MB kullanıyor; vendor DTS 0x2300000=35MB da vardı). → **35 yanlışsa -12 gelir; ilk testte 43MB dene.**
- `wifi0 board-id=22` nereden geldi? (upstream RDP441=18; GPL bdwlan.b12 board-id 0x12=18). → **22 yanlış olabilir.**
- Q6 fw: flint3 q6_fw0=OpenWrt 11812; vendor 15472 → hangisi -12'yi çözer? Denenmeyen kombosyon: **43MB + board-id 18 + OpenWrt fw + 3-arg(0606) + M3 + bootargs SMEM**.
- 0606 patch branch'te yok; findings'a göre **kendimiz yazacağız** (veya QSDK `qcom_q6v5_wcss_sec.c`'ten 3-arg'lı port).

## 9. YEDEK STRATEJİSİ (bundan sonra HER ZAMAN)
- **Çalışan her imaj/build** → `_yedekler/<tarih>_<test>/` kopyala + sha256sum.
- DTS/patch değişikliğinden ÖNCE yedek al (`cp file file.bak_<tarih>`).
- WSL log'ları düzenli `E:\ROUTER\router\GL-BE9300 (Flint 3)\_loglar\` kopyalanır.
- rsync `--exclude` her zaman **anchored** (`--exclude=/build_dir`, asla çıplak `bin`).



## 6. SBE1V1K REFERANS ANALİZİ — WIFI ÇALIŞAN KURULUM (2026-09-04)

### 6.1 Amaç
SBE1V1K (IPQ9570, QCN9274) çalışan wifi kurgusunu inceleyip, MR47BE (IPQ5322, QCN6274) için eksik/olan şeyleri bulmak. Sadece wifi değil — büyük resim (patch, DTS, board, base-files, config).

### 6.2 Patch karşılaştırması
İki ağaçtaki patch'ler **birebir aynı**: `target/linux/qualcommbe/patches-6.18/` 0301-0340 (QCA8084 + PCS + PPE/EDMA) + `target/linux/generic/` (nvmem, jiffies, mtd, spi, wireguard). **Patch eksikliği yok.**

### 6.3 Board dosyası karşılaştırması (strings, varsayımsız)
| Board | magic | string | data size | variant |
|---|---|---|---|---|
| **SBE1V1K** (çalışan) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=255,variant=Askey-SBE1V1K_1` (62B) | 0xf850 (63568) | ✅ 3 farklı variant (_1, _4, _2) |
| **MR47BE** (bizim) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=4121` (39B) | 0x27838 (161848) | ❌ YOK |
| **be9300** (çalışan) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=4121` (39B) | 0x27838 (161848) | ❌ YOK |

**Kritik bulgu:** be9300 (çalışan) ile MR47BE board'u birebir aynı string/size. Yani board-id=4121 be9300'de çalışıyor ama MR47BE'de çalışmıyor. **Tek fark board değil — DTS eşleşmesi.**

### 6.4 DTS wifi node karşılaştırması (büyük resim)
| Özellik | SBE1V1K (çalışan) | MR47BE (bizim) | be9300 (çalışan) |
|---|---|---|---|
| Eşleşme | `calibration-variant` + `nvmem MAC` | `board-id=0x1019` + `num-radios=2` | `board-id=0x1019` |
| WSI topolojisi | Üçgen (wifi1→wifi2→wifi3→wifi1) | İkili (wifi0↔wifi1) | İkili |
| MAC kaynağı | nvmem-cells (ethaddr -3/-1/-2) | YOK | YOK |
| qcom,wsi-controller | pcie2'de | sadece wifi0'da | sadece wifi0'da |
| PCIe sayısı | 3 (pcie1/2/3) | 1 (pcie1) + on-SoC Q6 | 1 (pcie1) |

### 6.5 Çıkarım
- SBE1V1K **variant tabanlı** eşleşme kullanıyor (DTS'teki `calibration-variant` → board'daki `variant=` ile eşleşir).
- be9300/MR47BE **board-id tabanlı** eşleşme kullanıyor.
- MR47BE board-id=4121 kullanıyor ama çalışmıyor → **QCN6274 firmware/board data eşleşmesi** farklı çalışıyor, veya DTS'de `calibration-variant` eksikliği var.

### 6.6 Yapılacak (sıralı)
1. MR47BE DTS wifi1 node'una SBE1V1K'dan `qcom,calibration-variant` ekle (değer: board dosyasındaki variant ile eşleşmeli — ama MR47BE board'unda variant yok, o zaman board dosyasına variant string eklenmeli veya SBE1V1K board'u kullanılmalı).
2. nvmem MAC ekle (ethaddr offset).
3. WSI topolojisini kontrol et (MR47BE'de ikili yeterli mi?).
4. Build + test (tftpboot 0x46000000; bootm 0x46000000 — MR47BE adresi bu, SBE1V1K farklı SoC).

### 6.8 FLINT3'TE QCN6274 PCIE LINK UP — BÜYÜK BULGU (2026-09-04)
- Flint3 imajında QCN6274 PCIe link up + driver bind olmuş:
  - `DRIVER=ath12k_wifi7_pci`, `OF_COMPATIBLE_0=pci17cb,1109`, `PCI_ID=17CB:1109`
- MR47BE'de hiç olmadı (MHI sessizliği)
- **Farkı bulmak lazım:** DTS wifi1/pcie1 node'u, board-id, calibration-variant, firmware, config
- Kullanıcı notu: "1105 muhabbeti ilk flint imajında da oldu" — eski live'da/bir yerlerde kayıtlı olmalı
- PCI subsystem = Qualcomm kendi ID'si (17cb:1109) = Qualcomm referans tasarımı

### 6.7 mr47be_ÇOK YAKIN Cihazlar.md özeti (2026-09-04)
- QCN6274 wifi: Flint 3 board-id=0x1019 çalışıyor, MR47BE vendor'da 0x1015 — bu farkı test et (şu an DTS'te 0x1019).
- QCA8084 Ethernet: mainline'da YOK, ess-switch-qca8386 (qca-ssw) sürücüsü şart. Compex AP.MI01.2 veya Wallys DR5322S GPL'lerinde var — avla.
- En yakın cihaz: Deco BE65 v2 (IPQ5322 + QCA8386).


### 8. PPE PATCH'LERİ MR47DE'DE ZATEN VAR (2026-09-04)
- 0370: EDMA reset controls (IPQ5332) ✅
- 0371: XGMAC TX queue store-and-forward ✅
- 0372: Wake Tx queue paired with ring ✅
- 0374: Close Tx queue stop/wake race ✅
- Sonuç: PPE TX FIFO fix'i zaten uygulanmış — sorun başka yerde (switch config? PHY?)

### 9. perceiveival forum/TOH bulguları (özet)
- Flint3 LAN/WAN 1.8-1.9 Gbps çalışıyor
- WAN RTL8221B USXGMII: inband-status çalışmıyor → MDIO polling
- WiFi: MLO mask patch gerekiyor (bağımsız wiphy)
- Switch: RTL8372N DSA, CPU port IVL/SVL=1 FID/MSTI=1 şart
- eth1 WAN link up ama veri akamıyor → PPE RX FIFO overrun (known issue)

### 12. WAN/LAN KARIŞIKLIĞI — DSA PORT SORUNU (2026-09-04)
- MR47DE'de WAN portu (mavi) bulunamıyor bazı imajlarda
- LAN1 WAN olarak algılıyor
- LAN2, LAN3 ölü
- Flint3'te LAN1=LAN1, WAN=WAN çalışıyor (portlar doğru)
- **Sorun kaynağı:** QCA8084 switch port mapping + DSA tanımı
- **Flint3:** RTL8372N DSA switch (portlar ayrı netdev: lan1/lan2/lan3/wan)
- **MR47BE:** QCA8084 switch (port@1=wan, port@2=lan — ama switch DSA değil?)
- **Çözüm araştırılacak:** QCA8084 DSA port tanımları / ess-switch sürücüsü / U-Boot switch config

### 10. QCA8084 SWITCH ARAŞTIRMASI (2026-09-04)
- ess-switch-qca8386 (qca-ssw) sürücüsü Deco BE65_V2_GPL'de bulunamadı (sadece "passwd" dosyaları — ilgisiz)
- GitHub code search giriş gerekiyor, sonuç vermedi
- Forum search sonuç vermedi
- QCA8084 switch = Qualcomm kapalı kaynak ess-switch sürücüsü gerektirir
- ess-switch sürücüsü olmadan switch fabric çalışmaz → veri akmaz
- **Sonuç:** Ethernet için ek sürücü gerekebilir ama kapalı kaynak → QSDK/Compex/Wallys GPL'lerinde aramalı

### 11. YAPILACAKLAR SIRALAMASI
1. Test29-luci build bitince test (tftpboot 0x46000000; bootm)
2. Ethernet çalışırsa → WiFi için ath12k MLO mask patch'i ara
3. Ethernet çalışmazsa → ess-switch sürücüsü ara (Compex AP.MI01.2 / Wallys DR5322S GPL)
- Watchdog disabled, procd integration lazım
- MR47BE'ye uygulanabilir: PPE patch'leri (zaten var), MLO mask (ath12k)
- Uygulanamaz: RTL8221B WAN (MR47BE'de yok), RTL8372N switch config (MR47BE QCA8084 kullanır)

## 7. TEST29 + LUCI EKLENDİ (2026-09-04)

### 7.1 Luci paketleri eklendi
- `CONFIG_PACKAGE_luci=y`
- `CONFIG_PACKAGE_luci-app-attendedsysupgrade=y`
- `CONFIG_PACKAGE_luci-theme-bootstrap=y`
- `CONFIG_PACKAGE_luci-proto-ipv6=y`
- Eklenmedi: rtl826x-firmware, kmod-phy-realtek, kmod-hwmon-pwmfan (SBE1V1K'ya özel, MR47BE'de QCA8084 ethernet zaten çalışıyor)

### 7.2 Build durumu
- Build başlatıldı: `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test29-luci.log`
- defconfig case-sensitivity hatası (NTFS) → doğrudan build başlatıldı

### 7.3 SBE1V1K imajından çıkan paketler (analiz)
- SBE1V1K: luci + attendedsysupgrade + rtl826x-firmware + kmod-phy-realtek + kmod-hwmon-pwmfan
- MR47BE'ye eklenen: luci + attendedsysupgrade (ethernet zaten çalışıyor, ek paket gerekli değil)
- SBE1V1K IPQ9570 için, MR47BE IPQ5322 için — rtl826x-firmware SBE1V1K'ya özel (RTL8261BE PHY)

## 7. TEST29 — FLINT3 REFERANS KARŞILAŞTIRMASI + BUILD (2026-09-04)

### 7.1 Test29 build durumu
- Build başlatıldı: `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test29.log`
- Board-id = **0x1019** (doğru değer, Flint3 ile aynı, çalışan değer — vendor 0x1015 gösteriyordu ama Flint3'te çalışan 0x1019)
- Backup: `ipq5332-mr47be-v2.dts.bak_prebuild29_20260904`

### 7.2 Flint3 BE9300 vs MR47BE DTS karşılaştırması (büyük resim)
| Özellik | MR47BE | Flint3 (çalışan) | Fark? |
|---|---|---|---|
| q6_region | 0x4a900000, 43MB | yok (farklı adres) | evet |
| q6_caldb | 0x4d500000, 5MB | 0x4d500000, 5MB | aynı |
| mlo_mem | 0x4db00000, 18MB | 0x4db00000, 18MB | aynı |
| qcn host_ddr | **qcn9224**, 0x4ed00000, 50MB | **qcn9274**, 0x4ed00000, 50MB | sadece isim |
| board-id (wifi1) | 0x1019 | 0x1019 | aynı |
| num-radios | 2 | 2 | aynı |
| calibration-variant | YOK | YOK | aynı |
| fw-memory-mode | 1 | 1 | aynı |
| WSI topolojisi | İkili (wifi0↔wifi1) | İkili (wifi0↔wifi1) | aynı |

**Sonuç:** DTS'ler birebir aynı yapıda. Tek fark `qcn9224` vs `qcn9274` etiketi (önemsiz). **Patch'ler de birebir aynı** (0301-0340 + generic). Yani DTS/patch eksikliği yok.

### 7.3 QCN6274 PCIe link up bulgusu (1105)
- Flint3 imajında QCN6274 PCIe link up + driver bind olmuş:
  - `DRIVER=ath12k_wifi7_pci`, `OF_COMPATIBLE_0=pci17cb,1109`, `PCI_ID=17CB:1109`
- MR47BE'de hiç olmadı (MHI sessizliği)
- PCI subsystem = Qualcomm kendi ID'si (17cb:1109) = Qualcomm referans tasarımı
- Kullanıcı notu: "1105 muhabbeti ilk flint imajında da oldu" — eski live'da/bir yerlerde kayıtlı olmalı

### 7.4 Çıkarım
- DTS/patch aynı + board-id aynı + calibration-variant ikisinde de yok
- **Flint3'te QCN6274 çalışıyor, MR47BE'de çalışmıyor** → fark ne?
- Olası farklar:
  1. Board dosyası içeriği (binary, 161KB vs 161KB aynı boyut ama içerik farklı olabilir)
  2. Firmware/caldata (ART offset)
  3. Kernel config
  4. PCIe PHY/clock init
  5. reserved-memory boyutları (aynı)

### 7.5 Yapılacak sıralı
1. Test29 build bitince test: `tftpboot 0x46000000 <itb>; bootm 0x46000000`
2. QCN6274 PCIe link up olursa → wifi çalışıyor demek
3. Hâlâ sessizse → calibration-variant + nvmem MAC ekle (SBE1V1K referansı)
4. Board dosyası karşılaştırması (binary diff) — gerekirse

### 7.6 ÖNEMLİ NOT — Ne yaptığını bilmelisin" bilinmeli
- Sed ile board-id'i yanlışla 0x1015'e çevirmiştim → **geri aldık, 0x1019'da kalıyor** (doğru değer)
- PowerShell tırnak kaçışı sorunu yüzünden editör/sed komutları çoğu zaman çalışmadı → WSL'de doğrudan `cp`/`grep` kullanmak daha güvenilir
- rsync `--exclude=bin` (anchorsız) TÜM bin/ siler → `--exclude=/bin` kullan
- DTS'te `#` yorum DEĞİL; `/* */` kullan
- WSL segfault'u: `/mnt/e` (NTFS) üzerinde ağır taramalar (find/grep -r) segfault yapabilir → Windows tarafından oku/ara

mr47be ye benzeyen router paralel projeler;
SBE1V1K OpenWrt (v1)

> **TEK KAYNAK.** Her oturumda ilk iş: bunu oku + `BUILD_INFO.md`.
> **Proje kararı (2026-09-04):** MR47BE/flint3 portu KAPATILDI (test28 dahil — sgmii veriyi açmadı; kök eksik = QCA8386/ess-switch sürücüsü, GPL'lerde kapalı, mainline'da yok). Yeni alan: **SBE1V1K (IPQ9570)** — burada build/test edilip proje kapatılacak.

## 1. DURUM ÖZETİ
- **Hazır imajlar diskte** (build gerekmiyor):
  - `SBE1V1K LEDE Openwrt\` = **r7867-7aeb8ceff2**, LEDE(coolsnowwolf)+passwall feeds; 3 imaj + manifest + buildinfo + **sha256sums — Windows Get-FileHash ile BİREBİR doğrulandı**:
    - initramfs-uImage.itb → `d9ac6132d562affdd6abf6745724367668895b80445d0a69a7096b694a77b7a5` (66 531 656 B)
    - squashfs-factory.bin → `78c20352e117c3e3537f90116fa6c20c2aa4e1adcfc3433fd5a1e53000a465da`
    - squashfs-sysupgrade.bin → `4f2708472b16bd4260b36ab06cd77cce12ee75bd765fe05616b6d4b5ce2ecdcd`
  - `Spectrum SBE1V1K Openwrt\` = daha eski/küçük build; initramfs 19 022 856 B (TFTP için hızlı), sha'sız.
- **Depo:** `SBE1V1K -main GITHUB DEPOSU\` (luckkyboy main; `configs/sbe1v1k.config` mevcut; README'de build adımları doğrulandı). `imajlar\` şu an BOŞ.

## 2. SIRADAKİ ADIM (test — "flint3 gibi")
1. Cihazı aç: 1.8V UART + eMMC glitch → U-Boot prompt. PC: `192.168.1.2/24`, TFTP sunucu, initramfs.itb root'ta.
2. `setenv ipaddr 192.168.1.1; setenv serverip 192.168.1.2; tftpboot 0x80000000 <initramfs.itb>; bootm 0x80000000` — **saveenv YOK**.
3. Kriterler: `ubus call system board` → Askey SBE1V1K · `ip -br link` → 4 ethernet (10G/2.5G/1G×2) · `iw dev` + `wifi status` → **3 radio (2.4 QCN6214 + 5/6 QCN6274)** · `dmesg | grep -Ei 'ath12k|qca8081|rtl826|pwm|error|fail'` · ssh `root@192.168.1.1`.
4. Sonuçları `imajlar/<tarih>_sbe1v1k/boot-raporu.md`'ye yaz (dmesg + ip + wifi özeti).

## 3. AÇIK NOKTALAR / RİSKLER
- Hangi imaj? Önce **Spectrum 19 MB initramfs** (glitch-TFTP için hızlı) → sonra istenirse LEDE r7867 (sha doğrulandı). Sysupgrade için SADECE sha'lı LEDE setini kullan.
- Chainloader lokalde YOK (`sbe1v1k-chainloader.itb` = release 260720, sha `2aad05c1…5d702`, https URL'i BUILD_INFO §3 / UBOOT.md). Glitch'ten kaçınmak istersen bu opsiyon.
- PPE/NSS hızlandırma yok (software routing) — beklentiyi ona göre ayarla.
- MR47BE donanımına ASLA flash etme (farklı SoC).

## 4. BİLİNEN DERSLER (taşınanlar)
- `setsid nohup … &` şart; rsync `--exclude=/bin` anchored; WSL segfault → Windows tarafından oku/ara; build ext4 (`/root` veya `/mnt/wsl`), E: sadece cp ile.
- Image kopyalama sonrası her zaman ya `Get-FileHash` ya `sha256sum -c` doğrula.

## 5. İTB FORENZİK + RAM BOOT REÇETESİ (2026-09-04 — "ELMA/ARMUT" AYRIMI)

### 5.1 İki imajın gerçek kimliği (mkimage -l ile çözüldü)
| İmaj | Kernel | Gzip | Yapı | Load/Entry | FIT config | Durum |
|---|---|---|---|---|---|---|
| `SBE1V1K LEDE Openwrt\...initramfs-uImage.itb` (66 531 656 B) | **6.12.95** | 66 494 458 B (**63.4 MiB — initramfs gömülü**, "fat") | 2026-07-23 | `0x42080000` | `config@rtq7300t-rev0` | sağlam FIT (magic `d0 0d fe ed`), sha doğrulandı |
| `Spectrum SBE1V1K Openwrt\...initramfs-uImage.itb` (19 022 856 B) | **6.18.44** (mainline köken) | 18 985 474 B (~18 MiB, küçük initramfs) | 2026-09-03 | `0x42080000` | `config@rtq7300t-rev0` | sağlam FIT |

İkisi de AYNI config adını (`config@rtq7300t-rev0`) ve AYNI yükleme adresini (`0x42080000`) kullanıyor. DTB: `askey_sbe1v1k`. **LEDE = adamların kendi 6.12.95 "fat initramfs" build'i; Spectrum = 6.18.44 mainline-tarzı.**

### 5.2 RAM boot NEDEN açmadı (kullanıcı testi: yüklendi, sonra restart → stok)
Kök neden: **gzip decompress çakışması.** Kernel gzip, U-Boot tarafından `load 0x42080000`'e açılır:
- LEDE 63.4MB → çıktı aralığı `0x42080000..0x46300000+`. İmajı DÜŞÜK bir adrese yüklediysen (örn. `0x44000000` veya `0x46000000` — MR47BE alışkanlığı), **çıktı, hâlâ okunması gereken kaynağın üstüne biner** → kernel bozuk → anında crash → watchdog → stok'a dönüş. (Kullanıcının gördüğü tam olarak bu.)
- Çözüm: imajı **yüksek adrese** yükle; `0x80000000` (chainloader belgesinin de kullandığı adres):
  ```
  setenv ipaddr 192.168.1.1
  setenv serverip 192.168.1.2
  tftpboot 0x80000000 <initramfs-uImage.itb>
  bootm 0x80000000
  ```
  Kaynak `0x80000000..0x84200000` çıktı `0x42080000..0x46370000` ile ÇAKIŞMAZ → güvenli.
- **Not:** `do_boot`'taki `mmc read 0x44000000 ...; bootm 0x44000000` adresi eMMC'den okunan **küçük sysupgrade FIT** için geçerli; 63MB initramfs için DEĞİL.

### 5.3 Sıradaki test için tavsiye
- **Önce Spectrum 6.18.44 (19 MB)** ile dene — küçük, TFTP hızlı, aynı config/adres; `tftpboot 0x80000000; bootm 0x80000000`.
- UART'ı **bootm anında** yakala: "Verifying Hash Integrity ... OK" → "Loading ... boot_get_kernel" → "Uncompressing Kernel" → "Starting kernel ..." — nerede kopuyor görelim. (Kernel'e girip panic oluyorsa o ayrı bir konu; ama önce adres hatası elensin.)
- **saveenv YOK**, hiçbir kalıcı yazma yok.

### 5.4 ELMA/ARMUT UYARISI (geçerli)
- `SBE1V1K LEDE Openwrt` = **adamların orijinal build'i** — DOKUNMA, build etme.
- `SBE1V1K -main GITHUB DEPOSU` = luckkyboy main (6.18 tabanlı kaynak; Spectrum imajı bu kökene yakın). Kaynak iken imaj DEĞİL.
- `MR47BE/flint3` = kapandı; bu projeyle ilgisiz; adresler/SoC farklı.

## 6. GÜVENLİ TEST POLİTİKASI + ADRES (2026-09-04 — SIKI ANALİZ)

- **Kullanıcı kararı geçerli:** sadece RAM-only deneme; itb'yi kalıcı yazma yok; `saveenv` YOK; cihaza komutları KULLANICI kendi UART konsolundan yazar; ben komut blokları HAZIR verip çalıştırmam (kullanıcı sadece alıntı için isteyebilir).
- **Adres matematiği (load 0x42080000) — sıkı:**
  - gzip, imajın yüklendiği adresten `0x42080000`'e açılır; imajın yüklendiği adres, açılan çıktının TEPESİNE denk gelmemeli.
  - LEDE (63.4 MB): üst sınır ≥ ~`0x84000000` → **`0xA0000000`** (güvenli).
  - Spectrum (18.1 MB): üst sınır ≥ ~`0x54000000` → **`0x90000000`**; alternatif `0x88000000`.
  - **`0x46000000` HEM LEDE hem Spectrum için YETERSİZ** (63.4 MB gzip 0x42080000'e açılınca 0x46000000'i ezer) → "yüklendi ama stok'a döndü" = imaj değil, adres.
- **Hedef:** önce Spectrum (19 MB, TFTP hızlı) `0x90000000`; sonra LEDE `0xA0000000`.
- Kısıtlar/yapılmadı: qemu yok; SBE1V1K full backup yok → yalnız RAM-only; netboot/PPP bios önerilmez.

## 7. MR47BE UYARLAMASI (değişecek dosyalar)
| Dosya | İşlem |
|---|---|
| `target/linux/qualcommbe/dts/ipq5332-mr47be-v2.dts` | flint3 `ipq5332-gl-be9300.dts` kopyala + MR47BE'ye çevir (model, compat, LED, GPIO, Ethernet=QCA8084, q6_region boyutu, board-id) |
| `target/linux/qualcommbe/image/ipq53xx.mk` | `Device/mercusys_mr47be-v2` ekle (FitImage/UbiFit, DEVICE_DTS_CONFIG=config@mi01.6, IMAGES=initramfs+factory/sysupgrade) |
| `target/linux/qualcommbe/ipq53xx/base-files/etc/board.d/02_network` | `mercusys,mr47be-v2` case (lan/wan) |
| `target/linux/qualcommbe/ipq53xx/base-files/etc/board.d/01_leds` | LED eşleme |
| `target/linux/qualcommbe/ipq53xx/base-files/etc/hotplug.d/firmware/12-ath12k-caldata` | `mercusys,mr47be-v2` case (caldata offset) |
| `package/firmware/ipq-wifi/src/board-mercusys_mr47be-v2.ipq5332` + `.qcn9274` | ART'tan çıkar (test9 art_full.bin) |
| `package/firmware/ipq-wifi/Makefile` | ALLWIFIBOARDS + generate satırı |
| `target/linux/qualcommbe/patches-6.18/0606-...` | QSDK 3-arg PAS auth patch (bulgu; branch'te yok — gerekli) |

## 8. MR47BE KRİTİK DTS KARARLARI (ilk test denemesi)
```dts
reserved-memory {
    q6_region: wcss@4a900000 { reg = <0x0 0x4a900000 0x0 0x02b00000>; };  /* 43MB DENENECEK */
    m3_dump:  m3-dump@4d400000  { reg = <0x0 0x4d400000 0x0 0x100000>; };
    q6_caldb: q6-caldb@4d500000 { reg = <0x0 0x4d500000 0x0 0x500000>; };
    mlo_mem:  mlo-global-mem@4db00000 { reg = <0x0 0x4db00000 0x0 0x01200000>; }; /* 18MB */
    qcn9224_host_ddr: qcn9224-host-ddr@4ed00000 { reg = <0x0 0x4ed00000 0x0 0x03200000>; }; /* 50MB */
};
&wifi0 { qcom,board-id = <18>; ... };   /* 22 YERİNE 18 */
&q6v5_wcss { firmware-name = "ath12k/IPQ5332/hw1.0/q6_fw0.mdt"; };
```
> Not: MR47BE vendor GPL'de 35MB (0x2300000) **da** gördük. İlk test 43MB + board-id 18. Eğer TZ yine -22 verirse 3-arg auth (0606) ekle.

## 9. BİLİNEN HATALAR / DERSLER
- DTS'te `#` yorum DEĞİL; `/* */` kullan.
- rsync `--exclude=bin` (anchorsız) TÜM bin/ siler → `--exclude=/bin` kullan.
- `setsid nohup make &` şart; nohup tek başına ölür.
- İmaj kopyalama her zaman python/script ile (WSL watcher ölüyor).
- DEVICE_DTS `mercusys_mr47be-v2` → build `ipq5332-mr47be-v2.dts` arar; dosya adını doğru koy.
- 6.18.39 devam; .44/.48'e çıkma yok (patch set kırılır).

## 10. YEDEK
- Çalışan her imaj/build → `"E:\ROUTER\router\Askey SBE1V1K\imajlar"\<tarih>_<test>\`
- DTS/patch değişikliği öncesi `cp file file.bak_<tarih>`.




## 11. TEST25 DURUMU (2026-09-03 gece — hedef: 5/6G + WAN/LAN, 2.4G bırakıldı)
- [x] gpio -16 fix: `dts/ipq5332-mr47be-v2.dts` satır 146 `tlmm 30` → `tlmm 17` (doğrulandı)
- [ ] 0606 3-arg PAS patch: ERTELENDİ (2.4G bırakıldı; Q6 -22/-12 kalsa da PCIe etkilenmez)
- [ ] defconfig: Profile `mercusys_mr47be-v2` seçildi, tuttu (`CONFIG_TARGET_PROFILE="DEVICE_mercusys_mr47be-v2"`)
- [x] build BAŞLADI (2026-09-03 ~20:55): `/root/flint3-mr47be-20260903` (ext4, C: doluluğundan etkilenmez),
  `make -j4 V=s`, log: `_loglar/build-test25.log` (prereq aşaması doğrulandı, log büyüyor)
- [x] DERS: root ile build'de `tools/tar` configure "should not run as root" → Error 2.
  Çözüm: `FORCE_UNSAFE_CONFIGURE=1` ile relaunch (~21:18, PID 448, çalışıyor).
- [x] BUILD BİTTİ (2026-09-03 23:27, hatasız — checksum aşamasına geldi):
  initramfs 22155992 B (sha `bea808af…`), factory/bin+ubi 20578304 B, sysupgrade 19527973 B, uImage 6013952 B
- [x] KOPYALANDI → `imajlar/test25/` (7 dosya: 5 imaj + manifest + test25-sha256.txt)
- [ ] RAM boot + kriter: gpio -16 YOK; PCIe `qcn9274 hw2.0` → `wlan1/wlan2`;
      WAN DHCP (upstream 192.168.0.x) internet; `passwd root` sonrası SSH.
## 12. TEST26 (2026-09-04 ~01:01 — hedef: QCA8084 + SSH)
- [x] 0312a patch portlandı + temiz uygulandı (4 hunk, offset'li)
- [x] `make target/linux/clean` + rebuild BAŞLADI (PID 1055, log `_loglar/build-test26.log`)
- [x] BUILD BİTTİ (2026-09-04 ~02:27, hatasız — checksum aşaması geçildi)
- [x] KOPYALANDI → `imajlar/test26/` (5 imaj + test26-sha256.txt; initramfs sha `9abb680f…`)
- [x] Manifest ✓: kmod-ath12k + ath12k-firmware-ipq5332/qcn9274 + ipq-wifi-mercusys_mr47be-v2 imajda VAR
  → test25'teki MHI sessizliği fw eksikliği DEĞİL.
- [ ] RAM boot + kriter: mdio-1:01-04 probe OK (QCA8084, ID `004dd180`), `wan`/`lan` netdev,
      `dmesg | grep -iE 'mhi|qmi|bdf|cal'` → MHI/fw zinciri nerede duruyor,
      `ls /lib/firmware/ath12k/QCN9274/hw2.0/` + cal-pci bin yazıldı mı,
      `passwd root` → SSH; WAN DHCP (upstream 192.168.0.x) internet.
- NOT: E: klon NTFS case-insensitive → build orada ÖLÜR. Build ağacı `/root/flint3-mr47be-20260903`.
  DTS/patch değişikliği iki tarafa da aynalanacak.

## 13. VENDOR MİMARİ GERÇEĞİ (2026-09-04 — GPL `kernel-ipq5332-mi01.6.dts` okundu; 4 deliğin sırrı)
- **Stokta 4 port = QCA8084'ün DAHİLİ L2 SWITCH'i** (`ess-switch1@1`, `compatible="qcom,ess-switch-qca8386"`, `switch_access_mode="mdio"`). Vendor'da da SADECE 2 MAC/netdev (aliases: dp1=LAN/MAC2@0x3a504000 is_switch_connected=1, dp2=WAN/MAC1@0x3a500000).
- Switch haritası: `cpu_bmp=0x21` (port0+port5 = 2 SerDes uplink, forced 2500 → MAC2+MAC1) · `lan_bmp=0x1c` (port2/3/4 = PHY addr2/3/4 = LAN1/2/3) · `wan_bmp=0x2` (port1 = PHY addr1 = WAN jakı). "MHT port ring #20-23" IRQ'ları bu switch'in; dp'ler `qcom,mht-dev=1`.
- **ÖNCEKİ BULGULARIN AÇIKLAMASI:** test26 WAN link ✓ / DHCP offer ✗ → copper link MDIO polling'inden görünüyor ama veri switch fabric'ten geçmeli; switch sürücüsü mainline'da YOK → portlar izole. Test11a'daki "nadir" LAN SSH = U-Boot'un bıraktığı default bridge'ten sızma (güvenilmez). test27 MAC2↔PHY4 aynı duvara toslayabilir (bedava deneme).
- **GERÇEK ÇÖZÜM:** `ess-switch-qca8386` (qca-ssw) sürücüsünü mainline 6.18'e port etmek. Kaynak yerleşimi GPL'de teyit edilecek (kernel ağacında `drivers/net/ethernet/qualcomm/` sadece emac/qca_spi içeriyor — sürücü ayrı pakette ya da prebuilt olabilir).
- Vendor DTS detayları: mdio 4 PHY (addr1-4) · `phy-reset-gpio = <&tlmm 16>` · `link-intr-gpio = <&tlmm 17>` · `switch_mac_mode=0xc` (her iki uniphy) · dp phy-mode="sgmii" · `phyaddr_fixup=<0xC90F018>` · LED: wan=31, lan1=24, lan2=39, lan3=32, green=33, orange=34 · wifi0 board_id=0x16 (22), wifi2 board_id=0x1015.

## 14. TEST25 SONUCU (2026-09-04 — ek rapor dahil)
- gpio -16 YOK (gpio17 fix ✓) · Q6 -22 (beklenen; 2.4G bırakıldı) · `network.wan` conf ✓ (device='wan', proto=dhcp).
- PCIe: Root Port `[17cb:1005]` = SoC kök portu (wifi DEĞİL) + EP `[17cb:1109]` = QCN62xx/92xx ortak ID
  (çip = QCN6274, marking `JE510CV2`) → probe ✓ `qcn9274 hw2.0` + MSI16 ✓ — ama MHI/fw başlamadı → wlan1/2 yok.
- YENİ BLOKER: QCA8084 4× PHY probe `-22` (log 406-409) → `PPE port 1 phylink -EINVAL` → WAN/LAN dead. test26 0312a hedefi.

## 15. TEST27 (2026-09-04 — hedef: LAN1 canlı + WAN'ı koru)
- test26 UART analizi: QCA8084 probe OK (0312a ✓, mdio-1:01 attach) · WAN MAC1↔addr1 İLK KEZ doğru jak (çek/tak link tepkisi) · ama WAN DHCP offer YOK (udhcpc discover döngüsü) · LAN MAC2 fixed-link veri taşımıyor · UART local ping 192.168.1.1 %100 loss · wlan yok (MHI/fw zinciri tam sessiz; fw imajda VAR — kmod-ath12k, fw-ipq5332/qcn9274, dropbear, firewall4 manifest'te ✓).
- KANIT ZİNCİRİ: test11a (SSH dönemi) MAC2↔phy3/addr4 hattı canlıydı (kullanıcı: LAN1 jakına takılınca "wan" tepki veriyordu) + test20 kaydı "addr4 = LAN1" → **LAN1 jakı = PHY addr4**.
- DTS değişikliği (test26 → test27): port@2 `fixed-link` KALDIRILDI → `phy-handle = <&phy3>` (addr4). WAN port@1 (MAC1↔phy0/addr1) DOKUNULMADI.
- LAN2/3 (addr2/3): IPQ5332'de 2 MAC (biri WAN'da); QCA8084 L2 switch sürücüsü mainline'da yok → LAN1 bu build'de, LAN2/3 switch sürücüsü portu sonraki büyük aşama.
- Build başlatıldı: `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test27.log`. Bitince imajlar → `imajlar/test27/`.
## 11. ETHERNET VERİ YOLU — BE6500/SBE1V1K REFERANS BULGULARI (2026-09-04)

- **test27 UART ✓ (büyük ilerleme):** `lan: PHY mdio-1:04 QCA8084` attach ✓ · LAN1 link up/down PHY-event ✓ (log 333/425-429) · UART içi ping 192.168.1.1 %0 loss (test26 %100) · `ethtool lan` 1000Mb/s PHYAD4 ✓. MAC2↔addr4 donanımda canlı; kalan = PC→router veri (ARP/DHCP) + SSH.
- **BE6500:** QCA8084 = SADECE WAN PHY (`phy-mode="usxgmii"`), LAN = **RTL837x DSA switch**. ⇒ MR47BE WAN phy-mode adayı **usxgmii**; QCA8084'ün 4-port switch kullanımı BE6500'de yok.
- **SBE1V1K (Askey, ipq95xx/IPQ9570):** Ethernet QCA8084 değil — qca8075(qsgmii) lan2/3 + qca8081/rtl8261(usxgmii) lan1/wan, ayrı MAC/PHY, switch yok. **QCN9274 WiFi referansı:** board-askey_sbe1v1k.qcn9274 + ath12k-firmware-qcn9274 + 3 radyo, caldata `0:ART 0x58800/0x8a800/0xbc800` (MR47BE 0x58800 ile aynı başlangıç), `qcom,calibration-variant`. Patch seti flint3 ile aynı.
- **QXGMII modu:** 0311/0320 = "QCA8084 four ports 2.5G PHYs" için → MR47BE MAC2/LAN SerDes tarafı; DTS referansında kullanan yok (vendor sgmii, be6500/sbe1v1k usxgmii). Değerlendir: MR47BE hangi SerDes modu (SGMI usxgmii/QXGMII)?
- **test28 önerisi:** `wan phy-mode` 2500base-x → **usxgmii** (WAN DHCP hedefi; at93xx/at803x upstream destekliyor). LAN (is_switch_connected=1) gerçek çözüm = `ess-switch-qca8386` sürücü portu (Deco BE65_V2_GPL QCA8386 kaynağı).
- KORUNAN BULGU: LAN veri yolu phy-mode'la açılmaz; switch fabric + ssw sürücü gerekli.

## 16. TEST28 (2026-09-04 — DTS HAZIR; kök neden = RTL kopyası phy-mode`2500base-x`)hedef: LAN1 canlı + WAN'ı koru
aynı bok bişey değişmedi.

- **Kanıt (vendor GPL DTS, satır 178/191):** dp1=LAN `phy-mode="sgmii"` + `qcom,is_switch_connected=<1>`** dp2=WAN `phy-mode="sgmii"`** `ess-switch@3a000000` `switch_mac_mode=<0xc>` (hem inst0 hem inst1**. Bizdeki `2500base-x` be9300'ün RTL8221B'sinden kalma — **MR47BE'de YANLIŞ**;test27 log'undaki `configuring for phy/sgmii` satırı da çipin sgmii tercihini gösteriyordu.

- **Değişiklik(2 satır, jak eşlemesi KORUNDU:** port@1 (wan): phy-mode→`"sgmii"` (phy-handle=&phy0/addr1 aynen) · port@2 (lan): phy-mode→`"sgmii"` (phy-handle=&phy3/addr4 aynen(.). LED/GPIO/wifi/mem aynısında bakup: `.bak_test28_20260904` (iki ağaçta da; E: + /root?.



- **Beklenti:** WAN DHCP offer gelebilir** MAC↔switch uplink artık doğru modda; WAN'ın da switch arkasında olduğu unutulmamalı** LAN1 PC ping'i cevap verirse **veri yolu ilk kez açıldı** demektir; LAN2/3 switch fabric** U-Boot default( üzerinden canlı gelebilir((ayrı netdev OLARAK DEĞİL, br-lan→lan üstünden).
- **Build:** `/root/flint3-mr47be-20260903` `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test28.log` → `imajlar/test28/`.
- RAM boot kriterleri: ① `dmesg | grep -iE 'qca8084|mdio'` → mdio-1:04 de attach (LAN1 PHY) ② PC LAN1 jakına takılı + `ping 192.168.1.1` PC'den → cevap ③ `ssh root@192.168.1.1` (şifre boş) ④ WAN DHCP offer ⑤ `dmesg | grep -iE 'mhi|qmi|bdf'` (wifi teşhisi, değişmedi).

## 17. SBE1V1K REFERANS ANALİZİ — WIFI ÇALIŞAN KURULUM (2026-09-04)

### 17.1 Amaç
SBE1V1K (IPQ9570, QCN9274) çalışan wifi kurgusunu inceleyip, MR47BE (IPQ5322, QCN6274) için eksik/olan şeyleri bulmak. Sadece wifi değil — büyük resim (patch, DTS, board, base-files, config).

### 17.2 Patch karşılaştırması
İki ağaçtaki patch'ler **birebir aynı**: `target/linux/qualcommbe/patches-6.18/` 0301-0340 (QCA8084 + PCS + PPE/EDMA) + `target/linux/generic/` (nvmem, jiffies, mtd, spi, wireguard). **Patch eksikliği yok.**

### 17.3 Board dosyası karşılaştırması (strings, varsayımsız)
| Board | magic | string | data size | variant |
|---|---|---|---|---|
| **SBE1V1K** (çalışan) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=255,variant=Askey-SBE1V1K_1` (62B) | 0xf850 (63568) | ✅ 3 farklı variant (_1, _4, _2) |
| **MR47BE** (bizim) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=4121` (39B) | 0x27838 (161848) | ❌ YOK |
| **be9300** (çalışan) | QCA-ATH12K-BOARD | `bus=pci,qmi-chip-id=0,qmi-board-id=4121` (39B) | 0x27838 (161848) | ❌ YOK |

**Kritik bulgu:** be9300 (çalışan) ile MR47BE board'u birebir aynı string/size. Yani board-id=4121 be9300'de çalışıyor ama MR47BE'de çalışmıyor. **Tek fark board değil — DTS eşleşmesi.**

### 17.4 DTS wifi node karşılaştırması (büyük resim)
| Özellik | SBE1V1K (çalışan) | MR47BE (bizim) | be9300 (çalışan) |
|---|---|---|---|
| Eşleşme | `calibration-variant` + `nvmem MAC` | `board-id=0x1019` + `num-radios=2` | `board-id=0x1019` |
| WSI topolojisi | Üçgen (wifi1→wifi2→wifi3→wifi1) | İkili (wifi0↔wifi1) | İkili |
| MAC kaynağı | nvmem-cells (ethaddr -3/-1/-2) | YOK | YOK |
| qcom,wsi-controller | pcie2'de | sadece wifi0'da | sadece wifi0'da |
| PCIe sayısı | 3 (pcie1/2/3) | 1 (pcie1) + on-SoC Q6 | 1 (pcie1) |

### 17.6 Çıkarım
- SBE1V1K **variant tabanlı** eşleşme kullanıyor (DTS'teki `calibration-variant` → board'daki `variant=` ile eşleşir).
- be9300/MR47BE **board-id tabanlı** eşleşme kullanıyor.
- MR47BE board-id=4121 kullanıyor ama çalışmıyor → **QCN6274 firmware/board data eşleşmesi** farklı çalışıyor, veya DTS'de `calibration-variant` eksikliği var.

### 17.6 Yapılacak (sıralı)
1. MR47BE DTS wifi1 node'una SBE1V1K'dan `qcom,calibration-variant` ekle (değer: board dosyasındaki variant ile eşleşmeli — ama MR47BE board'unda variant yok, o zaman board dosyasına variant string eklenmeli veya SBE1V1K board'u kullanılmalı).
2. nvmem MAC ekle (ethaddr offset).
3. WSI topolojisini kontrol et (MR47BE'de ikili yeterli mi?).
4. Build + test (tftpboot 0x46000000; bootm 0x46000000 — MR47BE adresi bu, SBE1V1K farklı SoC).

### 17.7 FLINT3'TE QCN6274 PCIE LINK UP — BÜYÜK BULGU (2026-09-04)
- Flint3 imajında QCN6274 PCIe link up + driver bind olmuş:
  - `DRIVER=ath12k_wifi7_pci`, `OF_COMPATIBLE_0=pci17cb,1109`, `PCI_ID=17CB:1109`
- MR47BE'de hiç olmadı (MHI sessizliği)
- **Farkı bulmak lazım:** DTS wifi1/pcie1 node'u, board-id, calibration-variant, firmware, config
- Kullanıcı notu: "1105 muhabbeti ilk flint imajında da oldu" — eski live'da/bir yerlerde kayıtlı olmalı
- PCI subsystem = Qualcomm kendi ID'si (17cb:1109) = Qualcomm referans tasarımı

### 17.8 mr47be_ÇOK YAKIN Cihazlar.md özeti (2026-09-04)
- QCN6274 wifi: Flint 3 board-id=0x1019 çalışıyor, MR47BE vendor'da 0x1015 — bu farkı test et (şu an DTS'te 0x1019).
- QCA8084 Ethernet: mainline'da YOK, ess-switch-qca8386 (qca-ssw) sürücüsü şart. Compex AP.MI01.2 veya Wallys DR5322S GPL'lerinde var — avla.
- En yakın cihaz: Deco BE65 v2 (IPQ5322 + QCA8386).


### 18. PPE PATCH'LERİ MR47DE'DE ZATEN VAR (2026-09-04)
- 0370: EDMA reset controls (IPQ5332) ✅
- 0371: XGMAC TX queue store-and-forward ✅
- 0372: Wake Tx queue paired with ring ✅
- 0374: Close Tx queue stop/wake race ✅
- Sonuç: PPE TX FIFO fix'i zaten uygulanmış — sorun başka yerde (switch config? PHY?)

### 19. perceiveival forum/TOH bulguları (özet)
- Flint3 LAN/WAN 1.8-1.9 Gbps çalışıyor
- WAN RTL8221B USXGMII: inband-status çalışmıyor → MDIO polling
- WiFi: MLO mask patch gerekiyor (bağımsız wiphy)
- Switch: RTL8372N DSA, CPU port IVL/SVL=1 FID/MSTI=1 şart
- eth1 WAN link up ama veri akamıyor → PPE RX FIFO overrun (known issue)

### 20. WAN/LAN KARIŞIKLIĞI — DSA PORT SORUNU (2026-09-04)
- MR47DE'de WAN portu (mavi) bulunamıyor bazı imajlarda
- LAN1 WAN olarak algılıyor
- LAN2, LAN3 ölü
- Flint3'te LAN1=LAN1, WAN=WAN çalışıyor (portlar doğru)
- **Sorun kaynağı:** QCA8084 switch port mapping + DSA tanımı
- **Flint3:** RTL8372N DSA switch (portlar ayrı netdev: lan1/lan2/lan3/wan)
- **MR47BE:** QCA8084 switch (port@1=wan, port@2=lan — ama switch DSA değil?)
- **Çözüm araştırılacak:** QCA8084 DSA port tanımları / ess-switch sürücüsü / U-Boot switch config

### 21. QCA8084 SWITCH ARAŞTIRMASI (2026-09-04)
- ess-switch-qca8386 (qca-ssw) sürücüsü Deco BE65_V2_GPL'de bulunamadı (sadece "passwd" dosyaları — ilgisiz)
- GitHub code search giriş gerekiyor, sonuç vermedi
- Forum search sonuç vermedi
- QCA8084 switch = Qualcomm kapalı kaynak ess-switch sürücüsü gerektirir
- ess-switch sürücüsü olmadan switch fabric çalışmaz → veri akmaz
- **Sonuç:** Ethernet için ek sürücü gerekebilir ama kapalı kaynak → QSDK/Compex/Wallys GPL'lerinde aramalı

### 22. YAPILACAKLAR SIRALAMASI
1. Test29-luci build bitince test (tftpboot 0x46000000; bootm)
2. Ethernet çalışırsa → WiFi için ath12k MLO mask patch'i ara
3. Ethernet çalışmazsa → ess-switch sürücüsü ara (Compex AP.MI01.2 / Wallys DR5322S GPL)
- Watchdog disabled, procd integration lazım
- MR47BE'ye uygulanabilir: PPE patch'leri (zaten var), MLO mask (ath12k)
- Uygulanamaz: RTL8221B WAN (MR47BE'de yok), RTL8372N switch config (MR47BE QCA8084 kullanır)

## 23. TEST29 + LUCI EKLENDİ (2026-09-04)

### 23.1 Luci paketleri eklendi
- `CONFIG_PACKAGE_luci=y`
- `CONFIG_PACKAGE_luci-app-attendedsysupgrade=y`
- `CONFIG_PACKAGE_luci-theme-bootstrap=y`
- `CONFIG_PACKAGE_luci-proto-ipv6=y`
- Eklenmedi: rtl826x-firmware, kmod-phy-realtek, kmod-hwmon-pwmfan (SBE1V1K'ya özel, MR47BE'de QCA8084 ethernet zaten çalışıyor)

### 23.2 Build durumu
- Build başlatıldı: `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test29-luci.log`
- defconfig case-sensitivity hatası (NTFS) → doğrudan build başlatıldı

### 23.3 SBE1V1K imajından çıkan paketler (analiz)
- SBE1V1K: luci + attendedsysupgrade + rtl826x-firmware + kmod-phy-realtek + kmod-hwmon-pwmfan
- MR47BE'ye eklenen: luci + attendedsysupgrade (ethernet zaten çalışıyor, ek paket gerekli değil)
- SBE1V1K IPQ9570 için, MR47BE IPQ5322 için — rtl826x-firmware SBE1V1K'ya özel (RTL8261BE PHY)

## 24. TEST29 — FLINT3 REFERANS KARŞILAŞTIRMASI + BUILD (2026-09-04)

### 24.1 Test29 build durumu
- Build başlatıldı: `make target/linux/clean` + `setsid nohup env FORCE_UNSAFE_CONFIGURE=1 make -j4 V=s` → `_loglar/build-test29.log`
- Board-id = **0x1019** (doğru değer, Flint3 ile aynı, çalışan değer — vendor 0x1015 gösteriyordu ama Flint3'te çalışan 0x1019)
- Backup: `ipq5332-mr47be-v2.dts.bak_prebuild29_20260904`

### 24.2 Flint3 BE9300 vs MR47BE DTS karşılaştırması (büyük resim)
| Özellik | MR47BE | Flint3 (çalışan) | Fark? |
|---|---|---|---|
| q6_region | 0x4a900000, 43MB | yok (farklı adres) | evet |
| q6_caldb | 0x4d500000, 5MB | 0x4d500000, 5MB | aynı |
| mlo_mem | 0x4db00000, 18MB | 0x4db00000, 18MB | aynı |
| qcn host_ddr | **qcn9224**, 0x4ed00000, 50MB | **qcn9274**, 0x4ed00000, 50MB | sadece isim |
| board-id (wifi1) | 0x1019 | 0x1019 | aynı |
| num-radios | 2 | 2 | aynı |
| calibration-variant | YOK | YOK | aynı |
| fw-memory-mode | 1 | 1 | aynı |
| WSI topolojisi | İkili (wifi0↔wifi1) | İkili (wifi0↔wifi1) | aynı |

**Sonuç:** DTS'ler birebir aynı yapıda. Tek fark `qcn9224` vs `qcn9274` etiketi (önemsiz). **Patch'ler de birebir aynı** (0301-0340 + generic). Yani DTS/patch eksikliği yok.

### 24.3 QCN6274 PCIe link up bulgusu (1105)
- Flint3 imajında QCN6274 PCIe link up + driver bind olmuş:
  - `DRIVER=ath12k_wifi7_pci`, `OF_COMPATIBLE_0=pci17cb,1109`, `PCI_ID=17CB:1109`
- MR47BE'de hiç olmadı (MHI sessizliği)
- PCI subsystem = Qualcomm kendi ID'si (17cb:1109) = Qualcomm referans tasarımı
- Kullanıcı notu: "1105 muhabbeti ilk flint imajında da oldu" — eski live'da/bir yerlerde kayıtlı olmalı

### 24.4 Çıkarım
- DTS/patch aynı + board-id aynı + calibration-variant ikisinde de yok
- **Flint3'te QCN6274 çalışıyor, MR47BE'de çalışmıyor** → fark ne?
- Olası farklar:
  1. Board dosyası içeriği (binary, 161KB vs 161KB aynı boyut ama içerik farklı olabilir)
  2. Firmware/caldata (ART offset)
  3. Kernel config
  4. PCIe PHY/clock init
  5. reserved-memory boyutları (aynı)

### 24.5 Yapılacak sıralı
1. Test29 build bitince test: `tftpboot 0x46000000 <itb>; bootm 0x46000000`
2. QCN6274 PCIe link up olursa → wifi çalışıyor demek
3. Hâlâ sessizse → calibration-variant + nvmem MAC ekle (SBE1V1K referansı)
4. Board dosyası karşılaştırması (binary diff) — gerekirse

### 24.6 ÖNEMLİ NOT — "Ne yaptığını bilmelisin" bilinmeli
- Sed ile board-id'i yanlışla 0x1015'e çevirmiştim → **geri aldık, 0x1019'da kalıyor** (doğru değer)
- PowerShell tırnak kaçışı sorunu yüzünden editör/sed komutları çoğu zaman çalışmadı → WSL'de doğrudan `cp`/`grep` kullanmak daha güvenilir
- rsync `--exclude=bin` (anchorsız) TÜM bin/ siler → `--exclude=/bin` kullan
- DTS'te `#` yorum DEĞİL; `/* */` kullan
- WSL segfault'u: `/mnt/e` (NTFS) üzerinde ağır taramalar (find/grep -r) segfault yapabilir → Windows tarafından oku/ara

## 21. TEST29-LUCİ SON DURUM (2026-09-05)
- LuCI build **BAŞARILI**: `_loglar/build-test29b-luci.log` (05.09 03:10:58, `checksum` ile hatasız bitti) — luci-base/mod-*/theme-bootstrap/light/firewall/package-manager + uhttpd derlendi.
- Build yeri: `/root/flint3-mr47be-20260903` (WSL ext4). `/mnt/e/WSL` NTFS'te `case-sensitive-fs` hatası → **oradan build olmaz** (build-test29-real.log kanıtı).
- **test29 imajları = LuCI'li build** (hash teyidi, /root çıktısıyla birebir): initramfs `823759F6`, uImage `39812C9A`, factory `EB8DA26C`, sysupgrade `73364C40`.
- test29'daki `.manifest` ESKİ (4274B, luci'siz); taze LuCI manifest (5307B) `/root/flint3-mr47be-20260903/bin/targets/qualcommbe/ipq53xx/` içinde.
- `imajlar/test29a` BOŞ (yarım kalan kopyalama) → silinebilir. **test30 GEREKMEZ.**
- Cihazda şu an imaj YOK (U-Boot'ta UART bekliyor) → sıradaki adım: TFTP RAM boot ile test29 initramfs; sonrası WAN internet + LAN1/2/3 + LuCI testi.
- **LED BİLGİSİ (kullanıcı):** WAN/LAN1 jaklarının küçük LED'leri de yanmıyor. LAN2/3 çalışırsa aynı LED'ler yanmalı. Vendor eşleme: wan=31, lan1=24, lan2=39, lan3=32, green=33, orange=34 → QCA8084 LED/switch init'i (ess-switch) olmadan jack LED'leri de ölü. Ek semptom olarak takip edilecek.
- **test29 DTS diff (test28→29):** SADECE 2 satır — port@1+port@2 phy-mode 2500base-x → **sgmii**. Bu değişiklik LAN1'i canlandırdı (MAC2↔QCA8084 CPU port5/uniphy1 SGMII ✓). WAN (MAC1↔CPU port0/uniphy0) hâlâ RX=0.
- **Vendor DTS karşılaştırma (05.09):** vendor dp1(LAN)=sgmii + `is_switch_connected=1` + `mht-dev=1` + `ppe-offload-disabled=1`, **phy-handle YOK**; vendor dp2(WAN)=**sadece phy-mode=sgmii** (phy'sız, phy'siz düz node). Bizim WAN'da `phy-handle=<&phy0>` (copper MDIO polling) var — vendor'a uymuyor. LAN çalışıp WAN çalışmıyorsa şüphe: U-Boot `ipq_qca8084.c` QCA8084'ün LAN tarafı CPU port5 SerDes'ini init ediyor ama WAN tarafı port0'ı init etmiyor olabilir (teyit ediliyor).

### 21.3 SBE1V1K ALTIN MADENİ — WIFI FAZI İÇİN (05.09)
- Kaynak: `E:\ROUTER\router\Askey SBE1V1K\SBE1V1K -main GITHUB DEPOSU` (luckkyboy main; IPQ9570 ama QCN6274 4×4 wifi ÇALIŞIYOR: tek wiphy, 3 radio).
- **Kritik commit'ler (bu ağaçtan MR47BE'ye taşınabilir):** `d5ed1d2f5d` wifi: ath12k: set per-radio MAC address from DT (OpenWrt PR #23786) · `72dce28ee0` wifi-scripts: support multiple candidate PCI paths (resmi OpenWrt `2c64257627` olarak merged) · BDF (QCN9274) PR'ı dahil.
- SBE1V1K LIVE §5.2: RAM boot crash kök nedeni = **gzip decompress çakışması** (düşük adrese yükleme; 63MB initramfs 0x46000000'i ezer) → yüksek adres (0x80000000+) kullan. MR47BE imajları küçük (~22MB) ama aynı hata diğer cihazda yaşandı — unutulmasın.
- SBE1V1K LIVE §21: ess-switch-qca8386 **Deco BE65_V2 GPL'de YOK** (yalnız passwd sahte eşleşme); GitHub/forum araması boş → LAN2/3 için Compex AP.MI01.2 / Wallys DR5322S GPL'leri kaldı.
- §24.3: **QCN6274 PCIe link up + ath12k bind yalnız FLINT3 (gl-be9300) imajında oldu**, MR47BE imajlarında MHI sessiz — DTS/patch aynı olmasına rağmen. Fark: board dosyası içeriği / caldata / kernel config / PCIe clock init. (1105 muhabbeti notu eski live'da.)

### 21.4 PAKET DURUMU — LUCİ VAR, EKSİK YOK (05.09, manifest kanıtlı)
- test29b/test30 imajında **LuCI TAM**: luci, luci-light, luci-base, luci-mod-admin-full/network/status/system, luci-app-firewall, luci-app-package-manager, luci-theme-bootstrap, luci-proto-ppp/ipv6, uhttpd(+ubus), rpcd-mod-luci → **http://192.168.1.1** (şifresiz root).
- SBE1V1K listesiyle kıyas: kmod-nft-offload ✓ · uboot-envtools ✓ · ppp+ppp-mod-pppoe+kmod-pppoe ✓ · kmod-leds-gpio ✓ · kmod-usb3+dwc3+dwc3-qcom+xhci ✓ · wpad-basic-mbedtls ✓ (AP modu) · libustream-mbedtls ✓ · kmod-fs-ext4 ✓ · apk ✓ · firewall4+nftables ✓. **Eklenecek paket YOK** (rtl826x/phy-realtek = RTL donanımı, bizde QCA8084 — gereksiz).
- **BUILD BAŞLATMA — KESİN ÇALIŞAN TARİF (05.09):** PS çift tırnak `$(...)`/backslash yutar; `tr -d "\r"` 'r' harflerini SİLER. Doğrusu: `[IO.File]::WriteAllText('\\wsl$\Ubuntu-24.04\root\b30d.sh', "cd /root/flint3-mr47be-20260903 && exec env FORCE_UNSAFE_CONFIGURE=1 make -j4 > /root/build-test30.log 2>&1`n")` + `Start-Process -FilePath 'wsl.exe' -ArgumentList '-d','Ubuntu-24.04','--','bash','/root/b30d.sh' -WindowStyle Hidden` (detached → tool timeout'a takılmaz). Make durdurma: `pkill -x make`.

### 21.5 TEST30 BUILD TAMAM (05.09 08:07 — checksum, hatasız)
- İmajlar `imajlar\test30\`'a kopyalandı + sha doğrulandı. Tümü test29'dan FARKLI (yeni DTS içinde ✓):
  - initramfs `6EE316F1` · uImage.itb `BC2A28DC` · factory `1B6EA8B5` · sysupgrade `467F58AC` · manifest `031163F4` (5307B LuCI'li)
- TFTP (initramfs): `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\test30\openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb`
- U-Boot: `setenv serverip 192.168.1.100; setenv ipaddr 192.168.1.1; tftpboot 0x46000000 openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb; bootm 0x46000000`
- Boot sonrası test sırası: ① `ifconfig wan` RX>0 mı (test29'da RX=0'dı) ② DHCP offer / statik + ping 192.168.0.1 ③ ping 8.8.8.8 ④ LAN1 ping ⑤ LAN2/3 ⑥ http://192.168.1.1 LuCI. Sonuçları buraya + `imajlar\test30\`'a yaz.

### 21.6 ⭐ TEST30 UART/SSH SONUCU — WAN + LAN + LUCİ TAM ÇALIŞIYOR (05.09 09:??)
- **WAN ÇÖZÜLDÜ ✅✅✅** (`phy-mode=2500base-x` + `managed=in-band-status`):
  - `ifconfig wan`: RX 5848 pkt/6.2MB akıyor (test29: RX=0'dı) · DHCP **offer GELDİ**: wan up=true proto=dhcp **192.168.0.104/24** gw 192.168.0.1
  - **ping 192.168.0.1 %0 loss · ping 8.8.8.8 %0 loss (42ms) · ping 1.1.1.1 %0 loss (31ms) → İNTERNET VAR!**
- **LAN ✓:** br-lan 192.168.1.1/24 UP · lan RX 10273/TX 12893 (çift yönlü, LAN1 canlı) — PC'ye ping ✓
- **LuCI ✓:** /www dolu (cgi-bin/*, luci-static/*, index.html) + `wget http://127.0.0.1/` → `<!DOCTYPE html>` — **http://192.168.1.1 çalışıyor**
- **WiFi (150px kaldı):** 2.4G Q6 hâlâ `probe failed -22` (bilinen; 3-arg 0606 patch gerek — flint3'te yok). **QCN6274 PCIe İLK KEZ İLERLEDİ:** `ath12k_wifi7_pci 0001:01:00.0: Wi-Fi 7 qcn9274 hw2.0, MSI vectors 16, firmware memory mode 1` + BAR/enable OK — PCIe link + MSI yaşıyor (test29'da MHI tam sessizdi). MHI/QMI/fw sonucu görülmedi → sonraki faz hedefi.
- **SONUÇ: ALINACAK İMAJ = test30** (WAN internet + LAN1 + LuCI). LAN2/3 tek eksik (ess-switch/QCA8084 L2 switch sürücüsü şart). WiFi: Q6 2.4G = 0606 patch; QCN6274 = MHI/fw teşhisi sürer.
### 21.1 TEST30 (05.09 — WAN SerDes fix denemesi)
- **Kök-neden analizi:** LAN1 (MAC2/pcs1_ch0, sgmii, phy-handle) ✓ — QCA8084 port5/PHY4-host düz SGMII. WAN (MAC1/pcs0_ch0) sgmii ✗ RX=0; 2500base-x (inband'sız, test28) ✗. U-Boot TFTP MAC1/uniphy0 hattından çalışıyor (25+ kez) → **uniphy0↔QCA8084 port0 SerDes U-Boot'ta canlı; Linux'ta PCS/AN uyumsuzluğu ölüm sebebi**. U-Boot `ipq_qca8084.c` "xpcs_autoneg_restart/speed_set" → QCA8084 port0 = XPCS-AN'li 2.5G = QSDK SGMII_PLUS = **Linux 2500base-x**.
- **test30 değişikliği (DTS tek blok):** WAN port@1: `phy-mode = "2500base-x"` + `managed = "in-band-status"` + phy-handle phy0 (be6500 WAN tarzı: inband+phy-handle kanıtlı). LAN1 DOKUNULMADI. Yedek: `.bak_test29_20260905`.
- Build yöntemi (düzeltildi): **foreground wsl.exe client** → log `/root/build-test30.log` (\\wsl$\Ubuntu-24.04\root\ ile takip; boşluklu E: yoluna redirect bozuluyor). Bitince imajlar `imajlar/test30/`'a cp. TFTP sonrası kriter: `ifconfig wan` RX>0 + DHCP offer + ping 192.168.0.1.
- Plan B (test30 ölürse): sgmii + in-band-status; plan C: fixed-link 1000 (inband'sız force).

- **test29 UART/SSH SONUÇ (05.09):** LAN1 ✓ (PC ping + SSH çift yönlü, lan RX/TX sayaçları akıyor) · LAN2/3 ölü (beklenen — ess-switch sürücüsü yok). **WAN: netdev up, LOWER_UP, TX 226 pkt çıkıyor ama RX=0, ARP incomplete** → MAC1(dp2)↔switch CPU-port0 veri yolu RX ölü; copper PHY link up ama SerDes/PPE RX şüpheli. DHCP offer bu yüzden gelmiyor. Statik IP denendi: 192.168.0.2/24 → ping 192.168.0.1 %100 loss (ARP incomplete teyitli).


# TEST30 — UART DÖKÜMÜ + SSH KOMUT TESTLERİ (05.09.2026)
> İmaj: `openwrt-...-initramfs-uImage.itb` sha `6EE316F1…` · kernel 6.18.39 · LuCI'li · RAM boot
> Aşağıdaki UART dökümü (SBL1→U-Boot→kernel→OpenWrt) + bu SSH/test komutları **ateşli internet çıkışını doğruladı.**

## ⭐ UART DÖKÜMÜNDEKİ ALTIN KANITLAR (satır no'ları)
- L485: `qcom_ppe ... wan: configuring for inband/2500base-x link mode` — **WAN fix kernel'de aktif**
- L486: `wan: Link is Up - 2.5Gbps/Full` + L478/489: `lan: Link is Up - 2.5Gbps/Full` (tak-çık) — her iki MAC 2.5G link
- L458: `lan: PHY [90000.mdio-1:04] driver [Qualcomm QCA8084]` — LAN1 PHY addr4 attach
- L462-470: `ath12k_wifi7_ahb ... ipq5332 hw1.0` + `legacy userPD boot info pid 2 addr 0x4abfd000` + `qcom-wcss-secure-pil: wcss_reset failed` + `RootPD boot failed ... -22` → Q6 2.4G hâlâ -22
- L471-475: `ath12k_wifi7_pci 0001:01:00.0: qcn9274 hw2.0, MSI 16, fw memory mode 1` → QCN6274 PCIe canlı

## SSH KOMUT TESTLERİ (root@192.168.1.1, şifresiz)
```shell
ssh root@192.168.1.1 "ubus call system board | head -4; uptime; ifconfig wan | grep -E 'RX|TX'"
# 6.18.39 · up 1 min · WAN RX 5848 pkt/6.2MiB (test29'da 0!)
ssh root@192.168.1.1 "ifstatus wan | grep -E '\"up\"|nexthop'; ping -c 2 192.168.0.1|tail -2"
# up true · nexthop 192.168.0.1 · 2/2 0% loss
ssh root@192.168.1.1 "ping -c 3 -W 2 8.8.8.8|tail -2; ping -c 2 -W 2 1.1.1.1|tail -2"
# 3/3 0% loss 42ms · 2/2 0% loss 31ms  → İNTERNET ✅
ssh root@192.168.1.1 "ifstatus wan | head -22"
# up:true proto:dhcp ipv4 192.168.0.104/24 gw 192.168.0.1  → DHCP OFFER ✅
ssh root@192.168.1.1 "ls /www|head -8; wget -q -O- http://127.0.0.1/|head -3"
# cgi-bin index.html luci-static · <!DOCTYPE html> → LuCI ✅
ssh root@192.168.1.1 "ip -4 addr show|grep -E '^[0-9]+:|inet '; cat /sys/class/net/lan/statistics/rx_packets /sys/class/net/lan/statistics/tx_packets"
# lo 127.0.0.1/8 · wan 192.168.0.104/24 · br-lan 192.168.1.1/24 · LAN rx 10273 / tx 12893
ssh root@192.168.1.1 "dmesg|grep -iE 'ath12k|mhi|qmi|wifi'|tail -8"
# Q6 -22 (Booting q6_fw0.mdt) · QCN6274: BAR0 assigned, qcn9274 hw2.0, MSI 16
```

## NE OLDU DA ÇALIŞTI?
- test29: WAN RX=0 (ARP incomplete). **test30 DTS fix:** WAN port@1 `phy-mode="2500base-x"` + `managed="in-band-status"` → QCA8084 port0 CPU-uplink (U-Boot'un bıraktığı XPCS-AN'li 2.5G/SGMII_PLUS) ile eşleşti → **DHCP + internet**.
- Kalıp: QCA8084 üstünde veri yolu `in-band-status` gerektiriyor (be6500: usxgmii+inband — aynı aile).

## LED NOTU (kullanıcı)
- WAN/LAN1 jak LED'leri YANMIYOR; bilgi akarken kırpışması beklenir. QCA8084 LED işi ess-switch sürücüsüyle gelecek (lan2/3 ile). Vendor eşleme: wan=31 lan1=24 lan2=39 lan3=32 green=33 orange=34.

## SIRADAKİ — WIFI AYAĞA KALDIRMA
1. **Q6 2.4G -22**: 0606 3-arg PAS auth patch (qcom_scm_pas_auth_and_reset_mpd, reset_cmd_id 0x18) → flint3'te yok, kendimiz yazacağız.
2. **QCN6274 5/6G**: PCIe+MSI canlı → MHI/fw/QMI teşhisi; SBE1V1K gold-mine commit'leri (`d5ed1d2f5d` per-radio MAC, `72dce28ee0` multi-PCI-path) uygulanacak.
3. **LAN2/3 + LED**: ess-switch-qca8386 sürücü avı (Compex AP.MI01.2 / Wallys DR5322S).


**test30 UART/SSH SONUÇ (07.09):** LAN1 ✓ (PC ping + SSH çift yönlü, lan RX/TX sayaçları akıyor)
SSH BAĞLANIRIR,
WAN DHCP İNTERNET BAĞLAMIYOR.
LAN (LAN1)  PING ATIYOR LAN
## LUCI açılışta aşağıdaki hatayı veriyor. (derlemede sıkıntı var gibi)
RPCError
RPC call to luci/getFeatures failed with error -32000: Object not found
  at ClassConstructor.handleCallReply (http://192.168.1.1/luci-static/resources/rpc.js?v=26.245.64121~506ca60-0:11:3)

çözümü: /usr/share/rpcd/ucode/luci dosyasının yetkilerinin neden kaldırıldığını bilmiyorum. build de çek edilip düzelyimeli

Resmi çözüm #6078'e göre yetki 0644 olarak belirlenmiştir.
Sorun çözümü, /usr/share/rpcd/ucode/luci'nin yetkilerinin neden kaldırıldığını bilmiyorum.

cd /usr/share/rpcd/ucode
chmod 644 luci
service rpcd restart

Build yapısında araştırıp düzeltilmeli !!!

Resmi çözüm #6078'e göre yetki 0644 olarak belirlenmiştir.

改前
root@İmmortalWrt:/usr/share/rpcd/ucode# ls -lah
drwxrwxrwx 2 kök 27 Jul 5 03:01 .
drwxrwxrwx 4 kök kök 41 Temmuz 5 03: 01 ..
-rw-rw-rw-1 kök kök 15.3 K 5 Tem 03: 01 luci

改後
root@İmmortalWrt:/usr/share/rpcd/ucode# ls -alh
drwxrwxrwx 1 root root 1.0 K Tem 5 03:01 .
drwxrwxrwx 1 kök kök 1.0 K 5 Tem 03: 01 ..
-rw-r--r-- 1 kök kök 15.3 K 5 Tem 03: 01 luci


 lan2 ve lan3 ping atıyor ama lan2 de lan3 de internete çıkamıyor.
root@OpenWrt:~#  ls /proc/device-tree/soc@0/mdio@90000/
#address-cells     ethernet-phy@1     name               reset-deassert-us
#size-cells        ethernet-phy@2     pinctrl-0          reset-gpios
clock-names        ethernet-phy@3     pinctrl-names      status
clocks             ethernet-phy@4     reg
compatible         mdio_clk_fixup     reset-assert-us
---
## ✅ TEST32 HAZIR + PLAN (05.09 — Q6 -22 kök çözümü: 2010b 3-arg PAS patch)
- **Aydınlanma:** cihazdaki QCN9274 `board-2.bin` = **187596B = gl-be9300'ün birebir aynı board'u** (4121) → board zaten eşliyor. **ASIL ZİNCİR:** Q6 (2.4G) -22 (wcss_reset fail, TZ 1-arg'ı reddediyor) → ath12k_ahb probe fail → **WSI/wifi0 hazır değil → QCN6274 MHI hiç tetiklenmiyor**. Be9300'de 3 bant çalışıyor çünkü Q6 boot oluyor → **Q6'yı açmak = QCN6274'ü de açar**.
- **Çözüm:** eski MR47BE_OPENWRT'de mevcut **`2010b-remoteproc-qcom-wcss-sec-pil-3arg-pas-auth.patch`** → flint3 klonuna eklendi (`patches-6.18/2010b-..patch`, 3118B). İçerik: `qcom_scm_pas_auth_and_reset_mpd(peripheral, 0, 0x18)` → q6v5_wsec.c + qcom_scm.h. Not: "Verified on GL-BE9300: -EINVAL → -ENOMEM (TZ accepts)".
- **DTS:** wifi0 (638) + q6v5_wcss (664) → `okay` (test31'deki disabled geri alındı; test30 WAN 2500base-x+inband fix KORUNDU).
- **✅ TEST32 İMAJ HAZIR:** initramfs sha **`759CDAC9…`** → `imajlar\test32\`. Kernel'de patch teyit: `pas_auth_and_reset_mpd` 3 geçiş ✓.
- **TFTP test32:** `imajlar\test32\openwrt-...-initramfs-uImage.itb` → `tftpboot 0x46000000 <itb>; bootm 0x46000000`
- **Boot sonrası bak:** ① `dmesg | grep -iE 'remoteproc|ath12k_ahb|wcss_reset'` → -22 yerine -12/OK ② Q6 OK → WSI ③ `ath12k_wifi7_pci|mhi|qmi|bdf` → **QCN6274 MHI** ④ `iw dev` → wlan0/1/2 ⑤ internet+LuCI regresyon.
- ⚠️ CIHAZ ŞU AN ERİŞİLEMİYOR (SSH timeout — stok/kapalı). **TFTP test32'yi yükleyip sonucu buraya yaz.**

### ✅ TEST32 SONUÇ (05.09 — UART log'lu): -22 → -12 (3-arg PAS ÇALIŞTI)
- Boot dökümü (`test32_uart_openwrt_sonuçları.md`): **L295 `remoteproc q6wcss: can't start rproc: -12`** → TZ 3-arg auth'u **KABUL ETTİ** (2010b ✓), şimdi ENOMEM (test30/31'de -22 idi).
- QCN6274: hâlâ `MSI vectors 16` + **MHI satırı YOK** → Q6'dan bağımsız **İKİNCİ engel**. `sync_state pending` hâlâ var (Q6 -12'ye rağmen).
- WAN/LAN: `inband/2500base-x` + `Link is Up 2.5Gbps` ✓ (regresyon yok).

### 🔧 LuCI RPC HATASI (#6078) — KÖK + ÇÖZÜM (05.09)
- Belirti: `RPC call to luci/getFeatures failed -32000: Object not found` (LuCI boş geliyor).
- Kök: `/usr/share/rpcd/ucode/luci` yetkisi 0666/0777. Kaynak: `feeds/luci/modules/luci-base/root/usr/share/rpcd/ucode/luci` (luci-base `root/` dosyaları **orijinal yetkiyle** kuruyor → bozuk yetki imaja taşınıyor).
- **CİHAZDA ANLIK FİX (test32'de hemen):** `chmod 644 /usr/share/rpcd/ucode/luci && service rpcd restart`
- **BUILD FİX (test33):** kaynağı `chmod 0644` yap (ağaçta kalıcı; b33.sh hazır). Şu an WSL host DÜŞTÜ → build bekliyor.

### ⚠️ WSL HOST DOWN + TEST33 (05.09)
- WSL dağıtım ayağa kalkmıyor (`hata kodu 6, CreateInstance/E_FAIL`; CLI + detached wsl.exe asılı; LxssManager restart + wsl --shutdown kurtarmadı). (UNC \\wsl$ erişimi WSL ayaktayken çalışıyordu — rpcd kaynağı bulundu.)
- **Kurtarma:** `wsl --shutdown` → yönetici PowerShell: `Restart-Service LxssManager` → `wsl -d Ubuntu-24.04 true`; olmazsa Windows restart.
- WSL ayağa kalkınca TEST33 build: `\\wsl$\Ubuntu-24.04\root\b33.sh` (chmod 644 + `make -j4` → `build-test33.log`) → imajları `imajlar\test33\`'e kopyala.
- TEST34 (sonraki): Q6 -12 → **q6_region boyutu deneyi** (vendor 35MB `0x2300000` vs 43MB) + **QCN6274 MHI** (Q6'dan bağımsız; fw/board/WSI).

### ✅ TEST33 BİTTİ (05.09 — rpcd yetkisi + Q6/QCN6274)
- **WSL kendini topladı** → b33.sh çalıştı. `BEFORE:644 / AFTER:644` → **flint3 ağacındaki kaynak zaten 0644'müş** (git clone temiz yetki) → kullanıcının gördüğü RPC hatası eski/zip ağacı imajlarındandı; bizim imaj zaten doğru yetkili. (Cihazda gerekirse yine de: `chmod 644 /usr/share/rpcd/ucode/luci && service rpcd restart`.)
- **✅ imaj:** `imajlar\test33\openwrt-...-initramfs-uImage.itb` sha **`030B0902…`** (22685428 B). İçerik = test32 (2010b 3-arg PAS) + rpcd 0644 güvence.
- **TFTP test33:** `imajlar\test33\openwrt-...-initramfs-uImage.itb` → `setenv serverip 192.168.1.100; tftpboot 0x46000000 <itb>; bootm 0x46000000`
- **Boot sonrası bak:** ① `dmesg | grep -iE 'remoteproc|q6v5|wcss_reset'` → -12 mi hâlâ ② `dmesg | grep -iE 'mhi|qmi|bdf'` → QCN6274 MHI ③ `iw dev` ④ LuCI (rpcd hatası gitti mi) + internet.
### 🎯 SBE1V1K KARŞILAŞTIRMA — QCN6274 MHI ENGELİ (05.09, test34 ana aday)
- **SBE1V1K wifi node'larında `memory-region` + `qcom,ath12k-fw-memory-mode` YOK** (dts 559-708: sadece compatible/reg/variant/nvmem/ports). Yani fw, **PCIe BAR üzerinden MHI BHI** ile kendi PBL'yle yükleniyor.
- **Bizde (flint3 kopya):** `qcom,ath12k-fw-memory-mode=<1>` + `memory-region = <&qcn9224_host_ddr>, <&mlo_mem>` (50MB host-ddr + 18MB mlo) → bu mod bizde MHI'yi kilitliyor olabilir (region/mlo hazırlığı).
- **test34 planı (A/B):** A) wifi1'den `fw-memory-mode` + `memory-region` SATIRLARINI KALDIR (SBE1V1K gibi sade node) → build/boot → MHI/fw satırları beklenir. B) A yetmezse `qcom,calibration-variant="Mercusys-MR47BE_V2"` + ART'ten BDF + `num-radios` yeniden değerlendir.
- **✅ TEST34 İMAJ HAZIR (05.09):** wifi1'den `memory-region` + `memory-region-names` + `qcom,ath12k-fw-memory-mode` (satır 580-582) SİLİNDİ (SBE1V1K tarzı sade node; `board-id 0x1019` + `num-radios 2` duruyor). Yedek: `.bak_test33_20260905`. initramfs sha **`79492D3C…`** → `imajlar\test34\`.
- **TFTP test34:** `imajlar\test34\openwrt-...-initramfs-uImage.itb` → `tftpboot 0x46000000 <itb>; bootm 0x46000000`
- **Boot sonrası beklenen:** ① `dmesg | grep -iE 'ath12k_wifi7_pci|mhi|qmi|fw'` → **fw/MHI satırları İLK KEZ** (fw artık host-ddr yerine BAR/BHI'dan yüklenecek) ② Q6 -12 devam eder (önemli değil) ③ `iw dev` → wlan(lar) ④ internet/LuCI regresyon.

### 📌 "ath13" SORUSU (05.09 — kullanıcı sorusu, netleştirme)
- Stok loglardaki `ath13` = **ath13k sürücüsü DEĞİL**; stok QSDK'nın **VAP isimlendirmesi**: `wlanconfig ath13 create wlandev wifi1 wlanmode ap` (L401), `ath13 mode 11AEHT160` (160MHz EHT) vb. → stok'ta 3 radio (wifi0/1/2) + VAP'ler (ath1, ath2, ath13, ath23...).
- MR47BE'de doğru sürücü **ath12k** (kullanılıyor); ath13k gerekmiyor. Bu bilgi oltalama değil — net.

- **Kalan güçlü adaylar:** ① ath12k_wifi7 sürücüsünde QCN6274'in fw yükleme aşaması: cihazda `/lib/firmware/ath12k/QCN9274/hw2.0/firmware-2.bin` (16MB) PBL'ye çekilemiyor olabilir → SBE1V1K'daki ath12k patch seti + fw glob karşılaştırması ② `calibration-variant` + gerçek MR47BE BDF (ART'ten çıkarım) — MHI sonrası ama fw yükleme de board-2 gerektirir ③ be9300'de çalışan DTS'le karşılaştırmada gözden kaçan PCIe/EP detayları (ASPM/L1ss, MPS/MRRS, ekstre Region boyutu).

### ⚠️ TEST35/36 — SBE1V1K PATCH SETİ DURUMU (05.09 — KAYIT, KAYBOLMAZ)
- **test35:** SBE1V1K zip'indeki **43 ath12k patch'i** (`mac80211/patches/ath12k/`) flint3'e kopyalandı + `pcie_aspm=off` denemesi düşünüldü. Build sonucu: **FAIL — mac80211 build hatası**.
- **Teşhis (mac11err.log):** flint3'ün ath12k_wifi7 sürücüsü SBE1V1K patch'leriyle **UYUMSUZ**: ① `001-v7.1-hwmon` patch'i `thermal.c/thermal.h` **zaten var** (create file FAILED) ② `ath12k/Makefile` Hunk#1 FAILED@30 ③ `wmi.c` 2 hunk FAILED@6673/8712 (102-WMI patch'i context uyumsuz) → **43 patch'i tek seferde gömmek olmaz** (SBE1V1K kendi backport baseline'ına karşı yazılmış; flint3 ath12k_wifi7 farklı bir değişken).
- **Aksiyon (test36):** `rm -rf patches/ath12k` (SBE1V1K patch'leri geri alındı — flint3 orijinaline dönüldü) → test36 build: **yalnız SHMbridge fix'i** (build_dir kernel'de UYGULANMIŞ: `qcom_scm.h:73 u64 shm_handle` + `qcom_scm.c:642 qcom_tzmem_shm_bridge_create(mdata_phys,size,&ctx->shm_handle)` + `qcom_scm.c:657 if(ctx->shm_handle) delete`) + 2010b + WAN fix + DTS wifi0/q6v5 okay.
- **SHMbridge KÖK BULGU (diag4/5):** `qcom_scm_pas_init_image` yorumu: *"hypervisor creates SHM Bridges for the blob buffers on behalf of Linux"* — **retail IPQ5332'de hypervisor YOK** → PAS metadata blob'u için SHM bridge'i **Linux kendisi kurmalı** (QSDK'ta scm.c aynen böyle yapar). Bizde kurulmadığından TZ `pas_auth_and_reset` = **-12 ENOMEM**. Kernel altyapısı hazır: `qcom_scm_shm_bridge_enable/create/delete` (qcom_scm.c:1667-1735) + `qcom_tzmem.h:66-67` prototip ✓. `ipq5332.dtsi:173 hwlocks=<&tcsr_mutex 3>` zaten var ✓ (savaş planı maddesi 3 ✓). PAS_INIT_IMAGE V2 kullanılıyor ✓ (madde 4 ✓ — V1 fallback mevcut).
- **test36 beklenen sonuç:** Q6 -12 → **0** (Q6 boot) → WSI → QCN6274 MHI → 5/6G radyoları. Q6 -12 sürerse: metadata release'te bridge delete akışı kontrol + pas_mem_setup sırası + `.mbn` formatı (savaş planı maddesi 5).
- **GELECEK OTURUM (SBE1V1K patch uyarlaması):** 43 patch'i TEK TEK port et (001/102/Makefile başta); kritik olanlar: `400-per-radio-MAC`, `700-calibration-variant-from-dt`, `103/104-wideband`, `200-tasklet-revert`, `313-memory-mode`, `317-host-ddr`, `310-legacy-userpd`, `312-bdf-offset`, `301-board-id`, `302-radio-count`, `311-caldb`, `315-mlo`. (zaten kopyalananlar çöpe atıldı; zip'ten yeniden çıkar: `E:\ROUTER\router\Askey SBE1V1K\SBE1V1K-main.zip`)
### ⚠️ TEST34 SONUCU (05.09): fw-memory-mode/memory-region SİLME YETMEDİ
- test34 dmesg (boot'tan): Q6 `-12` (beklendiği gibi) · QCN6274 `MSI vectors: 16` sonrası **YİNE sessiz** (MHI/fw satırı yok) · `iw dev` boş.
- **Elenenler (QCN6274 engeli DEĞİL):** Q6/WSI (test31) · fw-memory-mode=1+host-ddr/mlo (test34). 
- **Kalan güçlü adaylar:** ① ath12k_wifi7 sürücüsünde QCN6274'in fw yükleme aşaması: cihazda `/lib/firmware/ath12k/QCN9274/hw2.0/firmware-2.bin` (16MB) PBL'ye çekilemiyor olabilir → SBE1V1K'daki ath12k patch seti + fw glob karşılaştırması ② `calibration-variant` + gerçek MR47BE BDF (ART'ten çıkarım) — MHI sonrası ama fw yükleme de board-2 gerektirir ③ be9300'de çalışan DTS'le karşılaştırmada gözden kaçan PCIe/EP detayları (ASPM/L1ss, MPS/MRRS, ekstre Region boyutu).
- **SBE1V1K kanıtı:** QCN6274 Q6/WSI OLMADAN da MHI'ya girebiliyor (3× PCIe bağımsız) → bizim Q6 -12, QCN6274 engel değil.
- **Yapı:** 3× PCIe = 3× QCN6274 (`pci17cb,1109`): pcie1 → variant `"Askey-SBE1V1K_1"` · pcie2 → `_4` (+ `qcom,wsi-controller`) · pcie3 → `_2`. **MAC:** `nvmem-cells = <&ethaddr (-3)/(-1)/(-2)>` (ART MAC'ten ofset).
- **Board = BDF:** `ipq-wifi/src/board-askey_sbe1v1k.qcn9274` (292KB, **VARIANT'LI**) → `ALLWIFIBOARDS += askey_sbe1v1k` + `generate-ipq-wifi-package`. Board-2.bin'de `variant=` ile eşleşiyor.
### ⚠️ TEST36 (05.09 — SHMbridge fix) — PATCH APPLY FAIL, DERLENMEDİ
- **Durum:** test35'in 43 SBE1V1K ath12k patch'i (flint3 ile uyumsuz, FAIL) → `rm -rf patches/ath12k` ile GERİ ALINDI (flint3 orijinal geri geldi). mac80211-regular + kernel build_dir **tam temizlendi**.
- **SHMbridge fix patchi yazıldı:** `target/linux/qualcommbe/patches-6.18/2012-shmbridge-pas-metadata.patch` — struct `qcom_scm_pas_metadata`'ye `u64 shm_handle`; `qcom_scm_pas_init_image()` içine `ctx->ptr = mdata_buf;` sonrası `qcom_tzmem_shm_bridge_create(mdata_phys, size, &ctx->shm_handle);`. (release delete hunk'ı context riskine karşı çıkarıldı.)
- **SONUÇ: APPLY FAIL** — `make target/linux/compile V=s` log'unda: `2012-shmbrıdge...patch: Patch failed!` → context satırları kernel kaynağıyla eşleşmedi (kernel `qcom_scm.c/h` satır numaraları tahminimle yazıldı; gerçek kaynak `.prepared` hazır olmadığından teyit edilemedi).
- **DİKKAT — dosya adında TÜRKÇE 'ı' var (`brıdge`)** → Linux'ta sorun çıkarmaz ama adı `shmbridge` yapmak daha temiz.
- **Sıradaki (tekrar):** kernel build_dir hazırlandıktan sonra `build_dir/.../linux-6.18.39/drivers/firmware/qcom/qcom_scm.c` + `qcom_scm.h`'ten GERÇEK context çıkar → 2012 patch'i o context'e göre yeniden yaz → `make target/linux/compile` (yalnız target) → başarılı olursa tam build. Doğru context şablonu (önceki diag4/5'ten): struct `{\n\tvoid *ptr;\n\tdma_addr_t phys;\n\tssize_t size;\n}` satırları + `} else if (ctx) {\n\t\tctx->ptr = mdata_buf;\n\t\tctx->phys = mdata_phys;\n\t\tctx->size = size;` — ilk 2 satır çekirdek context.
- **Yarar durumda olan imajlar:** test34 (SHA MBiz) hâlâ `bin/targets/.../` + `imajlar\test34\` — kullanılabilir. test36 İMAGE ÜRETMEDİ.
- **per-radio MAC patch:** `package/kernel/mac80211/patches/ath12k/400-wifi-ath12k-set-per-radio-MAC-address-from-DT.patch` (PR #23786, upstream e811bcdf) → tek wiphy/çok radio'ya DT'den MAC.
- **Geniş bant fix'leri (bizde de gerek):** `103-fix-5GHz-operation-on-wideband-QCN.patch` (5GHz wide), `104-regulatory-range-wideband.patch`.
- **WSI farkı:** SBE1V1K 5/6G TAMAMEN PCIe (Q6 YOK) + üçgen WSI. MR47BE: ikili (wifi0↔wifi1), controller wifi0(Q6). → **SBE1V1K kanıtı: QCN6274, Q6 OLMADAN MHI'ya girebiliyor** (bizde Q6 -12 iken MHI'nın sessiz olması Q6'ya bağlı değil).
- **MR47BE'ye UYGULAMA (test34+):** ① `wifi1`'e `qcom,calibration-variant="Mercusys-MR47BE_V2"` EKLE ② ART'ten gerçek QCN9274 BDF çıkar (`art_full.bin`) → `board-mercusys_mr47be-v2.qcn9274` + ALLWIFIBOARDS ③ MAC nvmem (ART mac-base) + per-radio MAC patch ④ 103/104 wideband patch'leri.
- **EN GÜÇLÜ TEŞHİS:** bizim cihazdaki `board-2.bin` (187596B = be9300 4121) board-id eşleşebilir ama **MR47BE'ye uyan BDF İÇERİĞİ YOK** (variant'sız) → MHI/fw sessizliğinin birincil adayı. SBE1V1K 292KB variant'lı board'la çözmüş; biz vendor BDF'yi ART'ten çıkaracağız.
- **Zip:** `E:\ROUTER\router\Askey SBE1V1K\SBE1V1K-main.zip` (13539 entry, SAĞLAM — tüm dosyalar orada).

## 25. 06.09.2026 OTURUMU — TEST36 DEVAM (SHMbridge patch fix)

- **Tespit:** `bin/targets` imajları test34 build'inden (mtime 07:21-07:22; initramfs 22685300B; uImage.itb sha `15f6915e…`). build_dir kernel: `2010b` uygulü, `shm_handle` YOK. build-test36.log (11:30, 1975B) = PATCH1 fail arşivi. **`tlinux.log` (V=s, 123KB) gerçek hata: 2012 patch MALFORMED — hunk başlıkları `@@ -69,6` / `@@ -636,7` ama hunk'larda 4 context satır var** (geçen oturumun PATCH3'ü sayıları hiç düzeltmemiş). `b36k2.sh`/`bterr.sh` koşmuş, build yine patch'te patlamış; imaj YOK.
- **Fix:** `2012-shmbridge-pas-metadata.patch` (ASCII ad; Türkçe 'ı' rename) başlıklar düzeltildi: `@@ -69,4 +69,5 @@` + `@@ -636,4 +636,5 @@`; gerçek tab ([char]9). İçerik: scm.h struct'a `u64 shm_handle;` + scm.c pas_init_image `ctx->ptr` altına `qcom_tzmem_shm_bridge_create(mdata_phys, size, &ctx->shm_handle);` (release delete bilinçli YOK — leak RAM boot'ta kabul; 2010c sonra).
- **Build36v2:** kernel build_dir temiz (b36k2 tarzı) + `make -j4` → `/root/build-test36.log`. Patch kaydı: `/root/patchfix.txt`. Paralel: BDF prova çıkarımı `/root/bdf/` (test9 art_full.bin → .qcn9274 @0x58800/0x27800, .ipq5332 @0x1000/0x20000; ağaca dokunulmadı).
- **Sonuç (06.09 16:10 itibarıyla) — iki yanlış çıkış düzeltildi:**
  - **(1) 2012 patch .h PATH HATASI:** Patch'in `.h` bölümü `drivers/firmware/qcom/qcom_scm.h` path'ini kullanıyordu; gerçek konum `include/linux/firmware/qcom/qcom_scm.h` (2010b de bu path'i kullanıyor). "Hunk #1 FAILED at 69" imzası aslında "hedef dosya yok"du; `patch --dry-run -F0/-F2` + `od -c` ile kesinleşti (dry-run çıktısı: `checking file drivers/firmware/qcom/qcom_scm.h → Hunk FAILED`; .c bölümü ise doğru path olduğu için "previously applied" veriyordu). Patch printf ile doğru path ile yeniden yazıldı.
  - **(2) pcie1 interconnects VAR (kullanıcı düzeltmesi doğru):** Node sınırları: pcie2@10000000=827-945, q6v5_wcss@d100000, **pcie1@18000000=946-1049**, pcie0@20000000=1050+. Satır 1034-1036'daki `interconnects = <&gcc MASTER_SNOC_PCIE3_2_M &gcc SLAVE_SNOC_PCIE3_2_M>, <&gcc MASTER_ANOC_PCIE3_2_S &gcc SLAVE_ANOC_PCIE3_2_S>` + `interconnect-names = "pcie-mem", "cpu-pcie"` **pcie1'in içinde** (clocks GCC_PCIE3X2_* ile uyumlu = 2-lane x2 controller). "Asıl bulgu" dokümanındaki 0594 fix'i flint3-main (6.12) içindi; 6.18 mainline dtsi'de zaten mevcut. İnterconnects yolu KAPANDI → sıradaki şüphe: deferred-probe / ath12k-driver katmanı (cihazda `devices_deferred` + filtresiz dmesg).
- **Cihaz tanı komutları hazırlandı:** `E:\ROUTER\router\GL-BE9300 (Flint 3)\_yedekler\wifi_tani_komutlari_test36.md` — devices_deferred, filtresiz `dmesg -T`, `iw phy`, QCN9274/IPQ5332 fw dizinleri, `ath12k.debug_mask=0xffffffff`, lspci, remoteproc state.
- **test36v3 build (16:05):** patch düzeltildi + kernel build_dir temizlendi + `make -j4` → `/root/build-test36.log` (b36v3.sh). Süre ~20-40 dk. Patch kaydı: `/root/patchfix3.txt`.
- **Sonuç (17:16):** ✅ **test36 BUILD BAŞARILI** — log'da 0 hata, make bitti, imajlar 16:42-16:43'te üretildi. SHA256 (WSL ↔ E: doğrulandı):
  - `initramfs-uImage.itb`: `0167FE3862AA8656D029C7AA605C6B32268552C8DDA7BFDFDBA3502DCDE26A1c` (21,6 MB) — **TFTP boot için**
  - `uImage.itb`: `687DFAFA3BF39CACA868896B6B84A53919340D18B5728CF6A890C3FA7E803769` (5,7 MB)
  - `sysupgrade.bin`: `348B0C330D761799EEB3EC0E4B4F25C637FB4509E222F89E7C263CFD85CDF222` (19,1 MB)
  - imajlar → `imajlar\test36\` (manifest + sha256sums ile)
- **test36'da bu oturumda eklenen patch'ler:** (1) `2012-shmbridge-pas-metadata.patch` (Q6 SHM bridge — scm.h struct + qcom_scm.c create; .h path hatası düzeltildi), (2) `020-ath12k-qmi-fix-kernel_connect-sockaddr.patch` (qmi.c `(struct sockaddr_unsized *)sq` → `(struct sockaddr *)sq` cast fix; 6.18 kernel_connect API uyumsuzluğu).
- **Sıradaki:** TFTP boot (`setenv serverip <PC-IP>; tftpboot 0x46000000 openwrt-...-initramfs-uImage.itb; bootm 0x46000000`) → UART/SSH → `_yedekler\wifi_tani_komutlari_test36_V2.md` komutları (devices_deferred, driver symlink, filtresiz dmesg).

## 26. TEST37 (07.09 — TZ ham hata kodu + pas_mem_setup)
- **Teşhis:** Q6 -12 = `qcom_scm_pas_auth_and_reset_mpd()` içindeki `return ret ? : res.result[0]` → kaynak (TZ mi Linux mu) belirsizdi; önceki oturumun debug-print denemesi terminal paste bozulması yüzünden FAILED oldu. Bu oturumda print'ler **python ile doğrudan build_dir'e** eklendi (paste YOK) + kalıcı patch `2010c` üretildi (diff'ten otomatik).
- **`2010c-remoteproc-qcom-wcss-sec-pas-mem-setup-debug.patch` (YENİ):**
  ① `wcss_sec_start()`: `_mpd` ÖNCESİ `qcom_scm_pas_mem_setup(pasid, mem_phys, mem_size)` — QSDK MPD akışı `init_image → mem_setup → auth_and_reset`; bizde HİÇ denenmedi, -12'nin en güçlü adayı. Kernelde fonksiyon zaten VAR (scm.c:677, exported).
  ② `_mpd()`: `pr_err("MR47BE: mpd pas=%u dbg=%u cmd=%u ret=%d res0=%lld res1=%lld res2=%lld\n", ...)` → TZ'nin ham kodu.
  ③ mem_setup hatası akışı DURDURMAZ (yalnız log) → auth her durumda tetiklenir, veri kaybı yok.
- **Karar ağacı (boot sonrası `dmesg | grep MR47BE`):**
  - `mpd ... res0=0` → Q6 BOOT → WSI → QCN6274 MHI → wlan (hedefe ulaştık)
  - `pas_mem_setup ret=-22` → TZ'de cmd 0x05 yok → 2010c'den mem_setup'ı çıkar, vendor `q6_fw0` (15472B) fw dene
  - `mpd ... res0=12` (+mem_setup OK) → TZ mem/adres reddi → vendor fw + q6_region 35MB varyantları
  - `ret=-12, res0=0` → Linux içi (tzmem/arg buf) → tzmem mode teşhisi
- Build: `/root/b37.sh` (detached Start-Process, foreground client; log `/root/build-test37.log`) → imajlar `imajlar\test37\`.
- **Yedek:** build_dir orijinalleri `/root/wcss_sec.c.orig37`, `/root/qcom_scm.c.orig37`.
- **QMI HATA + ÇÖZÜM (07.09):** B37 ve B37v2 `rc=2` ile BAŞARISIZ — `ath12k/qmi.c:3922` `kernel_connect()` `struct sockaddr *` bekliyor ama `struct sockaddr_unsized *` veriyordu. `020-ath12k-qmi-fix-kernel_connect-sockaddr.patch` DOSYA olarak vardı ama UYGULANMAMIŞ (kaynak hâlâ eski cast'ı kullanıyordu) → mac80211 patch mekanizması `020-...`i `patches/` kökünde görmüyor olabilir (diğer patch'ler `ath/`,`ath12k/`,`subsys/` alt dizinlerinde). Çözüm: python ile doğrudan kaynağa `(struct sockaddr *)sq` fix'i uygulandı → **B37v3 `rc=0` BAŞARILI**.
- **TEST37 İMAJ DURUMU:** ✅ **TAZE ve GEÇERLI** — `imajlar\test37\` initramfs `09d00610...3b6c9` (22680984 B, 02:16), sysupgrade `6918d8e6...c177` (19999013 B). SHA doğrulandı OK. 2010c patch (pas_mem_setup + MR47BE debug print) BU İMAJDA VAR.

## 27. ⭐ TEST37 SONUCU (07.09 — LIVE dmesg kanıtıyla, SSH ile doğrulandı)
- **Cihaz YENİ test37'yi çalıştırıyor** (kullanıcı build bitince yüklemiş; SSH ile doğrulandı). dmesg'te 2010c print'leri VAR:
  ```
  MR47BE: wcss_sec_start pasid=13 mem_phys=0x000000004a900000 mem_size=45088768
  MR47BE: pas_mem_setup ret=0
  MR47BE: mpd pas=13 dbg=0 cmd=24 ret=-12 res0=0 res1=0 res2=0
  qcom-wcss-secure-pil d100000.remoteproc: wcss_reset failed  → Q6 hâlâ -12
  ```
- **KAZANIM 1 — pas_mem_setup ÇALIŞIYOR (`ret=0`):** TZ, PAS_MEM_SETUP (cmd 0x05) çağrısını **KABUL ETTİ** — asıl aday -12 kaynağı değil, elendi. Linux↔TZ SCM kanalı bu çağrıda SAĞLAM.
- **KAZANIM 2 — 3-arg auth TZ'ye ULAŞIYOR ve TZ KENDİ ENOMEM'İNİ DÖNÜYOR (KESİN):** `qcom_scm_remap_error` tablosuna göre (`drivers/firmware/qcom/qcom_scm.h`): `QCOM_SCM_ENOMEM = -5` → `remap_error(-5) = -ENOMEM (-12)`. **res0=0 = TZ hata kodu dönmeden önce sonuç kayıtlarını doldurmadı.** Yani: Linux SMC yolu 0 hatasız çalıştı, **TZ/QSEE PAS_AUTH_AND_RESET içinde ENOMEM verdi** → Linux -12'ye çevirdi. "-12 = Linux tzmem alloc" teorisi DEĞİL, TZ tarafı ENOMEM.
- **KAZANIM 3 — "-22 → -12" zinciri çözüldü:** -22 (EINVAL, 1-arg reddi) → 3-arg ile -12'ye düştü → şimdi bunun **TZ'nin kendi bellek yetersizliği** olduğu kanıtlandı (önceki ENOMEM teorileri -12'yi Linux'a bağlıyordu; YANLIŞ çıktı).
- **KAZANIM 4 — WAN/LAN/SSH/LuCI regresyon YOK:** `Link is Up 2.5Gbps`, SSH OK, board "Mercusys MR47BE V2" OK.
- **BOZUK KALANLAR:** ① Q6 2.4G — `auth_and_reset` TZ ENOMEM → `RootPD boot failed -12` → `ath12k_wifi7_ahb probe failed -12`. ② QCN6274 (PCIe 5/6G) — `MSI vectors 16` sonrası MHI sessiz; `consumer:platform:c000000.wifi` devlink bağı var; `iw phy` boş.
- **SONRAKİ (test38) hipotezler — TZ ENOMEM nedenleri:**
  1. **q6_region 43MB yerine vendor 35MB (0x2300000) dene** — TZ'nin beklediği bölge boyutu farkı ENOMEM yapabilir.
  2. **Firmware: eski MR47BE_OPENWRT ağacındaki 11812B q6_fw0** (segment boyutları flint3'ten FARKLI: b03=207956, b05=18256, b07=541840, b08=110244, b09=54348, b11=1712) → İMAJA kopyala dene — vendor'a daha yakın. (15472B stok fw hâlâ çıkarılmadı.)
  3. **reset_cmd_id=0x18 → 0x14 dene** (IPQ5018 değeri; MR47BE GPL'de net değil).
  4. pas_init_image/metadata SHM-bridge akışını TZ ENOMEM açısından doğrula (2012 patch yüklü ama doğrulanmadı).
- **KAYIT:** Bu oturumda yapılanlar: 2010c yazıldı (pas_mem_setup+print), B37/B37v2 rc=2 (QMI kernel_connect fix UYGULANMAMIŞTI — root'ta yanlış konum), qmi.c'ye direkt fix → **B37v3 rc=0 BAŞARILI**, imajlar kopyalandı ve SHA doğrulandı, cihazda SSH ile test37 teyit. Build log: `/root/build-test37.log`; patch: `patches-6.18/2010c-...patch`; yedekler: `/root/wcss_sec.c.orig37`, `/root/qcom_scm.c.orig37`.
- **TEST37 BOOT REÇETESİ (imaj kopyalanınca):**
  - TFTP: `E:\ROUTER\router\GL-BE9300 (Flint 3)\imajlar\test37\openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb`
  - U-Boot: `setenv serverip 192.168.1.100; setenv ipaddr 192.168.1.1; tftpboot 0x46000000 openwrt-qualcommbe-ipq53xx-mercusys_mr47be-v2-initramfs-uImage.itb; bootm 0x46000000`
  - OpenWrt açılınca UART'a TEK SATIR: `dmesg | grep MR47BE; dmesg | grep -iE "wcss|remoteproc|ath12k" | tail -20`
  - Beklenen satırlar: `MR47BE: wcss_sec_start pasid=13 mem_phys=0x4a900000 mem_size=45088768` · `MR47BE: pas_mem_setup ret=...` · `MR47BE: mpd pas=13 dbg=0 cmd=24 ret=... res0=... res1=... res2=...`
  - Sonuç bu dosyanın §26'sına YAZILACAK (karar ağacı yukarıda).
- **OTOMASYON (bu oturum):** `/root/finish37.sh` detached çalışıyor — `B37.DONE`'u bekler (≤30 dk), imajları `/mnt/e/.../imajlar/test37/`'e kopyalar, `test37-sha256.txt` yazar, `/root/finish37.flag` oluşturur. Session ölürse bile kopyalama server-side tamamlanır.
- **VENDOR FW BULGUSU:** eski MR47BE_OPENWRT ağacındaki `q6_fw0.mdt` de 11812B (flint3 ile aynı sürüm ailesi; b03/b05/b07/b08/b09/b11 boyutları farklı → içerik farklı). "_gl_beta/wifi_fw" kopyası da aynı. **Gerçek vendor 15472B fw elimizde YOK** — gerekirse stok imajdan (squashfs dump) çıkarılacak. `_loglar\vendor_fw37.txt`'de liste var.


## 28. ⭐⭐ ATLADIĞIMIZ ŞEY BULUNDU (07-09 — Askey karşılaştırması: ath12k PATCH SETİ EKSİK + QCN9274 FW BOŞ!)

**Kullanıcı ipucu:** Askey SBE1V1K (IPQ9570 — AYNI QCN6274 5/6G 4×4, tek wiphy 3 radio) OpenWrt'ta wifi'yi AYAĞA KALDIRMIŞ. **Fark = bizim ağaçta mac80211/patches/ath12k/ KLASÖRÜ YOK → ath12k VANILLA derleniyor.**

### A) Askey'in ath12k patch seti (9) — `package/kernel/mac80211/patches/ath12k/`
| Patch | Ne yapıyor | Bizim belirtiyle ilişkisi |
|---|---|---|
| 001 | hwmon sıcaklık | — |
| **100** | **ath12k_pci_enable_ltssm → return; (BPI-Rx = IPQ53xx crash fix)** | **"MSI 16 sonrası MHI sessiz" ile BİREBİR** |
| 102 | WMI_SCAN_CHAN_LIST arg ≥2048 fix | 5/6G tarama |
| 103 | wideband QCN9274 5GHz HT/VHT caps | 5GHz band |
| 104 | wideband regd 5GHz düşmesin | 5GHz band |
| **200** | **CE interrupt tasklet→BH workqueue REVERT** | **MHI sessiz ile BİREBİR** |
| 300 | thermal symbol | — |
| 400 | per-radio MAC from DT (wiphy addresses[]) | 3 radio tek wiphy |
| **700** | **calibration-variant from DT (BDF seçimi)** | **caldata/BDF seçimi** |

### B) Bizde durum (37 test boyunca HİÇ bakmadığımız katman!)
- `package/kernel/mac80211/patches/ath12k/` **YOK**. Sadece elle eklediğimiz `020-ath12k-qmi-fix` patches/ **KÖKÜNDE** → Makefile `PatchDir ... ath12k/` alt dizinini taradığı için **o bile uygulanmıyor** (test36'da elle kaynağa işlemiştik, patch mekanizması boş)
- Makefile:352 `$(call PatchDir,$(PKG_BUILD_DIR),$(PATCH_DIR)/ath12k,ath12k/)`
- DTS'te `qcom,calibration-variant` YOK (bizde `qcom,board-id` var) — Askey'de 3 wifi node'unda var
- BDF'te `variant=` string'i YOK (sadece `qmi-board-id=4121`)
- Build_dir ath12k kaynağında LTSSM fonksiyonu grep'te yok → en az 100/200 patch'leri vanilla'da yok

### C) Firmware durumu (ikinci eksik)
- bizim `ath12k-firmware` paketi: **PKG_SOURCE_DATE=2026-01-21** (7 AY ESKİ! src/ gömülü)
- `build_dir/.../ath12k-firmware/QCN9274/hw2.0/` = **SADECE regdb.bin (25KB)** — MHI fw dosyaları YOK (paket sadece BDF/regdb içeriyor)
- LuCI'de görülen güncel paket: **ath12k-firmware-qcn9274-20260810-r1 (6.8MB)** — APK indirildi `/root/ath12k-fw-new.apk` (apk v3 imzalı, açma işlemleri sürüyor)
- `ipq-wifi` (BDF paketi) = 2026-05-18 `e20f4c6f` — Askey ile **AYNI** (BDF/fw yaşı tek başına engel değil)
- **OpenWrt main'de ath12k-firmware paketi `package/firmware` içinde ARTIK YOK** (taşınmış); `owrt-packages` klonu `git.openwrt.org/feed/packages.git` devam ediyor, path aranıyor
- **Bulgu:** `jiay-wlan-ap/feeds/qca-wifi-7/ath12k-firmware/files/IPQ5332/` = Qualcomm resmi qca-wifi-7 feed'i — q6_fw0.bxx, iu_fw, Data.msc DOSYALARI VAR (bizim build'deki 11812B q6_fw0.mdt ile kıyaslanacak)

### D) TEST38 PLANI (önerilen öncelik sırası)
1. **Askey'in 9 ath12k patch'ini bizim ağaca KOY** (`patches/ath12k/` klasörü oluştur; 020'yi de oraya taşı) — düşük maliyetli, 100/200'ün MHI belirtisine etkisi doğrudan test edilebilir
2. **DTS'e `qcom,calibration-variant` ekle** (wifi1 node'u; BDF'te variant string'i ile eşleşmeli)
3. **QCN9274/hw2.0'a gerçek MHI fw koy** (güncel APK'dan veya qca-wifi-7'den) — MHI firmware yoksa ath12k hiç konuşmaz
4. BDF variant string'i ilgili kayıtları doğrula (bizim BDF mi eksik, Askey'inkini mi kullanmalı)

### E) Oturum kayıtları
- Askey zip tam açıldı: `/root/askey-sbe1v1k-20260907/SBE1V1K-main/` (11415 dosya) — E:'deki klasör eksikti
- Askey BDF: `package/firmware/ipq-wifi/src/board-askey_sbe1v1k.qcn9274` (variant=Askey-SBE1V1K_1/2/4)
- Askey DTS: `target/linux/qualcommbe/dts/ipq9570-sbe1v1k.dts` — 3 PCIe (pcie1/2/3) + `qcom,wsi-controller` + per-radio nvmem MAC
- Askey patch listesi çıkarıldı (9 dosya, E: klasöründen okundu)
- Güncel OpenWrt main ipq-wifi Makefile: PKG_SOURCE_DATE=2026-08-23 `0c67bbcc` — askey_sbe1v1k artık RESMİ board listesinde
- APK çözme araçları: `_yedekler/apk_extract.sh`, `_yedekler/apk_scan.py`
## 29. ⭐⭐ TEST38 HAZIRLIK TAMAM (08-09 — APK AÇILDI: MHI firmware BULUNDU + 10 patch ağaçta!)

### A) 🎯 ALTIN BULGU — QCN6274 MHI FIRMWARE EKSİKTİ (KÖK NEDEN ADAYI #1)
- **Güncel `ath12k-firmware-qcn9274-20260810-r1.apk` (6.8MB) AÇILDI** (apk-tools 3.0.8 + `--allow-untrusted`; apk v3 formatı = ADBd imza bloğu + tar.gz)
- **İçerik (`lib/firmware/ath12k/QCN9274/hw2.0/`):**
  | Dosya | Boyut | Anlamı |
  |---|---|---|
  | **`firmware-2.bin`** | **16 MB** (16035896 B) | **QCN9274/QCN6274 MHI firmware — BİZDE HİÇ YOKTU!** |
  | `board-2.bin` | 2.6 MB (2626240 B) | çoklu-board BDF container |
  | `Notice.txt` | 156 KB | sürüm notu |
- **Bizim build:** `ath12k-firmware/src/QCN9274/hw2.0/` = **SADECE regdb.bin** (25KB) → cihaza MHI firmware **HİÇ GİTMEMİŞ** → `MSI 16 sonrası MHI sessiz`'in en güçlü açıklaması bu!
- **YAPILDI:** `firmware-2.bin` → `/root/flint3-mr47be-20260903/package/firmware/ath12k-firmware/src/QCN9274/hw2.0/` (16MB) kopyalandı
- apk-tools 3.x açma reçetesi (apk v3): `wsl ... curl -sL -o apk3.apk https://dl-cdn.alpinelinux.org/alpine/edge/main/x86_64/apk-tools-static-3.0.8-r0.apk && tar xzf apk3.apk && ./sbin/apk.static --allow-untrusted extract xyz.apk` (extract `-o`/`--output` DESTEKLEMİYOR — cwd'ye açar!)
- APK v3 yapısı: başta `ADBd` (imza/dosya yolu bloğu) + arkası tar.gz. `bzip2 @4196412` ve `gzip @5251889` bu TAR'I İÇİNDEKİ binary veriden tesadüf yakalamış (fantoma).

### B) 10 ath12k PATCH AĞAÇTA ✅
- `/root/flint3-mr47be-20260903/package/kernel/mac80211/patches/ath12k/` = 001, 020(qmi-fix taşındı), 100, 102, 103, 104, 200, 300, 400, 700
- **020 qmi-fix artık Ath12k/ içinde** → Makefile `PatchDir ... ath12k/` taraması artık onu da uygulayacak (test36'da elle işlemiştik; artık mekanizma düzgün)

### C) ipq-wifi BDF durumu
- Makefile line 73/276 `mercusys_mr47be-v2` KAYITLI ✓
- BDF: `bus=pci,qmi-chip-id=0,qmi-board-id=4121` — **variant string'i YOK** (Askey'de `variant=Askey-SBE1V1K_1/2/4` var)
- NOT: yeni board-2.bin 2.6MB = çoklu board tek dosya → ath12k board-id'ye göre seçecek; bizim ayrı BDF'ler (board-mercusys_mr47be-v2.qcn9274) ipq-wifi paketinden `board-2.bin` olarak QCN9274/hw2.0'a düşüyor. `firmware-2.bin` ise MHI'in kendisi.
- QUESTION: ath12k firmware-2.bin varlığında board-2.bin olarak hangisi kazanır (yeni fw's board-2.bin 2.6MB mı, bizim 187KB mr47be BDF mi)? Build'de göreceğiz.

### D) Build durumu / sıradaki
- Kernel ath12k kaynağı build_dir'de HENÜZ yok (temiz derleme gerekli), `mac80211-regular` pkbuild var
- **TEST38 = şu değişikliklerle TAM BUILD:** ① ath12k patch seti (10) ② firmware-2.bin QCN9274/hw2.0'da ③ (opsiyonel) DTS calibration-variant
- Build komutu (standart): `wsl -d Ubuntu-24.04 -- bash -c 'cd /root/flint3-mr47be-20260903 && env FORCE_UNSAFE_CONFIGURE=1 make -j4 > /root/build-test38.log 2>&1; echo DONE'` → imajlar `imajlar\test38\`

## 30. ⭐ TEST38 BUILD — PATCH DURUMU + BAŞLANGIÇ (08-09)

### A) mac80211 prepare testi sonuçları (backports-7.2-rc4 / kernel 6.18.39)
| Patch | Sonuç | Not |
|---|---|---|
| 001 hwmon | ❌ ÇIKARILDI | `thermal.c already exists` — kernelde zaten var (upstream'e girmiş) |
| 020 qmi-connect fix | ✅ | Elle yeniden yazıldı (tab sayısı düzeltildi) |
| 100 ltssm crash fix | ✅ | BPI-Rx / IPQ53xx crash fix |
| 102 WMI scan chan list | ❌ ÇIKARILDI | context uyuşmuyor (farklı kernel rev) |
| 103 5GHz wideband caps | ✅ | |
| 104 regulatory range | ✅ | |
| 200 CE interrupt revert | ✅ | tasklet→BH workqueue geri alındı |
| 300 thermal symbol | ✅ | |
| 400 per-radio MAC | ❌ ÇIKARILDI | context uyuşmuyor |
| 700 calibration-variant | ✅ | DT'den BDF variant okuma |

**mac80211 prepare BAŞARILI** → 8 patch uygulandı (001/102/400 çıkarıldı).

### B) firmware-2.bin eklendi
- `/root/flint3-mr47be-20260903/package/firmware/ath12k-firmware/src/QCN9274/hw2.0/firmware-2.bin` (16MB) kopyalandı
- Yeni APK'dan çıkarılan dosyalar: `firmware-2.bin` (16MB) + `board-2.bin` (2.6MB) + `Notice.txt`
- board-2.bin (2.6MB, çoklu-board) ve Notice.txt EKLENMEDİ (sadece firmware-2.bin) — ipq-wifi BDF'miz (mr47be) korunacak

### C) TEST38 build
- Komut: `cd /root/flint3-mr47be-20260903 && env FORCE_UNSAFE_CONFIGURE=1 make -j4 > /root/build-test38.log 2>&1`
- Log: `/root/build-test38.log`
- İmajlar: `imajlar\test38\` (build bitince kopyalanacak)
- Build ~20-40 dk sürebilir
- Dikkat: ath12k patch'leri vanilla 6.18 kaynağına uyum sağlamalı (Askey IPQ95xx aynı 6.18 ağacından; fark target'tan değil kernel sürümünden olabilir). 020 eskiden elle işlendiği için çakışma ihtimali düşük ama makro `prepare` temizliği önerilir: `make package/kernel/mac80211/clean`
## 31. ⭐ TEST38 CİHAZDA — SSH İLE DOĞRULANDI (07.09, 11:00 — bu oturum)

### A) Cihaz durumu (test38 RUNNING — initramfs)
- `ubus call system board`: kernel 6.18.39 · model "Mercusys MR47BE V2" · board mercusys,mr47be-v2 · rootfs_type **initramfs** · r0-a655214.
- WAN 192.168.0.103 (DHCP ✓) · br-lan 192.168.1.1 · `Link is Up 2.5Gbps` (lan+wan) · SSH/LuCI ✓ → **ETHERNET REGRESYON YOK**.
- `iw dev` / `wifi status` BOŞ · `uci show wireless` boş → **3 radyo hâlâ YOK** (kullanıcı teşhisi "düzelen bir şey yok" doğrulandı).

### B) ⚡ MHI FIRMWARE HİPOTEZİ ÇÖKTÜ (§29A "altın bulgu" YANLIŞ çıktı)
- Cihazda `/lib/firmware/ath12k/QCN9274/hw2.0/` = firmware-2.bin **16,035,896 B** + board-2.bin 187,596 B (bizim ipq-wifi BDF) + Notice.txt.
- **SHA256 ÜÇLÜ EŞLEŞME:** cihazdaki firmware-2.bin = WSL `/root/apkx3/...` (20260810-r1 apk içinden) = build-tree kopyası → hepsi `5115c1c1e91278f0c50dcf2bbdacf9ba666cd5e99d225005c4d462d234deebfc`.
- Yani ağaçtaki eski-etiketli `ath12k-firmware-qcn9274-20260622-r1` paketi **AYNI MHI fw'yi** kuruyor → LuCI Software'de görünen "20260622-r1 » 20260810-r1 (6.54 MiB)" güncellemesi **içerik olarak boş** (sadece sürüm etiketi farkı).
- **test37 manifest'inde de `ath12k-firmware-qcn9274 - 20260622-r1` VARDI** (imajlar\test37\*.manifest doğrulandı) → MHI fw test37'de de imajdaydı → "QCN9274 MHI fw eksikti" teorisi test25'ten beri yanlıştı; test38'de hiçbir şeyin düzelmemesi bununla uyumlu.
- DERS: build çakışmalarında paket kaldırırken içerik eşitliğini SHA ile doğrula + manifest'leri imajlar arası karşılaştır.

### C) PCI (QCN6274) probe analizi — sessizliğin YERİ ilk kez netleşti
- PCI EP 0001:01:00.0 `[17cb:1109]` → `ath12k_wifi7_pci` sürücüsüne **BOUND** (readlink doğrulandı; probe hata satırı YOK).
- MHI controller KAYITLI: debugfs `mhi0` var · /proc/interrupts'ta 2× "mhi" IRQ (49/50, GICv2m-PCI-MSI) ama **0 kesme**.
- dmesg: `MSI vectors: 16` (7.841s) sonrası ath12k/mhi/qmi/bdf **SIFIR satır**; kmodloader 7.867'de bitti → **probe ~30ms'de tamamlandı** → 16MB fw yüklemesi (mhi_sync_power_up) probe sırasında **hiç başlamadı**; "mhi ... Requested to power ON" da YOK.
- `devices_deferred` BOŞ → deferred-probe senaryosu elendi. PCIe Gen.3 x2 link up, EP enumerate ✓.
- lsmod: ath12k (548864) + **ath12k_wifi7** (86016) + compat/mac80211/cfg80211/mhi/qrtr_mhi · remoteproc0 state=offline, fw=q6_fw0.mdt (11812 ✓).
- ath.mk:381-382 → kmod-ath12k hem `ath12k.ko` hem `wifi7/ath12k_wifi7.ko` kuruyor (AYNI backports ağacının 2. derlemesi) → **patch'ler çalışana sürücüde**: backports qmi.c:3926'da 020 izi yerinde (`(struct sockaddr *)sq` fix) → 6 patch (020/100/103/104/300/700) ath12k_wifi7'ye de gitti.
- ŞÜPHE (test39'da debug ile kesinleşecek): probe sync power-up yapmadan 30ms'de dönüp bind oluyorsa power_up ertelenmiş demektir — core.c hw-group (MLO) bekleme mantığı veya QMI-event gated akış. AHB (2.4G) probe'u -12 ile öldüğü için grup asla tamamlanmıyor olabilir → PCI sonsuza kadar bekliyor (tüm test25+ gözlemlerini açıklıyor).

### D) Deney bedeli — cihaz ÇÖKTÜ (yeniden boot ŞART)
- debug_mask denendi: `/sys/module/ath12k/parameters/debug_mask` **YANLIŞ modül** — çalışan modül **ath12k_wifi7** (V2 dokümanındaki "modül adı ath12k DEĞİL" uyarısı aynen doğru çıktı). Doğru yol: `/sys/module/ath12k_wifi7/parameters/debug_mask` veya cmdline `ath12k_wifi7.debug_mask=0xffffffff`.
- `echo 1 > /sys/bus/pci/devices/0001:01:00.0/remove` + `/sys/bus/pci/rescan` → **kernel hard-crash** (SSH "Connection reset", ardından ping %100 loss, SSH timeout). initramfs → kendi kendine gelmez.
- **CIHAZ ŞU AN ÖLÜ → UART/TFTP ile test38 (veya test39) yeniden boot edilecek. ÇIKARIM: bu build'de ath12k_wifi7_pci remove/re-probe yolu zehirli — canlı re-probe denemesi YAPMA, debug'u boot cmdline'ından ver.**
- Takip (11:15): çökme sonrası cihaz kendi kendine resetlendi — ping cevaplıyor ama port 22 sürekli kapalı (>1 dk) → **U-Boot TFTP aşamasında takılı** (bootloader ARP/ping'e cevap veriyor, kernel'a geçemiyor; PC'de TFTP sunucu kapalı olabilir) ya da boot döngüsü. Çözüm: PC'de TFTP sunucuyu aç (serverip 192.168.1.100/.2) veya UART'tan elle `tftpboot 0x46000000 <initramfs.itb>; bootm 0x46000000`.

### E) qrtr-ns EKSİK (yeni kesin bloker adayı)
- Manifest: kmod-qrtr / kmod-qrtr-mhi / kmod-qrtr-smd / kmod-qcom-qmi-helpers VAR ama **userspace `qrtr-ns` daemon YOK** (`.config`'de yok, ağaç feeds'inde de paket yok; `ps | grep qrtr` boş).
- PCI ath11k/ath12k QMI service discovery qrtr-ns ister (upstream wiki gereksinimi) → **test39'da eklenmeli**: upstream packages feed'inden `package/net/qrtr-ns` (andersson/qrtr, procd init scripti ile) + `CONFIG_PACKAGE_qrtr-ns=y`.

### F) TEST39 planı (öneri sırasıyla)
1. **qrtr-ns** paketini ağaca ekle + .config (§31E).
2. **`ath12k_wifi7.debug_mask=0xffffffff`** modül paramı (CONFIG_CMDLINE veya /etc/modules.d/ath12k satırına) → boot'tan tam ath12k dbg izi; İLK ARANAN: `ath12k_core_init: num devices N num probed M` + power_up'ın nerede durduğu (§31C şüphesi: hw-group/MLO bekleme).
3. MHI power-up zincirini kaynakta izle: core.c soc_create:854 `ath12k_hif_power_up` → pci.c:1427 `ath12k_pci_power_up` → mhi.c:421/439 — bunun PCI probe akışında NEREDE çağrıldığını/ertelendiğini tespit et; hw-group `num_probed` mantığını AHB-fail etkisiyle doğrula.
4. Q6 (2.4G): test38, 11812B eski-ağaç q6_fw0'ı imaja aldı (boot log `size 11812` ✓ imajda) → **sonuç yine TZ ENOMEM** (`mpd pas=13 dbg=0 cmd=24 ret=-12 res0=0`) → eski-fw hipotezi de ELİNDİ (§27 liste başlığı 2 kapandı). Kalan: vendor q6_fw0 (15472B) çıkarma, reset_cmd_id 0x14, tzmem teşhisi (§27 karar ağacı).
5. Disiplin (kullanıcı talebi): artık her imaj sonrası bu §31 tarzı cihaz-dozdoğrulama + manifest diff + SHA karşılaştırma standart akış; "hata al → bir şey çıkar → build geç" döngüsü yerine her çıkarmanın içeriğe etkisi kanıtlanacak.

### G) KİMLİK SORUSU KESİNLEŞTİ (07.09 — build ağacı kanıtları; soru: "ath12k mi ath12k_wifi7 mi? QCN6274 PCIe mi?")
**İKİSİ DE KESİN.** kmod-ath12k (CONFIG_PACKAGE_kmod-ath12k=y, .config:3080) İKİ modül kuruyor (ath.mk:381-382; aynı backports-7.2-rc4 ağacının 2. derlemesi):
- `ath12k.ko` — name=ath12k, **hiç alias yok** (modinfo -F alias BOŞ) → kendi başına hiçbir aygıta bağlanmaz; ortak kütüphane katmanı (ahb/pci_register_driver, mac_op'lar, dbg fonksiyonlarını EXPORT eder).
- `ath12k_wifi7.ko` — name=ath12k_wifi7, depends: ath12k,mhi,mac80211,cfg80211,compat. Alias'ları: `pci:v000017CBd00001109` (+1107/1112 WCN7850 ailesi) + OF `qcom,ipq5332-wifi(C)` → **HEM PCI QCN6274 HEM AHB 2.4G'yi BU modül bağlar** (nm -u: ath12k_pci_register_driver + ath12k_ahb_register_driver regular'dan import). Canlı doğrulama: dmesg DRIVER=ath12k_wifi7_pci (§31C, §17.7).
- **QCN6274 = PCIe, KESİN (4 bağımsız kanıt):** ① DTS ipq5332-mr47be-v2.dts:7-8, 563-578 → `&pcie1` altında `wifi1: pcie@0 { compatible = "pci17cb,1109"; }` (5G+6G 2 radyo; WSI endpoint'leri wifi0 2.4G ile bağlı) ② canlı dmesg: PCI_ID=17CB:1109, PCIe Gen3 link up, DRIVER=ath12k_wifi7_pci ③ foto: çip marking QCN6274 JE510CV2 ④ kaynak: pci.c:20 `QCN9274_DEVICE_ID 0x1109` → hw_rev=QCN9274_HW20 → fw dizini "QCN9274/hw2.0". **"ath12k-firmware-qcn9274" paket adı çip değil FW DİZİNİ adıdır; QCN6274 bu fw ailesini kullanır.**
- 2.4G on-SoC IPQ5332 (wifi0, AHB, OF alias qcom,ipq5332-wifi; board-id 0x12) — aynı ath12k_wifi7 modülü bağlar.
- Flint3 vs MR47BE: AYNI çip + AYNI PCIe transport (17CB:1109); fark yalnız board-id/BDF (Flint3 0x1019=4121, MR47BE 0x1015=4101; DTS'te 0x1015). Karıştırılacak tek şey bu.
- ⚠️ **DEBUG PARAM DÜZELTMESİ (§31F madde 2'yi DEĞİŞTİRİR):** ath12k_wifi7 modinfo parm BOŞ → `ath12k_wifi7.debug_mask=` cmdline'ı unknown-param riskiyle modül yüklemesini bozabilir → YAPMA. Regular ath12k'de param VAR (core.c:28 `module_param_named(debug_mask, ath12k_debug_mask, uint, 0644)`) ama İŞLEVİSİZ: backports .config:60 `CPTCFG_ATH12K_DEBUG is not set` → her iki modülde ath12k_dbg no-op (wifi7 nm -u'da __ath12k_dbg importu YOK; §31D'deki "yanlış modüle yazdım" teşhisinin kökü bu). DEBUGFS zaten y. **Tek doğru yol: build'de CPTCFG_ATH12K_DEBUG=y → test39 debug izi build flag'iyle alınacak, modül parametresiyle değil.**

### H) TEST39 HAZIRLIK + KAYNAK ANALİZİ (07.09 öğleden sonra — hepsi build ağacı kaynak kanıtı, tahmin değil)
1. **NSSCC gizemi çözüldü:** config-6.18:226 "not set" ŞABLON satırıymış; GERÇEK build .config:3883-3887 → `CONFIG_IPQ_NSSCC_5332=y` + `CONFIG_IPQ_NSSCC_QCA8K=y`; nsscc-ipq5332.o + nsscc-qca8k.o derlenmiş, vmlinux'ta nsscc_ipq5332 sembolü (3 eşleşme) → **sürücü zaten kernelde, düzeltme gerekmedi**. (Mistral'in tek "isabetli" ipucu zaten yapılmıştı; forum/Mercusys "kanıt" linkleri uydurma çıktı — detay _yedekler\Mistral Ai sohbeti incelemesi.)
2. **`pci 0001:00:00.0 [17cb:1005]` = SoC PCIe ROOT PORT** (type 01, class 0x060400 köprü) — wifi DEĞİL. EP = 0001:01:00.0 **[17cb:1109]** = QCN6274. test27 satırı ile test38 çelişkisi YOK (root port her imajda var).
3. **§31C SIRRI ÇÖZÜLDÜ (kaynak kanıtı):** PCI probe akışı (regular pci.c ~1540-1650): family_ops->probe (wifi7/pci.c:174 hw_init ✓) → msi_alloc (**"MSI vectors: 16" @7.841s = test38 loguyla birebir**) → core_pre_init → **ath12k_mhi_register (pci.c:1604 — PROBE İÇİNDE, power_up DEĞİL!)** → hal_srng/ce/qmi-ce/irq config → arch_init → **EN SON ath12k_core_init**. Yani test38'deki "mhi0 kayıtlı + 2 IRQ ama power_up yok" = probe tamamlandı, core_init SESSİZCE PARK ETMİŞ (hata YOK). core.c: core_init(2251) → hw_group_assign → dbg "num devices N num probed M" → create_ready(1846: `num_probed == num_devices`) SAĞLANIRSA group_create → soc_create(837: qmi_init_service → **hif_power_up:854**) → pci power_up → MHI prepare/sync → fw yükleme.
4. **GRUP (WSI) HİPOTEZİ — artık güçlü:** assign() WSI DT grafiğinden grup kurar (get_wsi_info endpoint zinciri yürür; WSI yoksa "unable to get wsi info from dt, grouping single device" → num_devices=1). DTS'te wifi0↔wifi1 WSI ports VAR idi → num_devices=2. AHB probe RootPD -12 (ahb.c:859) ile ölünce grup ASLA ready olmuyor → PCI core_init'te sonsuza kadar bekliyor. test31'in (wifi0 disabled) işe yaramaması da uyumlu: WSI DT'de durdukça graf 2 sayıyor.
5. **TEST39 DTS DEĞİŞİKLİKLERİ (UYGULANDI; yedek ipq5332-mr47be-v2.dts.bak_test39_20260907):** ① wifi1 board-id 0x1019→**0x1015** (satır 580; MR47BE vendor değeri İLK KEZ deneniyor — §6.8/345'teki fark; bayat yorum satır 8'in iddiası buydu ama property 0x1019'du!) ② **her İKİ WSI ports bloğu SİLİNDİ** (wifi1 583-602, wifi0 637-656; çapraz label referansları yüzünden ikisi birden; dosya 662→622 satır) → her radyo tekil gruba düşer → PCI create_ready hemen TRUE → power_up zinciri başlamalı.
6. **TEST39 DEBUG (UYGULANDI; yedek Makefile.bak_test39_20260907):** package/kernel/mac80211/Makefile:274 `config-y += ATH12K_DEBUG` → CPTCFG_ATH12K_DEBUG=y (backports Kconfig kendi de "If unsure, say Y" diyor). wifi7 modülü artık __ath12k_dbg'lı derlenir; kapı = paylaşılan ath12k_debug_mask (regular ath12k) → **cihazda runtime aç: `echo 0xffffffff > /sys/module/ath12k/parameters/debug_mask`** (cmdline GEREKMEZ; §31G'deki unknown-param riski yok).
7. **qrtr-ns (YARIDA KALDI — yazılacak):** openwrt packages feed'inde YOK (raw 404). Kaynak: **linux-msm/qrtr v1.2** (repo andersson/qrtr'dan taşındı; v1.2 commit `b51ffaf22707b6000ecfb894c5b750f3bb7843b2`). v1.1/v1.2 **meson** tabanlı (root Makefile yok): libqrtr SHARED lib + qrtr-ns + qrtr-lookup + qrtr-cfg; meson_options: qrtr-ns/systemd-service feature'ları; ağaçta include/meson.mk VAR → paket meson.mk ile yazılacak + files/qrtr-ns.init (procd, START=20, respawn) → .config `CONFIG_PACKAGE_qrtr-ns=y` → defconfig → build.
8. **TEST39 BEKLENTİ / DEĞİŞKENLER:** ① WSI kırılırsa boot logda `wsi group-id ... num-devices 1` + `num devices 1 num probed 1` beklenir; PCI artık qmi/hif_power_up/MHI fw (16MB) akışına girmeli ② qrtr-ns imajda yoksa fw boot etse bile QMI service discovery ölür → paket şart ③ board-id 0x1015 yalnız BDF seçiminde etkili (QMI sonrası); "board data" search fail ederse tek satırla 0x1019'a dönülür ④ 2.4G (AHB) beklentisi DEĞİŞMEDİ: RootPD -12 (TZ ENOMEM) sürer — ayrı cephe §27 ⑤ **cihaz HÂLÂ U-Boot/TFTP'de** (ping var, SSH kapalı); test39 initramfs hazır olunca PC'de TFTP sunucu (serverip 192.168.1.100/.2) veya UART `tftpboot 0x46000000 <itb>; bootm` ile yüklenecek ⑥ logda aranacaklar: "Kernel command line", "num devices", "wsi group-id", "QMI", "mhi", "board data"/"BDF", "ath12k_wifi7_ahb".
9. **BUILD TAMAM ✓ (07.09 13:56) — imajlar\test39\ READY:** initramfs-uImage.itb **22,724,208 B** (22.7MB ✓ normal) + uImage.itb (sysupgrade 6.0MB) + manifest (173 satır, `qrtr-ns - 1.2-r1` + kmod-ath12k + fw'ler ✓) + sha256sums. Doğrulamalar: FIT kernel-1 = 21.64 MiB (rootfs gömülü ✓); DTB decompile → `qcom,board-id = <0x1015>` ✓, WSI ports YOK ✓ (yalnız `qcom,wsi-controller` property kaldı); vmlinux-initramfs içinde qrtr-ns/libqrtr strings ✓; CPTCFG_ATH12K_DEBUG=y ✓ (build .config:60).
10. **⚠️ DERS — CRLF TUZAĞI (bu build'i 2 saat uğraştırdı):** Windows editörüyle yazılan `qrtr.init` CRLF ile install edilince rc.d symlink adı `S20<CR>qrtr` oldu → kernel `gen_init_cpio` **"Unrecognized dir format ... line 286" Error 255** ile cpio üretimi çöktü; reçete `;` zinciri hatayı YUTTUĞU için build "başarılı" görüp **6MB'lık rootfs'siz initramfs** üretti (sessiz bozuk imaj!). Kök neden zinciri: qrtr-ns eklendi → `package/cleanup` = `rm -rf STAGING_DIR_ROOT` + staging rootfs yeniden kuruldu → bozuk symlink → kernel `target/compile` anında staging'i bake'lerken cpio patladı. Ayrıca `Image/Build/Initramfs` makrosu bu ağaçta tanımsız (upstream'de de) → target/install initramfs kernel'i ASLA yeniden bake etmez; staging temizken (incremental build) target/compile'daki bake big olur. **KURAL: Windows'ta yazılan tüm paket dosyaları ağaca girmeden `tr -d '\r'`'dan geçirilecek + her build sonrası initramfs itb boyutu ~22MB kontrolü.** (qrtr.init/Makefile şimdi LF; staging rc.d symlinkleri elle onarıldı: S20qrtr ✓)
11. **SIRADAKİ ADIM (test39 UART/TFTP):** cihaz HÂLÂ U-Boot'ta — imajlar\test39\initramfs-uImage.itb'yi TFTP ile yükle (PC sunucu 192.168.1.100/.2 veya UART `tftpboot 0x46000000 ...; bootm`). Boot sonrası: `iw dev`/`wifi status` 3 radyo? · `ps | grep qrtr` (qrtr-ns çalışıyor mu) · `echo 0xffffffff > /sys/module/ath12k/parameters/debug_mask` (runtime debug, reboot gereksiz) · dmesg'de aranacaklar: "num devices 1 num probed 1" (WSI teorisi ✓ ise), "wsi group-id", QMI/mhi/fw yükleme satırları, "board data" (0x1015 BDF eşleşmesi). 2.4G beklenen: RootPD -12 (ayrı cephe §27).

### I) TEST39 BOOT SONUÇLARI — TARİHÎ KIRILMA: QCN6274 FIRMWARE CANLI ✅ (07.09 ~13:51 boot; cihazda SSH analizi; canlı veri, tahmin değil)
**WSI KIRMA DENEYİ BAŞARILI — §31C sorusu çözüldü:** dmesg canlı akışı (t=sn):
- 7.624 AHB probe (`ipq5332 hw1.0`) → 7.649 `q6_fw0.mdt size 11812` → **7.671 RootPD -12** (`pasid=13 mem_size=45088768` = 43MB ✓, `cmd=24 ret=-12`) → AHB yine öldü (beklenen, §27)
- **7.724 PCI probe başladı: `qcn9274 hw2.0` → 7.731 `MSI vectors: 16` → 7.806 `mhi mhi0: Requested to power ON` + `Power on setup success` → 7.939 `Wait for device to enter SBL or Mission mode`** ← TEST25'TEN BERİ HİÇ GÖRÜLMEYEN AŞAMA! (mhi0 ilk kez power ON — WSI kırma işe yaradı, grup beklemesi kalktı)
- **8.784 FIRMWARE CANLI:** `fw_version 0x160484db fw_build_timestamp 2025-12-09 fw_build_id WLAN.WBE.1.6-01243-QCAHKSWPL_SILICONZ-1` + `chip_id 0x0 chip_family 0xb board_id 0xff soc_id 0x401a2200` → QMI handshake TAM, fw Mission mode'da cevap veriyor ✓✓
- 8.455 `qmi dma allocation failed (29360128 B type 1), will try later with small size` — 29MB DMA alloc patladı (RAM bol: 641MB free; dma_alloc_coherent contiguous bulamıyor) + 8.478 `memory type 10 not supported` (fw'nin istediği type host'ta yok) → küçük-mod retry BEKLENİYOR
- 8.822 `qmi failed to load regdb bin:` + `regdb file:-12` — **regdb.bin İMAJDA YOK** (/lib/firmware altında regdb yok; ath12k-firmware-qcn9274 paketinde Notice+board-2+firmware-2 dışında dosya yok)
- **8.8s'den sonra ath12k TAMAMEN SESSİZ** (20s+ dmesg'de hiçbir satır) → QMI mem negotiation asılı; timeout mesajı bile yok (work queue event bekliyor)
- `ps` qrtr-ns YOK → elle başlatıldı (aşağıda) · /sys/class/ieee80211 BOŞ (radyo henüz yok — probe QMI aşamasında) · debugfs `ath12k/pci-0001:01:00.0/` BOŞ
**YENİ BLOKERLER (sıralı):** ① QMI 29MB DMA (type 1) alloc fail + fw "type 10 not supported" → küçük-mod akışı takılı ② regdb.bin eksik (paket, fw dizinine regdb.bin eklenmeli — upstream ath12k-firmware QCN9274/hw2.0/regdb.bin) ③ **qrtr-ns boot'ta başlamıyor: imajdaki `/etc/init.d/qrtr` CRLF'li** (apk eski CRLF kaynakla derlenmiş; procd `/etc/rc.common\r` hatası) — cihazda elle `sed -i 's/\r$//' /etc/init.d/qrtr; /etc/init.d/qrtr start` ile başlatıldı (PID ✓, QMI yine de bu olmadan handshake etti — qrtr kernel tarafı bu aşamada yeter) — **kalıcı fix: `make package/qrtr-ns/clean compile` (kaynak artık LF) → sonraki imaj**
**DİĞER:** Ethernet regresyon YOK (LAN1+WAN 2.5G Link Up ✓) · Root Port `[17CB:1005]` pcieport + EP `[17CB:1109]` DRIVER=ath12k_wifi7_pci ✓ (§31H-2 öngörüsü) · MAC adresler random ("Using random MAC" — nvmem MAC bağlantısı bu imajda devrede değil; düşük öncelik) · `gcc sync_state() pending due to c000000.wifi` @19s (AHB ölünce normal) · debug_mask=0xffffffff runtime açık ✓ ama probe bitmiş olduğu için geriye dönük dbg YOK; "num devices/probed" satırlarını görmek için sonraki boot'ta cmdline/modules.d ile baştan açılmalı
**TEST40 PLANI (öneri):** ① qrtr-ns apk rebuild (LF kaynak) + regdb.bin pakete ekle (kvalo/ath12k-firmware QCN9274/hw2.0/regdb.bin → /lib/firmware/ath12k/regdb.bin) ② boot cmdline'a `ath12k.debug_mask=0xffffffff` (CONFIG_CMDLINE veya DTS chosen bootargs-append) — boot'tan tam iz ③ QMI 29MB DMA: reboot sonrası ilk boot'ta fragmantasyon azken geçebilir; geçmezse CMA boyutu / mem type patch değerlendirilir ④ beklenti: fw CANLI olduğu için BDF (board-2.bin, 0x1015) + radios → phy'ler gelirse 5/6G KURULUM ⑤ 2.4G hâlâ §27 cephesi (RootPD -12 TZ)
### J) TEST40 HAZIRLIK + KRİTİK DÜZELTMELER (07.09 ~17:30; bağlantı kırılgan, hızlı kayıt)
1. **REBOOT KARŞILAŞTIRMASI (deterministik/kesin):** test39 reboot sonrası BİREBİR aynı: 7.88 mhi power ON → 8.529 `qmi dma allocation failed (29360128 B type 1)` + `memory type 10 not supported` → 8.858 fw_version okundu → 8.896 regdb -12 → **sonrası SESSİZ**. Yani "fragmantasyon rebootta geçer" ŞANSI YOK — 29MB alloc + mem type 10 desteklenmiyor = **YAPISAL SORUN** (reboot çözmedi; test40'ın asıl hedefi bu).
2. **qrtr-ns cihazda elle çalıştı ✓** (`sed -i 's/\r$//' /etc/init.d/qrtr; start`) + **MHI event ring'ler AKTİF**: debugfs `IPCR(20)/IPCR(21) state 0x2 (=CONFIGURED) brstmode..type..event ring..wp..` — MHI transport tam çalışıyor, IPCR = QMI/IPC router channel ✓ → **QMI zaten MHI'den akabiliyor; qrtr-ns init'in boot'ta başlamaması BLOCK DEĞİL** (elle start çözüyor; apk LF rebuild ile kalıcı).
3. **REGDB SIRRI ÇÖZÜLDÜ (makine kanıtı):**
   - `feeds/base/firmware/linux-firmware/qca_ath12k.mk`: `ath12k-firmware-qcn9274` → `$(PKG_BUILD_DIR)/ath12k/QCN9274/hw2.0/*` (linux-firmware kaynağı) → **regdb İÇİN KURMAZ** (linux-firmware'de regdb dosyası yok).
   - `package/firmware/ath12k-firmware/Makefile` (özel paket): regdb.bin'i **YANLIŞ DİZİNE** koyuyor: `QCN9274/hw2.0/regdb.bin` → `ath12k/IPQ5332/hw1.0/regdb.bin` (PCI QCN6274 orada aramıyor!) → **fix: bu pakete QCN9274 install tanımı + regdb.bin'i `ath12k/QCN9274/hw2.0/regdb.bin`'e kur** (kvalo/ath12k-firmware QCN9274/hw2.0/regdb.bin; 20260810 apk içinde var mı kontrol — apk "not a zipfile" verdi, apk-tools ile açok).
4. **20260810-r1 apk unzip açılmadı** ("End-of-central-directory not found") — apk-tools/pax formatı; **§31B'de SHA üçlü eşleşme kanıt: 20260622 ile AYNI fw** → "yeni apk" sadece etiket; regdb içermiyor olabilir → en garanti yol: direkt kvalo regdb.bin kaynağından kur.
### L) TEST40 BUILD BAŞARILI — CİHAZA YÜKLEME HAZIR (07.09 18:06)
- **initramfs-uImage.itb = 22,724,656 B (22.7MB)** ✓ — CRLF tuzağı çözüldü, rootfs gömülü (kernel-1 = 21.64MiB)
- **uImage (sysupgrade) = 6.0MB** ✓
### M) TEST40 UART LOG ANALİZİ — KÖK SORUN NETLEŞTİ (07.09 ~19:00)
**Boot logundaki 3 kritik bulgu:**
1. **QCN6274 (17CB:1109) PCI'DA YOK!** PCIe root port (17CB:1005) var ama endpoint enumerate olmamış → driver yükleniyor ama bağlayacak cihaz yok
2. **`sync_state() pending due to c000000.wifi`** @18.4s — clock controller wifi sürücüsünü bekliyor, probe takılı
3. **Hiçbir wifi firmware yükleme mesajı YOK** — Q6 fw, regdb, board data, BDF mesajları hiç yok → `iw dev` boş, `dmesg | grep -iE 'regdb|qmi|board|bdf'` boş

**Test38 → Test40 değişikliği ve etkisi:**
- Test38: PCI device 0001:01:00.0 **vardı** (DRIVER=ath12k_wifi7_pci), MHI power_up ✓, QMI handshake ✓, fw_version ✓, regdb -12
- Test40: PCI device **yok** — WSI endpoint'leri silindi + board-id 0x1015 → QCN6274 artık PCI'da görünmüyor
- **Sonuç: WSI endpoint'leri silmek sorunu kötüleştirdi** — geri getirilmeli

**Kök sorun zinciri (güncel):**
1. İç wifi (2.4G) Q6 firmware yükleyemiyor → **RootPD -12** (TZ ENOMEM, §27)
2. WSI linki kurulmuyor (Q6 ölü)
3. QCN6274 reset/güç edilmiyor → PCI'da görünmüyor
4. ath12k_wifi7_pci bağlayacak cihaz bulamıyor

**Yeni hipotez: WSI endpoint'leri QCN6274'ün PCI枚举 için ŞART.** Silinmesi QCN6274'ü tamamen gizledi. Test41'de WSI endpoint'leri geri getirilmeli.

**Test40'ın tek kazanımı:** regdb.bin imaja eklendi (QCN9274/hw2.0/regdb.bin) — test38'de regdb -12 idi, test40'ta bu düzelmiş olmalı (ama PCI device olmadığı için doğrulanamadı).
### N) TEST41 BUILD — WSI ROLLBACK + PATCH RESTORE + REGDB (07.09 ~19:35)
**Kritik bulgu:** test40'ta QCN6274 PCI'da görünmedi → WSI endpoint'leri değil, **17 kritik patch silinmişti!** (git checkout ile geri yüklendi). Patch 107 (kernel_connect 6.18 fix) uyumsuzdu, silindi.

**Test41 değişiklikleri (test40 → test41):**
- ✅ WSI endpoint'leri DTS'te ZATEN VAR (test39'da silinmemiş, yanlış teşhis)
- ✅ 16 ath12k patch geri yüklendi (107 hariç — uyumsuz)
- ✅ board-id 0x1015 (MR47BE)
- ✅ qrtr-ns 1.2-r1 + regdb.bin (QCN9274/hw2.0/regdb.bin)
- ✅ ipq-wifi-mercusys_mr47be-v2 (BDF dosyası)
- ✅ ATH12K_DEBUG (mac80211 Makefile)

**Doğrulama:**
- initramfs-uImage.itb = 22,731,340 B (22.7MB) ✓
- regdb.bin rootfs'te ✓ (`lib/firmware/ath12k/QCN9274/hw2.0/regdb.bin`)
- kernel 21.65MiB + DTB ✓
- Manifest: qrtr-ns 1.2-r1, ath12k-firmware-ipq5332, ath12k-firmware-qcn9274, ipq-wifi-mercusys_mr47be-v2 ✓

**Beklenti:** Patch'ler geri yüklendi → QCN6274 PCI'da görünmeli (test38 kanıtı) → MHI power ON → QMI handshake → regdb.bin yüklenecek → radyolar?

**Dosyalar:** `imajlar\test41\` (itb + manifest + sha256sums)
- **manifest:** `ath12k-firmware-ipq5332`, `ath12k-firmware-qcn9274`, `qrtr-ns - 1.2-r1` ✓
- **imajlar\test40\** kopyalandı (itb + manifest; sha256sums oluşmadı, önemsiz)
- **qrtr.init LF** ✓ (0 CR) — boot'ta S20qrtr otomatik başlayacak
- **regdb fix:** `ath12k-firmware/Makefile` yeniden yazıldı — `ath12k-firmware-qcn9274` paketi artık `QCN9274/hw2.0/*` kuruyor (regdb.bin dahil); eski hatalı "regdb → IPQ5332/hw1.0" yolu kaldırıldı
- **CMA denemesi BIRAKILDI** (kconfig interaktif prompt'a takıldı, out-of-sync'e neden oldu) — CMA sonraki tur
- **bootargs hâlâ `root=/dev/ubiblock0_1`** (debug_mask cmdline eklenmedi, CMA olmadan) — debug için runtime: `echo 0xffffffff > /sys/module/ath12k/parameters/debug_mask`
- **BEKLENEN (test40 boot):** regdb -12 hatası düzelmeli (doğru yere kuruldu) → QMI board data → BDF 0x1015 eşleşmesi → radyo gelişi. 29MB DMA hâlâ fail olabilir (CMA yok) ama regdb + qrtr düzelse QMI akışı ilerler.
- **NOT:** `make package/compile` + `make target/install` ile bölünen build TEMİZ bitti (out-of-sync düzeltildi, defconfig senkron).
### K) TEST40 BUILD BAŞLADI + SNAPSHOT "UPDATE" AÇIKLAMASI + regdb (07.09 ~17:45; bağlantı kırılgan, hızlı kayıt)
1. **"Her testte LuCI update görünüyor" — AÇIKLAMA (net):** OpenWrt snapshot paketleri her gece yeniden derlenir ve sürüm no yükselir (`-r2`, `20260810-r1`) — **kod değişmese bile** (sürüm-counter her build'de artar). LuCI "yeni sürüm" der ama çoğu **içerik boş etiket değişimi**. Gerçek değişiklikler: ca-bundle (cert), libmbedtls21 3.6.6→3.6.7 (güvenlik), hostapd/wpad + wifi-scripts 1.0-r1→r2, uhttpd, jshn, ppp. **Bunların ATH12K/QMI/DMA sorunumuzla ilgisi YOK.**
2. **`ath12k-firmware-qcn9274 20260622-r1 → 20260810-r1` GEREKSİZ:** §31B SHA üçlü eşleşme kanıtı (firmware-2 birebir aynı `5115c1c1...`). 20260810 apk = sadece etiket; **upstream linux-firmware `qca_ath12k.mk`: `ath12k/QCN9274/hw2.0/*` kurar, regdb YOK** — o yüzden "güncellemeyi kabul etsen de regdb çözülmez"; adamlar regdb'yi ayrı satmıyor. (`/root/apkx3/...` SHA + cihaz/büyük eşleşme §31B.)
3. **REGDB ROOT CAUSE + FIX (kesin):** `package/firmware/ath12k-firmware` kaynağında `QCN9274/hw2.0/regdb.bin` ZATEN var ama IPQ5332 paket tanımı onu **YANLIŞ dizine** kuruyor (`→ ath12k/IPQ5332/hw1.0/regdb.bin`). PCI QCN6274 `ath12k/QCN9274/hw2.0/regdb.bin` arakıyor → "qmi failed to load regdb file:-12" cihazda. **FİX UYGULANDI:** yeni `ath12k-firmware-qcn9274-regdb` paketi (QCN9274/hw2.0/regdb.bin'e kural) eklendi; `.config` iki kopya =y (1978/4163) ✓; `ipq53xx.mk:120` DEVICE_PACKAGES'a `ath12k-firmware-qcn9274-regdb` ✓.
4. **MAKEFILE KAZASI (benim hata — DERS):** `tr -d '\r'` PowerShell'de `r` harfini de sildi → qrtr-ns/Makefile'da `rules.mk→ules.mk`, `qrtr→qt`, `Network→Netwok` → `package/qrtr-ns/compile` "ules.mk No such file" (dump.txt). **FIX: Makefile EL İLE (Windows edit) yazıldı + `sed -i 's/\r$//'` + `make package/qrtr-ns/compile` OK ✓.** KURAL (tekrar): Windows'tan ağaca kopyalanan HER dosya `tr -d '\r'` DEĞİL `sed -i 's/\r$//'` (tr'nın r silebilir!) veya LF tekrar, sonra package compile testi.
5. **CMA denemesi — BIRAKILDI (kısmi):** `CONFIG_CMA not set` (kernel .config:927) → QMI 29MB alloc için CMA dene-ye d? Ama tahmini: kconfig syncconfig interaktif prompt (CMA_DEBUGFS) → batch build new cıktı; ayrıca **29MB alloc'un dma_alloc_coherent değil dma_alloc + CMA olmadan fail beklentisi** belirsiz. **Karar: CMA'yı test40'te AÇMADAN build ediyoruz** (regdb + qtr fix ile QMI dolaşımı düzellirse "küçük-mod retry" akışı devam edebilir); CMA sonraki patch turunda. DTS'e eklediğim `cma=128M` geri alındı (bootargs temiz).
6. **TEST40 build BAŞLATILDI** (~17:45, setsid make -j4, log /root/test40-build.log). Değişiklikler: qrtr-ns Makefile yeniden (LF ✓), regdb paketi (3 maddede) ekli, DTS sadece WSI kırık + board-id 0x1015 (test39'dan korundu; CMA yok). **Beklenen hedefler:** ① imajda `ath12k/qcn9274-regdb - 1` + `ath12k/QCN9274/hw2.0/regdb.bin` VAR ② qrtr-ns apk LF (boot'ta otomatik S20qrtr) ③ boot sonrası dmesg: regdb yükleme ✓/bdf "board data" araması, QMI hash `qmi dma allocation failed` hâlâ var mı (küçük-mod retry beklenir), "num devices/probed" ④ radyo gelirse 5/6G ⑤ 2.4G ayrı (§27).
5. **MAKEFILE BOMBA (BENİM HATAM):** `tr -d '\r'` PowerShell'de `r` HARFİNİ DE SİLDİ → qrtr-ns/Makefile'da `rules.mk→ules.mk`, `qrtr→qt`, `Network→Netwok` oldu ve `package/qrtr-ns/compile` "ules.mk No such file" hatası verdi (dump.txt). **FIX YAPILMADI (PowerShell heredoc patladı) — yeni oturumda Makefile'ı 0'dan EL İLE yeniden yaz** (şablon: §31H-7 içeriği, LF).
6. **bootargs-append (dts satır 39) HÂLÂ `" root=/dev/ubiblock0_1"`** (sed bash'te patladı) — `ath12k.debug_mask=0xffffffff` cmdline test40'ta editor-ile DTS chosen append'a eklenmeli (boot'tan tam iz).
7. **WSL ext4 QCNCM865/NCM865 PROJESİ (yeni BÜYÜK fırsat):** /root/ çok zengin — `qca-wireless-20260823`, `gpl-lx54`, `jiay-wlan-ap`, `askey-sbe1v1k-20260907`, `mrfw`, `bdf`, fw decrypt araçları... **QCNCM865 = Qualcomm Wi-Fi 7** — MHI/QMI aynı aile; **NCM865 projesinde qmi_dma/mem_type/regdb/patch değiştirilmiş olabilir → test40'ın 29MB DMA + mem_type 10 sorunu için GOLD-MINE kaynağı** (araştırılacak: "29360128"/"qmi dma"/"mem type 10" geçen dosyalar).
8. **TEST41 beklentiler (öncelik):** ① regdb doğru yere (QCN9274/hw2.0) + qrtr-ns LF rebuild → ② 29MB DMA: CMA büyüt VEYA QMI mem_type patch (NCM865/GPL kaynakları) → ③ düzelse "num devices/probed" + "board data 0x1015" + phy/radyo gelişi ④ 2.4G §27 ayrı cephe.

## 32. TEST41 SONUCU + PCIe TEŞHİS KESİNLEŞMESİ (07.09 — UART + SSH canlı)
- İmaj: test41 initramfs, TFTP/UART boot ✓ (kernel 6.18.39, config@mi01.6). SSH ✓, ping 8.8.8.8 ✓ (WAN internet), LAN1 ✓; LAN2/3 ✗ (switch sürücüsü), WiFi ✗. test41_dmesg_live.txt (284 satır) imajlar\test41\ klasöründe.
- regdb FİX CİHAZDA DOĞRULANDI: /lib/firmware/ath12k/QCN9274/hw2.0/regdb.bin VAR. Ama dmesg'de SIFIR qmi/regdb/bdf satırı → sebep ath12k değil; PCI probe QMI aşamasına hiç gelmiyor (MHI power-up yok). qrtr-ns çalışıyor mu ps ile kontrol EDİLMEDİ (cihaz çökmeden önce).
- PCIe teşhisi (test25/26/31/32/36 UART loglarında tarandı — desen sabit; 27/39/40/41 aynı): [17cb:1005] Root Port (type 01 class 0x060400, ~1.075s) HER ZAMAN ✓ — sorun hiç o değildi; onunla yapılan DTS denemeleri (interconnects vb. §25) hedef yanlış olduğu için sonuçsuzdu. EP [17cb:1109] (QCN6274 JE510CV2, sürücü "qcn9274 hw2.0"): enumerate ✓ + bound + MSI16 ✓ sonra sessizlik — hatası -12/-22 DEĞİL, hiç hata basmıyor. -22 (test25/26) → -12 (test32+) daima ath12k_wifi7_ahb c000000.wifi = IPQ5332 İÇ Q6 (TZ auth_and_reset, §27).
- debug_mask parametre yolu kesinleşti: çekirdek modülü "ath12k" (614KB; debug_mask+ftm_mode), glue "ath12k_wifi7" (90KB; parametresiz) → /sys/module/ath12k/parameters/debug_mask DOĞRU; SSH'ten yazılıp okundu (4294967295).
- ÇÖKME (2x kanıt): rmmod ath12k_wifi7 → rmmod ath12k → modprobe, SSH üzerinden → bağlantı reset; cihaz ping ✓ / port 22 ✗ (userspace takılı) → UART güç çevrimi. KURAL: ath12k reload YALNIZ UART'tan; reload mask'i 0'a indirir (kalıcılık: /etc/modules.d'de "ath12k debug_mask=0xffffffff"; ya da modprobe sonrası hemen echo).
- SONRAKİ EN KAZANÇLI ADIM: UART'tan debug_mask=0xffffffff + modül reload → PCI probe'un hangi satırda return ettiğini gör (MHI power-up çağrılmıyor). 2.4G ayrı cephe: §31H-8 (NCM865/GPL qmi_dma/mem_type araştır + vendor 35MB q6_region + reset_cmd_id 0x14).

## 33. Q6-FW-COMPARE + RAM TEST (08.09 — firmware içeriği ELENDİ, vendor DTB = yeni prime suspect)
> Kaynak: `/root/flint3-mr47be-20260903/Q6-FW-COMPARE-RAMTEST-LIVE-LOG.md` (210 satır, WSL'de)
> Altyapı: `2.4GHZ-Q6-PAS-FINDINGS.md`. Test düzeneği: **test37 = 192.168.1.1 (tek çalışan kart; test38+ bozuk — onlara test planlama)**

### ① Üçlü q6_fw0 karşılaştırması — hepsi FARKLI
| # | Kaynak | mdt md5 | mdt boyut | Nerede (WSL) | RAM-test? | Sonuç |
|---|--------|---------|-----------|--------------|-----------|-------|
| A | Proje orijinal (upstream linux-firmware, QCOM ref) | `250e1642000d54df6c13dabc08560949` | 11812 | staging_dir `.../IPQ5332/hw1.0/q6_fw0.*.orig` (flash = bu) | YES (boot) | **-12** |
| B | Xiaomi RD08 1.1.96 (UBI+squashfs'tan çıkarıldı) | `7d617bfd232d6ae434cb4de73f93f7da` | 15472 | `/root/xiaomi_6500pro/rootfs/lib/firmware/IPQ5332/WIFI_FW/` | HAYIR (bekliyor) | ? |
| C | GL.iNet stok 4.9.0_release5 (FIT #0 wifi_fw squashfs) | `530f6a96687b687c5edcf5c5299ecb38` | 11812 | `/root/gl-inet-stok/deploy_glinet_q6fw0/` | YES (tmpfs) | **-12, aynı** |
| D | **Vendor DTB** (GL.iNet FIT #2, compatible `qcom,ipq5332-ap-mi01.6`) | — | 58498 | `/root/gl-inet-stok/vendor.dtb` + `vendor.dts` | n/a | n/a |
- Segment gerçeği: `q6_fw0.flist` + `q6_fw0.b04` ÜÇÜNDE DE aynı; diğer her segment + mdt farklı. Xiaomi mdt yapısal farklı (15472 vs 11812 B — farklı build gen).

### ② RAM testi (test37, tmpfs bind-mount, zero flash) — sonuç KESİN
- Yöntem (tekrar edilebilir): `/tmp/fwtest` tmpfs + `mount --bind` → `/lib/firmware/ath12k/IPQ5332/hw1.0` + `d100000.remoteproc` unbind/bind + AHB re-probe. Dağıtım: `ssh root@192.168.1.1 'mkdir -p /tmp/fwtest; mount -t tmpfs tmpfs /tmp/fwtest; cd /tmp/fwtest; tar xzf -' < glinet_q6fw0.tar.gz` (scp OLMAZ — board'da sftp yok; tar'ı SSH stdin'den pipe et).
- GL.iNet stok (mdt `530f6a96` mount içinden md5 ile doğrulandı, "Booting fw image ... size 11812") → **AYNI -12, birebir**:
  `MR47BE: mpd pas=13 dbg=0 cmd=24 ret=-12 res0=0` → `wcss_reset failed` → `can't start rproc q6wcss: -12`
- **ÇIKARIM: -12'nin sebebi firmware İÇERİĞİ DEĞİL.** (Retail TZ, fw ne olursa olsun aynı noktada reddediyor.)

### ③ Vendor DTB memory-map farkı = şimdiki prime suspect
- Bizim DTS (`ipq5332-mr47be-v2.dts` satır 58-59): `q6_region: wcss@4a900000 { reg = <0x0 0x4a900000 0x0 0x02b00000>; }` = **43 MB**; satır 68 `q6_caldb@4d500000`; satır 626-629 memory-region: `q6_region, m3_dump, q6_caldb, mlo_mem`.
- Vendor: q6_region **35 MB (`0x2300000`)** + **4 ek bölge** (m3_dump@4cc00000 + q6_etr_dump@4cd00000 + caldb@4ce00000 + mlo@4db00000 — mlo zaten bizde) + **`qcom,bootargs_version = <2>`** + **`qcom,heartbeat_smem = <508>`** — bizde HİÇBİRİ yok.
- QSDK çapraz kontrolü (Deco BE65 V2 GPL → `/root/qsdk_q6v5_mpd.c`, linux-5.4):
  - **3-arg auth GERÇEK QSDK davranışı:** `qcom_scm_pas_auth_and_reset(pasid, debug_wcss, reset_cmd_id)` → 2010b/0606 yama yönü DOĞRU.
  - **QSDK SMEM 507'ye FORMATLI bootargs yazıyor:** `u16 version` + `u16 element-count` + `boot-args[]` + **userpd entry'leri** (`q6_userpd_bootargs`: header{type,len}+pid+bootaddr+data_size) + **license entry'leri** (`license_bootargs`) + **create_heartbeat_smem** (`qcom,heartbeat_smem`=508). Biz bunların HİÇBİRİNİ yazmıyoruz — muhtemel eksik parça.
  - `q6_ipq5332_res_init` varsayılanı **VERSION2**.
  - QSDK `qcom_pil_info_store()` ÇAĞIRMIYOR (bizim 2010 yaması ekliyor; retail TZ'de PIL tablosu olmayabilir — boyut uyarısı anlamsız olabilir ama SMEM-507 formatı GERÇEK).
- Askey SBE1V1K **ELENDİ** (IPQ5018 tabanlı; 5332 bellek haritası referansı DEĞİL). En iyi bellek-harita referansı **GL vendor DTB** olarak kalıyor.

### ④ Test37 board durumu (08.09 sonu)
- Flash'a HİÇ dokunulmadı; mdt=`250e1642` (A) doğrulandı; remoteproc0 `offline`; `/tmp/fwtest` tmpfs unmount + bind-mount kaldırıldı + driver re-bound.
- Wi-Fi 5/6 GHz qcn9274 PCIe çalışıyor (ilgisiz); sadece boot-time Q6 -12.

### ⑤ Beklentiler — sıralı SONRAKİ ADIMLAR
1. **Sürücü yaması (EN YÜKSEK, ucuz):** QSDK bootargs yazıcısını bizim wcss-secure-pil 2010/2010c yamasına taşı (SMEM 507'ye `u16 version(2)` + count + userpd + license + heartbeat 508 → auth ÖNCESİ yaz; 507 zaten allocate edildi, içerik eksik olabilir). DTS'e ekle: `qcom,bootargs_version=<2>`, `qcom,heartbeat_smem=<508>`, `qcom,bootargs_smem=<507>`.
2. **DTB 35MB testi (orta):** `q6_region` `0x2b00000`→`0x2300000` + m3_dump@4cc00000 + q6_etr_dump@4cd00000 + caldb@4ce00000 + mlo@4db00000 — AMA SMEM-507 içeriği gerçek kapıysa -12'nin sürmesi beklenir.
3. Rebuild (kernel+dtb) → TFTP/initramfs → test37 üzerinde aynı bind-mount RAM-test prosedürü.
4. Hâlâ -12 ise: 2010c debug print'leriyle SCM/SMEM içeriğini dök; QSDK `reset_cmd_id` (0x18) + `debug_wcss` semantiğini derinleştir; **pd1/pd2 spawn gereksinimlerini kontrol et** (vendor `q6_fw1.mdt`/`iu_fw` DTB'de VAR ama biz boot etmiyoruz — vendor önce q6_fw0 boot ediyor, biz de; retail TZ ikinci PAS id/upd isteyebilir).

### ⑥ Araçlar (WSL `/root/flint3-mr47be-20260903` + bu workspace q6fw-compare/)
`scan.py, q6find.py, ubi_q6.py, dbg_ubi.py, compare.py, compare3.py, parse_fit.py, extract_rootfs.py, extract_wifi_fw.py, scan_glinet.py, scan_wifi_fw.py, parse_fit_v2.py, dump_vendor_dts.py, dump_phandles.py, find_sbe_dts.py, board_recon.sh, transfer_fw.sh, ram_test.sh, cleanup.sh, LIVE-LOG.md`
Anahtar artefaktlar: `/root/xiaomi_6500pro/{fw.bin,rootfs/}`, `/root/gl-inet-stok/{stok.bin,deploy_glinet_q6fw0/,glinet_q6fw0.tar.gz,vendor.dtb,vendor.dts,ex_images_wifi_fw/}`, `/root/qsdk_q6v5_mpd.c`

### ⑦ DTS güncel durum (test37 üzerinde — karışıklık yok)
- `target/linux/qualcommbe/dts/ipq5332-mr47be-v2.dts`: q6v5_wcss firmware-name `q6_fw0.mdt` ✓ · memory-region `q6_region+m3_dump+q6_caldb+mlo_mem` ✓ · **q6_region HÂLÂ 43MB** (35MB + bootargs/heartbeat YAMA YAPILMADI — bu oturumun 1. adımı).
- Yedekler ayrışmış: `.bak_test28/29/30/33_20260904/05`, `.bak_test39_20260907`, `.bak_gpio17_20260903`.
- Patch seti (patches-6.18): `2008-metadata`, `2010-wcss-secure-pil (ana)`, `2010a-q6v5-crash-reason`, **`2010b-3arg-pas-auth`** (3118B), **`2010c-pas-mem-setup-debug`** (938B), `2012-dts-q6-nodes`, `2012-shmbridge-pas-metadata` (438B). Q6 -12 cephesi için kritik olanlar: 2010/2010b/2010c + 2012/2012-shmbridge.
