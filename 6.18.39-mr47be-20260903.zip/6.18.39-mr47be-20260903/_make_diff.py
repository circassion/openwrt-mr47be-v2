import subprocess, os

# Path to modified source (with my changes)
mod_path = '/root/flint3-mr47be-20260903/build_dir/target-aarch64_cortex-a53_musl/linux-qualcommbe_ipq53xx/linux-6.18.39/drivers/remoteproc/qcom_q6v5_wcss_sec.c'

# Extract fresh kernel and apply 2010c to get the "original"
orig_path = '/tmp/qcom_q6v5_wcss_sec_2010c.c'
proj = '/root/flint3-mr47be-20260903'

# Extract kernel
subprocess.run(['xzcat', f'{proj}/dl/linux-6.18.39.tar.xz'], 
               stdout=open('/tmp/linux.tar', 'wb'), check=True)
subprocess.run(['tar', 'xf', '/tmp/linux.tar', '-C', '/tmp/'], check=True)

# Copy generic files
subprocess.run(['cp', '-r', f'{proj}/target/linux/generic/files/.', 
                f'/tmp/linux-6.18.39/'], check=True)

# Apply patches 2010, 2010a, 2010b, 2010c
patches_dir = f'{proj}/target/linux/qualcommbe/patches-6.18'
for p in ['2010', '2010a', '2010b', '2010c']:
    patch_file = None
    for f in os.listdir(patches_dir):
        if f.startswith(p + '-'):
            patch_file = os.path.join(patches_dir, f)
            break
    if patch_file:
        subprocess.run(['patch', '-p1', '-i', patch_file], 
                       cwd='/tmp/linux-6.18.39', check=True)

# Copy the 2010c-applied source
import shutil
shutil.copy('/tmp/linux-6.18.39/drivers/remoteproc/qcom_q6v5_wcss_sec.c', orig_path)

# Now generate diff
result = subprocess.run(['diff', '-u', orig_path, mod_path], 
                       capture_output=True, text=True)

# Write the patch
patch_path = f'{proj}/target/linux/qualcommbe/patches-6.18/2010d-remoteproc-qcom-wcss-sec-bootargs-writer.patch'
with open(patch_path, 'w') as f:
    f.write(result.stdout)

print(f'Patch written to {patch_path}')
print(f'Size: {len(result.stdout)} bytes')
print('First 10 lines:')
for line in result.stdout.split('\n')[:10]:
    print(line)
