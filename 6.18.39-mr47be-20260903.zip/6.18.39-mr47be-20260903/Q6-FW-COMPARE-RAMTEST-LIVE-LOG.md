# Q6 Root PD — Firmware Compare + RAM Test — LIVE LOG

Date: 2026-09-08 (session). Companion to `2.4GHZ-Q6-PAS-FINDINGS.md` (read that first).

## TL;DR — what changed today

1. **Three-way q6_fw0 comparison done** (project / Xiaomi RD08 / GL.iNet stock):
   ALL THREE Root PD images are DIFFERENT (only `flist` + `b04` shared).
2. **RAM test (tmpfs bind-mount, zero flash writes) executed on test37**:
   GL.iNet stock firmware fails with the **identical -12** at the identical call.
   => Firmware CONTENT is NOT the cause of `-12`.
3. **Vendor DTB extracted + decompiled (GL.iNet stock FIT)**:
   Found a **memory-map mismatch** that is now the prime `-12` suspect:
   our q6_region is **43 MB (0x2b00000)**, vendor is **35 MB (0x2300000)** plus
   **four more memory-regions** we don't define, plus
   `qcom,bootargs_version = <2>` / `qcom,heartbeat_smem = <508>` we don't set.

## Test rig

- **test37 = 192.168.1.1** — the ONLY working board right now. test38+ are broken/unusable
  (per owner; do not schedule tests on them).
- OpenWrt SNAPSHOT, kernel 6.18.39 (Sep 3 build of this tree), SSH root@ (BatchMode/key OK).
- Driver: `qcom-wcss-secure-pil` bound to `d100000.remoteproc`; remoteproc0 = `q6wcss`;
  AHB wifi: `ath12k_wifi7_ahb` @ `c000000.wifi`.
- RAM-test method (REPEATABLE, flash-safe): tmpfs at /tmp/fwtest + `mount --bind`
  over `/lib/firmware/ath12k/IPQ5332/hw1.0` + unbind/bind of
  `d100000.remoteproc` + re-probe AHB. Revert = umount + rebind (or reboot).
  Tarball deploy: `ssh root@192.168.1.1 'mkdir -p /tmp/fwtest; mount -t tmpfs tmpfs /tmp/fwtest; cd /tmp/fwtest; tar xzf -' < glinet_q6fw0.tar.gz`
  (scp does NOT work: no sftp-server on board; pipe tarball via SSH stdin.)

## Firmware images in hand (the arsenal)

| # | Source | mdt md5 | mdt size | Where (WSL) | RAM-tested? | Result |
|---|--------|---------|----------|-------------|-------------|--------|
| A | Project original (upstream linux-firmware, QCOM ref) | `250e1642000d54df6c13dabc08560949` | 11812 | `staging_dir/.../IPQ5332/hw1.0/q6_fw0.*.orig` (board flash = this) | YES (boot) | **-12** |
| B | Xiaomi RD08 1.1.96 (`miwifi_rd08_firmware_708c2_1.1.96.bin`, HDR1→UBI→squashfs) | `7d617bfd232d6ae434cb4de73f93f7da` | 15472 | `/root/xiaomi_6500pro/rootfs/lib/firmware/IPQ5332/WIFI_FW/` (staged into project dir, originals kept as `.orig`) | **NO — not yet tested on board** | ? |
| C | GL.iNet stock 4.9.0_release5 (`be9300-4.9.0...bin`, FIT #0 inline `wifi_fw` squashfs) | `530f6a96687b687c5edcf5c5299ecb38` | 11812 | `/root/gl-inet-stok/deploy_glinet_q6fw0/` + `glinet_q6fw0.tar.gz` | YES (tmpfs bind-mount) | **-12, identical** |
| D | **Vendor DTB** (from GL.iNet FIT #2, compatible `qcom,ipq5332-ap-mi01.6`) | — | 58498 B | `/root/gl-inet-stok/vendor.dtb` + decompiled `vendor.dts` | n/a | n/a |

md5 facts (segment level):
- `q6_fw0.flist` (`0892740a...`) and `q6_fw0.b04` (`ecaa7844...`): IDENTICAL in all three.
- Every other segment + mdt: all three differ. NOTE: earlier "Proj==Xiaomi" table was
  contaminated — it compared Xiaomi-installed staging. True project = `.orig` files.
- Xiaomi mdt is structurally different (15472 B vs 11812 B) — different build gen.

## RAM test results on test37 (2026-09-08)

Boot (image A, from flash):
```
MR47BE: wcss_sec_start pasid=13 mem_phys=0x000000004a900000 mem_size=45088768
MR47BE: pas_mem_setup ret=0
MR47BE: mpd pas=13 dbg=0 cmd=24 ret=-12 res0=0 res1=0 res2=0
qcom-wcss-secure-pil d100000.remoteproc: wcss_reset failed
remoteproc remoteproc0: can't start rproc q6wcss: -12
ath12k_wifi7_ahb c000000.wifi: RootPD boot failed
```

tmpfs bind-mount of image C (GL.iNet stock, mdt 530f6a96 loaded — verified via md5
through the mount, "Booting fw image ... size 11812"):
```
MR47BE: wcss_sec_start pasid=13 mem_phys=0x000000004a900000 mem_size=45088768
MR47BE: pas_mem_setup ret=0
MR47BE: mpd pas=13 dbg=0 cmd=24 ret=-12 res0=0 res1=0 res2=0
... can't start rproc q6wcss: -12
```
IDENTICAL failure. Interpretations:
- Firmware content/signature is NOT what makes TZ return -12 (two unrelated vendor
  images behave byte-for-byte identically at the SCM call).
- OEM-lock hypothesis WEAKENED: if TZ rejected by OEM signature we'd expect a
  different error (e.g. back to -22) for a foreign-OEM image. We got the same -12.
- mem_phys/mem_size and pas_mem_setup(ret=0) are identical in both runs — the call
  that dies is `PAS_AUTH_AND_RESET` itself (cmd=24=0x18, our 3-arg patch).
- Board restored after test: umount + rebind done, flash mdt verified `250e1642`,
  remoteproc0 state `offline`. Zero flash writes all session.

## VENDOR DTB FINDINGS (prime -12 suspect)

Vendor `remoteproc@d100000` (compatible `qcom,ipq5332-q6-mpd`, reg `<0xd100000 0x4040>`
"qdsp6", firmware `IPQ5332/q6_fw0.mdt`):

```
memory-region = <0x2c 0x32 0x33 0x34 0x35>;   // FIVE regions
qcom,bootargs_smem = <507>;
qcom,bootargs_version = <2>;
qcom,heartbeat_smem = <508>;
license-file = [00];
```

Vendor reserved-memory map (the full picture):
```
tzapp@49b00000        6 MB   (0x49b00000)
uboot@4a100000        4 MB
sbl@4a500000          1 MB
tz@4a600000           2 MB
smem@4a800000         1 MB   (phandle 0x19)
wcnss@4a900000       35 MB   (0x2300000)  phandle 0x2c  <-- q6_region equivalent
m3_dump@4cc00000      1 MB   phandle 0x32
q6_etr_dump@4cd00000  1 MB   phandle 0x33
q6_caldb_region@4ce00000 5 MB phandle 0x34
mlo_global_mem_0@4db00000 18 MB (0x1200000) phandle 0x35
qcn9224_pcie0@4ed00000 50 MB (disabled)
qcn9224_pcie1@51f00000 50 MB (ok — 5/6 GHz radio)
dma_pool1              9 MB (ok)
```

OUR tree (patch 2012, upstream ipq5332.dtsi):
```
q6_region: wcss@4a900000 { reg = <0x0 0x4a900000 0x0 0x2b00000>; };  // 43 MB!
memory-region = <&q6_region>;                                        // ONE region
```

THE MISMATCH:
- Our 43 MB single no-map region (0x4a900000..0x4d3fffff) SWALLOWS the vendor's
  m3_dump / q6_etr_dump / q6_caldb_region (0x4cc00000..0x4d2fffff) and overlaps
  mlo_global_mem (0x4db00000..). Vendor wcnss is only 35 MB (ends 0x4cbfffff).
- We pass 1 memory region; vendor passes 5. TZ (built against the vendor map)
  gets a size/region set it doesn't expect -> -ENOMEM from PAS_AUTH_AND_RESET is
  exactly the shape of failure you'd predict.
- Also unset by us: `qcom,bootargs_version = <2>`, `qcom,heartbeat_smem = <508>`
  (findings doc already tried bootargs segment 507 alone — version/heartbeat may matter).

## Root-cause theory (current best)

-12 (ENOMEM) from TZ is caused by the memory-map/METADATA mismatch between our
DTB and what the retail TrustZone expects: wrong q6_region size (43 vs 35 MB),
missing m3_dump/etr_dump/caldb/mlo_global regions in memory-region list, missing
bootargs_version=2 / heartbeat_smem. NOT the q6_fw0 binary itself (proven by RAM test).

## NEXT STEPS (concrete)

1. Patch 2012 + board DTS (gl-be9300 / mr47be):
   - q6_region size 0x2b00000 -> 0x2300000
   - add m3_dump@4cc00000 (1MB), q6_etr_dump@4cd00000 (1MB),
     q6_caldb_region@4ce00000 (5MB), mlo_global_mem_0@4db00000 (18MB), all no-map
   - memory-region = <&q6_region &m3_dump &q6_etr_dump &q6_caldb &mlo_global>
   - add qcom,bootargs_version = <2>; qcom,heartbeat_smem = <508> (needs driver
     support check in qcom_wcss_secure_pil / our MR47BE patch)
   - consider tzapp/uboot/sbl/tz/smem low regions if not already present
     (findings doc: added, kept — still needed with the new map)
2. Rebuild kernel+dtb, TFTP/initramfs boot, RAM-test again (same procedure).
3. Optional while at it: RAM-test Xiaomi image B via the same bind-mount flow
   (completes the matrix; not expected to change the -12 but cheap).
4. If -12 persists with the exact vendor map -> next suspect is the 8 MB gap
   0x4d300000..0x4db00000 (vendor leaves it unreserved) and glink/smp2p details;
   diff vendor glink-edge + interrupts against ours (vendor uses GIC SPI 421/417
   equivalents: hwirq 0x1a5/0x1a1 + smp2p 435/428 — our patch uses 421/417+435/428,
   looks consistent; verify irq type EDGE_RISING matches).

## ADDENDUM — session checkpoint (2026-09-08, saved defensively)

### What we were doing (context)
Chasing the `-12 (ENOMEM)` from `MR47BE: mpd pas=13 dbg=0 cmd=24 ret=-12` on the
MR47BE Q6 bring-up. Firmware content proven NOT the cause (RAM test, all 3 images -
12). Pivoted to: what does the retail TZ need that our driver/DTB does not provide?

### What I found this session (QSDK cross-check — DECO BE65 V2 GPL)
`/root/qsdk_q6v5_mpd.c` = QSDK 12.2 (linux-5.4) IPQ5332 MPD driver:
- **3-arg auth is genuine QSDK behavior**: `qcom_scm_pas_auth_and_reset(desc->pasid,
  debug_wcss, wcss->reset_cmd_id)` — validates our 2010b/0606 patch direction.
- **QSDK writes FORMATTED bootargs to SMEM 507** (`qcom,bootargs_smem`):
  `u16 version` + `u16 element-count` + `boot-args[]` bytes + userpd entries
  (`q6_userpd_bootargs`: header{type,len} + pid + bootaddr + data_size) +
  license entries (`license_bootargs`: header + license_type + addr + size) +
  **create_heartbeat_smem** (`qcom,heartbeat_smem`=508).
- Default `q6_ipq5332_res_init` = `bootargs_version VERSION2` (line 3784).
- QSDK's memory-region list (num_segs) is used for **coredump segments only** —
  same as our driver; NOT fed to TZ as a table.
- **QSDK does NOT call qcom_pil_info_store()** in mpd — our 2010 patch ADDS it
  ("wcss", phys, 43MB). Vendor TZ may not have this PIL table at all (QSDK flash
  has it; retail TZ unknown) — the size mismatch warning in our DTS comment may be
  moot for retail, but SMEM-507 bootargs format is real.

### Askey SBE1V1K = NOT our reference
`/mnt/e/ROUTER/router/Askey SBE1V1K/` = **IPQ5018**-based tree (dts/ = ipq5018-*,
q6 patches 0186/0188 target IPQ5018). Not MR47BE's IPQ5332 reference. Usable for
wcss-secure-pil driver ideas, NOT for the 5332 memory map.

Our GL-BE9300 vendor DTB (compatible `qcom,ipq5332-ap-mi01.6`) REMAINS the best
memory-map reference: wcnss 35MB + m3_dump + etr_dump + caldb + mlo_global.

### Board state (test37, 192.168.1.1)
- Flash untouched all session; mdt=`250e1642` verified; remoteproc0 `offline`.
- /tmp/fwtest tmpfs unmounted; bind-mount removed; driver re-bound.
- Only the boot-time -12; Wi-Fi 5/6 GHz qcn9274 PCIe works (unrelated).

### Expectations / next actions (ranked)
1. **Driver patch (HIGH confidence, cheap)**: mirror QSDK bootargs writer in our
   wcss-secure-pil 2010/2010c patch — write u16 version(2) + u16 count + userpd +
   license + heartbeat(508) into SMEM 507 before auth (we alloc'd 507 already;
   content may be the missing piece). Add `qcom,bootargs_version=<2>`,
   `qcom,heartbeat_smem=<508>`, `qcom,bootargs_smem=<507>` to remoteproc DTS node.
2. **DTB 35MB test (medium)**: q6_region 0x2b00000→0x2300000 + m3_dump@4cc00000 +
   q6_etr_dump@4cd00000 + caldb@4ce00000 + mlo@4db00000 (already present) —
   but expect -12 to persist if the SMEM-507 content is the actual gate.
3. Rebuild kernel+dtb → TFTP/initramfs → RAM-test via same bind-mount procedure.
4. If STILL -12: dump SCM/SMEM contents via 2010c debug prints on board, and diff
   QSDK reset_cmd_id value (0x18) + `debug_wcss` semantics; consider that retail TZ
   wants a second PAS id (upd pd1/pd2 q6_fw1/iu_fw present in vendor DTB but not
   booted by us — vendor boots q6_fw0 first, ours too; check pd1 spawn requirements).

### Scripts on disk (this workspace q6fw-compare/)
scan.py, q6find.py, ubi_q6.py, dbg_ubi.py, compare.py, compare3.py, parse_fit.py,
extract_rootfs.py, extract_wifi_fw.py, scan_glinet.py, scan_wifi_fw.py,
parse_fit_v2.py, dump_vendor_dts.py, dump_phandles.py, find_sbe_dts.py,
board_recon.sh, transfer_fw.sh, ram_test.sh, cleanup.sh, LIVE-LOG.md
Key artifacts (WSL): /root/xiaomi_6500pro/{fw.bin,rootfs/},
/root/gl-inet-stok/{stok.bin,deploy_glinet_q6fw0/,glinet_q6fw0.tar.gz,vendor.dtb,
vendor.dts,ex_images_wifi_fw/}, /root/qsdk_q6v5_mpd.c


