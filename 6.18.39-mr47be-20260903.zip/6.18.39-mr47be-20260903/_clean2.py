data = open('/root/flint3-mr47be-20260903/target/linux/qualcommbe/patches-6.18/2010d-remoteproc-qcom-wcss-sec-bootargs-writer.patch', 'rb').read()
data = data.replace(b'\r\n', b'\n')
open('/root/flint3-mr47be-20260903/target/linux/qualcommbe/patches-6.18/2010d-remoteproc-qcom-wcss-sec-bootargs-writer.patch', 'wb').write(data)
print('CLEANED', len(data), 'bytes')
